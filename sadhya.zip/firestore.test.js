const {
  initializeTestEnvironment,
  assertSucceeds,
  assertFails,
} = require('@firebase/rules-unit-testing');
const { describe, it, before, after, beforeEach } = require('node:test');
const fs = require('node:fs');

const PROJECT_ID = 'demo-no-project';
const ALICE_UID = 'alice_devotee_01';
const BOB_UID = 'bob_devotee_02';
const ADMIN_UID = 'admin_sevak_01';
const TEMPLE_ID = 'mayapur_chandrodaya';
const POST_SEVA_ID = 'post_seva_01';
const POST_ANN_ID = 'post_ann_01';

let testEnv;

function pastDate(offsetMs = 2000) {
  return new Date(Date.now() - offsetMs);
}

function futureDate(offsetMs = 120000) {
  return new Date(Date.now() + offsetMs);
}

function validUserProfile(uid, overrides = {}) {
  const ts = pastDate();
  return {
    userId: uid,
    displayName: 'Radha Dasi',
    email: 'radha@example.com',
    routineMode: 'CONGREGATIONAL',
    wakeTime: '04:45',
    sleepTime: '21:45',
    japaTargetRounds: 16,
    readingTargetMinutes: 30,
    hearingTargetMinutes: 30,
    attendOnlineMangalAarti: true,
    gayatriInitiated: false,
    gayatriMorningTime: '06:15',
    gayatriAfternoonTime: '12:15',
    gayatriEveningTime: '18:15',
    responsibilities: ['Morning Sadhana', 'Daily Seva'],
    distractingPackages: ['com.instagram.android', 'com.google.android.youtube'],
    focusStrictness: 'BALANCED',
    calendarTradition: 'ISKCON_MAYAPUR',
    locationName: 'Mayapur, India',
    latitude: 23.4231,
    longitude: 88.3880,
    timezoneId: 'Asia/Kolkata',
    followedTempleId: 'ref_mayapur',
    activeFestivalMode: '',
    themeStyle: 'IVORY_MAROON',
    darkModePreference: 'SYSTEM',
    fontScaleLevel: 'STANDARD',
    bedtimeModeEnabled: true,
    onboardingCompleted: false,
    createdAt: ts,
    updatedAt: ts,
    ...overrides,
  };
}

function validScheduleItem(overrides = {}) {
  const ts = pastDate();
  return {
    title: 'Morning Japa Meditation',
    category: 'JAPA',
    startTime: '05:00',
    endTime: '06:30',
    essential: true,
    completedDateKey: '',
    notes: '16 attentive rounds',
    sortOrder: 1,
    createdAt: ts,
    updatedAt: ts,
    ...overrides,
  };
}

function validDailyTask(overrides = {}) {
  const ts = pastDate();
  return {
    title: 'Prepare Ekadashi fruits',
    category: 'Devotion',
    dueDateKey: '2026-05-15',
    reminderTime: '07:30',
    priority: 'HIGH',
    completed: false,
    notes: 'Offer before sunrise',
    createdAt: ts,
    updatedAt: ts,
    ...overrides,
  };
}

function validSadhanaLog(overrides = {}) {
  const ts = pastDate();
  return {
    japaRounds: 16,
    readingMinutes: 30,
    hearingMinutes: 25,
    mangalAartiAttended: true,
    gayatriMorningDone: false,
    gayatriAfternoonDone: false,
    gayatriEveningDone: false,
    pujaDone: true,
    wakeStatus: 'ON_TIME',
    wakeActualTime: '04:40',
    sevaMinutes: 45,
    sevaNote: 'Temple flower garland seva',
    reflectionNote: 'Peaceful morning chanting',
    creditedAudioIds: ['tanpura_sa_pa'],
    createdAt: ts,
    updatedAt: ts,
    ...overrides,
  };
}

function validFocusLog(overrides = {}) {
  return {
    packageName: 'com.instagram.android',
    appLabel: 'Instagram',
    strictness: 'BALANCED',
    outcome: 'RETURNED_TO_SADHANA',
    reason: 'Returned to morning Japa',
    durationMinutes: 45,
    createdAt: pastDate(),
    ...overrides,
  };
}

function validTemple(adminUid, overrides = {}) {
  const ts = pastDate();
  return {
    name: 'Sri Mayapur Chandrodaya Mandir',
    city: 'Mayapur',
    country: 'India',
    tradition: 'ISKCON_MAYAPUR',
    adminUid,
    mangalAartiTime: '04:30',
    darshanAartiTime: '07:00',
    bhagavatamClassTime: '07:45',
    sandhyaAartiTime: '19:00',
    description: 'World headquarters pilgrimage temple.',
    liveStreamUrl: 'https://www.mayapur.tv',
    visibility: 'PUBLIC',
    createdAt: ts,
    updatedAt: ts,
    ...overrides,
  };
}

function validTemplePost(templeId, authorUid, overrides = {}) {
  const ts = pastDate();
  return {
    templeId,
    authorUid,
    authorName: 'Temple Servant',
    postType: 'SEVA',
    title: 'Sunday Feast Prasadam Seva',
    body: 'Join us in serving devotees at the Sunday Love Feast.',
    eventDateKey: '2026-05-17',
    eventTime: '17:00',
    visibility: 'PUBLIC',
    volunteerUids: [],
    createdAt: ts,
    updatedAt: ts,
    ...overrides,
  };
}

describe('Sadhya Firestore Security Rules', () => {
  before(async () => {
    testEnv = await initializeTestEnvironment({
      projectId: PROJECT_ID,
      firestore: {
        rules: fs.readFileSync('firestore.rules', 'utf8'),
        host: '127.0.0.1',
        port: 8085,
      },
    });
  });

  after(async () => {
    if (testEnv) {
      await testEnv.cleanup();
    }
  });

  beforeEach(async () => {
    await testEnv.clearFirestore();
  });

  it('denies unauthenticated access to all collections', async () => {
    const anonDb = testEnv.unauthenticatedContext().firestore();
    await assertFails(anonDb.collection('users').doc(ALICE_UID).get());
    await assertFails(anonDb.collection('users').doc(ALICE_UID).set(validUserProfile(ALICE_UID)));
    await assertFails(anonDb.collection('temples').where('visibility', '==', 'PUBLIC').get());
    await assertFails(anonDb.collection('unknown_col').doc('doc1').get());
  });

  it('enforces owner-only UserProfile CRUD, immutability, bounds, and no user listing', async () => {
    const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
    const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

    // Create own profile
    await assertSucceeds(aliceDb.collection('users').doc(ALICE_UID).set(validUserProfile(ALICE_UID)));

    // Owner get succeeds; listing users denied; cross-user read/write denied
    await assertSucceeds(aliceDb.collection('users').doc(ALICE_UID).get());
    await assertFails(aliceDb.collection('users').get());
    await assertFails(bobDb.collection('users').doc(ALICE_UID).get());
    await assertFails(bobDb.collection('users').doc(ALICE_UID).update({ displayName: 'Tampered', updatedAt: pastDate(500) }));

    // Partial update of allowlisted keys succeeds
    await assertSucceeds(
      aliceDb.collection('users').doc(ALICE_UID).update({
        displayName: 'Srimati Radha Dasi',
        japaTargetRounds: 24,
        onboardingCompleted: true,
        updatedAt: pastDate(500),
      })
    );

    // Immutable userId / createdAt tampering rejected
    await assertFails(
      aliceDb.collection('users').doc(ALICE_UID).update({
        userId: BOB_UID,
        updatedAt: pastDate(400),
      })
    );
    await assertFails(
      aliceDb.collection('users').doc(ALICE_UID).update({
        createdAt: pastDate(100),
        updatedAt: pastDate(100),
      })
    );

    // Out-of-bounds japaTargetRounds & tampered future timestamp rejected
    await assertFails(
      aliceDb.collection('users').doc(ALICE_UID).update({
        japaTargetRounds: 500,
        updatedAt: pastDate(300),
      })
    );
    await assertFails(
      aliceDb.collection('users').doc(ALICE_UID).update({
        displayName: 'Future Test',
        updatedAt: futureDate(),
      })
    );

    // Owner delete succeeds
    await assertSucceeds(aliceDb.collection('users').doc(ALICE_UID).delete());
  });

  it('enforces owner-only ScheduleItem, DailyTask, SadhanaDailyLog, and append-only FocusLog CRUD', async () => {
    const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
    const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

    // ScheduleItem
    const schedRef = aliceDb.collection('users').doc(ALICE_UID).collection('schedule_items').doc('starter_1');
    await assertSucceeds(schedRef.set(validScheduleItem()));
    await assertSucceeds(aliceDb.collection('users').doc(ALICE_UID).collection('schedule_items').get());
    await assertSucceeds(schedRef.update({ completedDateKey: '2026-05-15', updatedAt: pastDate(500) }));
    await assertFails(bobDb.collection('users').doc(ALICE_UID).collection('schedule_items').doc('starter_1').get());
    await assertFails(schedRef.update({ startTime: '99:99', updatedAt: pastDate(400) }));

    // DailyTask
    const taskRef = aliceDb.collection('users').doc(ALICE_UID).collection('tasks').doc('task_01');
    await assertSucceeds(taskRef.set(validDailyTask()));
    await assertSucceeds(taskRef.update({ completed: true, updatedAt: pastDate(500) }));
    await assertFails(bobDb.collection('users').doc(ALICE_UID).collection('tasks').get());

    // SadhanaDailyLog (dateKey YYYY-MM-DD enforced)
    const logRef = aliceDb.collection('users').doc(ALICE_UID).collection('sadhana_logs').doc('2026-05-15');
    await assertSucceeds(logRef.set(validSadhanaLog()));
    await assertSucceeds(logRef.update({ japaRounds: 18, updatedAt: pastDate(500) }));
    await assertFails(
      aliceDb.collection('users').doc(ALICE_UID).collection('sadhana_logs').doc('invalid_date').set(validSadhanaLog())
    );

    // FocusLog (append-only: create + list + delete allowed, update denied)
    const focusRef = aliceDb.collection('users').doc(ALICE_UID).collection('focus_logs').doc('focus_01');
    await assertSucceeds(focusRef.set(validFocusLog()));
    await assertSucceeds(
      aliceDb.collection('users').doc(ALICE_UID).collection('focus_logs').orderBy('createdAt', 'desc').limit(30).get()
    );
    await assertFails(focusRef.update({ outcome: 'GRANTED_EXCEPTION' }));
    await assertSucceeds(focusRef.delete());
  });

  it('enforces TempleCommunity & TemplePost visibility queries, admin writes, and atomic SEVA self-volunteer toggle', async () => {
    const adminDb = testEnv.authenticatedContext(ADMIN_UID).firestore();
    const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
    const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();

    // Admin registers temple with visibility == PUBLIC
    await assertSucceeds(adminDb.collection('temples').doc(TEMPLE_ID).set(validTemple(ADMIN_UID)));

    // Filtered PUBLIC query succeeds; unfiltered list fails
    await assertSucceeds(aliceDb.collection('temples').where('visibility', '==', 'PUBLIC').get());
    await assertFails(aliceDb.collection('temples').get());

    // Non-admin cannot edit temple or create posts
    await assertFails(
      aliceDb.collection('temples').doc(TEMPLE_ID).update({ city: 'Tampered', updatedAt: pastDate(500) })
    );
    await assertFails(
      aliceDb.collection('temples').doc(TEMPLE_ID).collection('posts').doc(POST_SEVA_ID)
        .set(validTemplePost(TEMPLE_ID, ALICE_UID))
    );

    // Admin creates SEVA and ANNOUNCEMENT posts
    await assertSucceeds(
      adminDb.collection('temples').doc(TEMPLE_ID).collection('posts').doc(POST_SEVA_ID)
        .set(validTemplePost(TEMPLE_ID, ADMIN_UID, { postType: 'SEVA' }))
    );
    await assertSucceeds(
      adminDb.collection('temples').doc(TEMPLE_ID).collection('posts').doc(POST_ANN_ID)
        .set(validTemplePost(TEMPLE_ID, ADMIN_UID, { postType: 'ANNOUNCEMENT', title: 'Ekadashi Notice' }))
    );

    // Filtered PUBLIC posts query succeeds; unfiltered posts list fails
    await assertSucceeds(
      aliceDb.collection('temples').doc(TEMPLE_ID).collection('posts').where('visibility', '==', 'PUBLIC').get()
    );
    await assertFails(
      aliceDb.collection('temples').doc(TEMPLE_ID).collection('posts').get()
    );

    // Non-admin Alice atomically adds ONLY her own UID to SEVA post
    const aliceSevaRef = aliceDb.collection('temples').doc(TEMPLE_ID).collection('posts').doc(POST_SEVA_ID);
    await assertSucceeds(
      aliceSevaRef.update({ volunteerUids: [ALICE_UID], updatedAt: pastDate(500) })
    );

    // Non-admin Bob adds ONLY his own UID while preserving Alice
    const bobSevaRef = bobDb.collection('temples').doc(TEMPLE_ID).collection('posts').doc(POST_SEVA_ID);
    await assertSucceeds(
      bobSevaRef.update({ volunteerUids: [ALICE_UID, BOB_UID], updatedAt: pastDate(400) })
    );

    // Bob CANNOT remove Alice or tamper with title
    await assertFails(
      bobSevaRef.update({ volunteerUids: [BOB_UID], updatedAt: pastDate(300) })
    );
    await assertFails(
      bobSevaRef.update({ volunteerUids: [ALICE_UID], title: 'Hacked', updatedAt: pastDate(300) })
    );

    // Non-admin Bob can remove ONLY his own UID
    await assertSucceeds(
      bobSevaRef.update({ volunteerUids: [ALICE_UID], updatedAt: pastDate(200) })
    );

    // Self-volunteer toggle is DENIED on non-SEVA (ANNOUNCEMENT) posts
    await assertFails(
      aliceDb.collection('temples').doc(TEMPLE_ID).collection('posts').doc(POST_ANN_ID)
        .update({ volunteerUids: [ALICE_UID], updatedAt: pastDate(100) })
    );
  });
});
