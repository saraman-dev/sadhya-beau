package com.example.focus

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.PreferencesManager
import com.example.data.local.SadhanaLocalDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

class FocusMonitorService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var monitorJob: Job? = null
    private var lastInterruptedPackage: String = ""
    private var lastInterruptTimeMs: Long = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAndCleanup()
            return START_NOT_STICKY
        }

        ensureChannels()
        val durationMin = intent?.getIntExtra(EXTRA_DURATION_MIN, 45) ?: 45
        val strictness = intent?.getStringExtra(EXTRA_STRICTNESS) ?: "BALANCED"
        val endEpoch = intent?.getLongExtra(
            EXTRA_END_EPOCH,
            System.currentTimeMillis() + durationMin * 60_000L
        ) ?: (System.currentTimeMillis() + durationMin * 60_000L)

        val notification = buildOngoingNotification(endEpoch)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        startMonitoring(endEpoch, strictness)
        return START_STICKY
    }

    private fun startMonitoring(endEpochMs: Long, strictness: String) {
        monitorJob?.cancel()
        val prefs = PreferencesManager(applicationContext)
        val db = SadhanaLocalDatabase.getInstance(applicationContext)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        monitorJob = serviceScope.launch {
            while (isActive) {
                val now = System.currentTimeMillis()
                if (now >= endEpochMs) {
                    prefs.setFocusShieldState(active = false, endEpochMs = 0L)
                    stopSelf()
                    break
                }

                // Update countdown notification
                nm.notify(NOTIFICATION_ID, buildOngoingNotification(endEpochMs))

                // Check foreground app if Usage Access is granted
                val fgPkg = UsageStatsHelper.queryForegroundPackageName(applicationContext)
                if (fgPkg != null && fgPkg != packageName) {
                    val rules = db.focusRuleDao().getAllRulesSnapshot()
                    val matchedRule = rules.firstOrNull {
                        it.packageName == fgPkg &&
                            it.blockDuringFocus &&
                            it.exceptionUntilMillis < now
                    }
                    if (matchedRule != null) {
                        val cooldownElapsed = (fgPkg != lastInterruptedPackage) || (now - lastInterruptTimeMs > 8_000L)
                        if (cooldownElapsed) {
                            lastInterruptedPackage = fgPkg
                            lastInterruptTimeMs = now
                            triggerMindfulPause(matchedRule.packageName, matchedRule.appLabel, strictness)
                        }
                    }
                }
                delay(2000L)
            }
        }
    }

    private fun triggerMindfulPause(blockedPackage: String, appLabel: String, strictness: String) {
        val pauseIntent = Intent(applicationContext, FocusInterruptionActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(FocusInterruptionActivity.EXTRA_PACKAGE, blockedPackage)
            putExtra(FocusInterruptionActivity.EXTRA_APP_LABEL, appLabel)
            putExtra(FocusInterruptionActivity.EXTRA_STRICTNESS, strictness)
        }

        // Android 10+ requires SYSTEM_ALERT_WINDOW to launch an activity from background service
        if (UsageStatsHelper.hasOverlayPermission(applicationContext)) {
            try {
                startActivity(pauseIntent)
                return
            } catch (_: Exception) {
                // Fall through to notification fallback
            }
        }

        // Graceful Notification Fallback when Display Over Other Apps isn't granted
        val pi = PendingIntent.getActivity(
            applicationContext,
            9202,
            pauseIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val fallbackNotif = NotificationCompat.Builder(applicationContext, CHANNEL_PAUSE_ALERT)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Mindful Pause — $appLabel")
            .setContentText("Your Sadhana Focus Shield is active. Tap to pause mindfully or return to Sadhya.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        nm.notify(9202, fallbackNotif)
    }

    private fun buildOngoingNotification(endEpochMs: Long): Notification {
        val remainingSec = ((endEpochMs - System.currentTimeMillis()) / 1000L).coerceAtLeast(0L)
        val mm = remainingSec / 60
        val ss = remainingSec % 60
        val formatted = String.format(Locale.US, "%02d:%02d", mm, ss)

        val openPi = PendingIntent.getActivity(
            this,
            9200,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopPi = PendingIntent.getService(
            this,
            9201,
            Intent(this, FocusMonitorService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_FOCUS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Sadhya Focus Shield Active")
            .setContentText("Remaining: $formatted • Protecting your peaceful Sadhana")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openPi)
            .addAction(0, "End Session", stopPi)
            .build()
    }

    private fun stopAndCleanup() {
        monitorJob?.cancel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        val prefs = PreferencesManager(applicationContext)
        serviceScope.launch {
            prefs.setFocusShieldState(active = false, endEpochMs = 0L)
            stopSelf()
        }
    }

    private fun ensureChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_FOCUS,
                    "Sadhya Focus Shield",
                    NotificationManager.IMPORTANCE_LOW
                )
            )
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_PAUSE_ALERT,
                    "Mindful Pause Reminders",
                    NotificationManager.IMPORTANCE_HIGH
                )
            )
        }
    }

    override fun onDestroy() {
        monitorJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.example.focus.ACTION_START"
        const val ACTION_STOP = "com.example.focus.ACTION_STOP"
        const val EXTRA_DURATION_MIN = "extra_duration_min"
        const val EXTRA_END_EPOCH = "extra_end_epoch"
        const val EXTRA_STRICTNESS = "extra_strictness"
        private const val CHANNEL_FOCUS = "sadhya_focus_shield"
        private const val CHANNEL_PAUSE_ALERT = "sadhya_mindful_pause"
        private const val NOTIFICATION_ID = 9200

        fun start(context: Context, durationMinutes: Int, endEpochMs: Long, strictness: String) {
            val intent = Intent(context, FocusMonitorService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_DURATION_MIN, durationMinutes)
                putExtra(EXTRA_END_EPOCH, endEpochMs)
                putExtra(EXTRA_STRICTNESS, strictness)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (_: Exception) {
                // Gracefully fall back to in-app timer if OS blocks foreground service start
            }
        }

        fun stop(context: Context) {
            try {
                context.stopService(Intent(context, FocusMonitorService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
