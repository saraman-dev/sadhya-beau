package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.WindowManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.SadhanaDailyLog
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.ui.components.ResponsiveContentColumn
import com.example.ui.components.SectionHeader
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.viewmodel.SadhanaViewModel
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SadhanaMediaScreen(
    viewModel: SadhanaViewModel,
    profile: UserProfile
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val localPrefs by viewModel.localPrefs.collectAsStateWithLifecycle()
    val logsState by viewModel.sadhanaLogsState.collectAsStateWithLifecycle()
    val audioState by viewModel.audioState.collectAsStateWithLifecycle()
    val completedPulse by viewModel.japaRoundCompletedPulse.collectAsStateWithLifecycle()

    val todayKey = viewModel.todayKey()
    val allLogs = (logsState as? UiState.Success)?.data.orEmpty()
    val todayLog = allLogs.firstOrNull { it.dateKey == todayKey } ?: SadhanaDailyLog(dateKey = todayKey)

    var showFocusedJapaOverlay by remember { mutableStateOf(false) }
    var showEditLogDialog by remember { mutableStateOf(false) }
    var showSevaDialog by remember { mutableStateOf(false) }

    // Distinct celebratory haptic pulse on completing bead 108
    LaunchedEffect(completedPulse) {
        if (completedPulse > 0) {
            try {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Vibrator::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(
                        VibrationEffect.createWaveform(longArrayOf(0, 70, 60, 120), -1)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(longArrayOf(0, 70, 60, 120), -1)
                }
            } catch (_: Exception) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }
        }
    }

    // Keep screen on when Focused Japa overlay is open and toggle is enabled
    DisposableEffect(showFocusedJapaOverlay, localPrefs.keepScreenOnJapa) {
        val activity = context as? Activity
        if (showFocusedJapaOverlay && localPrefs.keepScreenOnJapa) {
            activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    ResponsiveContentColumn {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Circular 108-Bead Japa Mala Card
            item {
                val primaryColor = MaterialTheme.colorScheme.primary
                val secondaryColor = MaterialTheme.colorScheme.secondary
                val trackColor = MaterialTheme.colorScheme.outlineVariant

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(18.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("108-Bead Japa Mala", style = MaterialTheme.typography.headlineSmall)
                                Text(
                                    "Rounds Today: ${todayLog.japaRounds} / ${profile.japaTargetRounds}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Row {
                                IconButton(
                                    onClick = { showFocusedJapaOverlay = true },
                                    modifier = Modifier.testTag("open_focused_japa_button")
                                ) {
                                    Icon(Icons.Default.Fullscreen, contentDescription = "Focused Japa mode")
                                }
                                IconButton(
                                    onClick = { showEditLogDialog = true },
                                    modifier = Modifier.testTag("edit_today_log_button")
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit today's log")
                                }
                            }
                        }

                        // Interactive 108-bead Mala Tap Circle
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(if (localPrefs.elderModeEnabled) 256.dp else 224.dp)
                                .clip(RoundedCornerShape(50))
                                .testTag("japa_mala_tap_area")
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    viewModel.tapJapaBead()
                                }
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize().padding(10.dp)) {
                                val radius = size.minDimension / 2f - 10f
                                val center = Offset(size.width / 2f, size.height / 2f)
                                drawCircle(
                                    color = trackColor.copy(alpha = 0.4f),
                                    radius = radius,
                                    center = center,
                                    style = Stroke(width = 2.dp.toPx())
                                )
                                // Draw 36 representative mala beads (each represents 3 beads) + smooth arc
                                val progress = localPrefs.japaBeadCount / 108f
                                drawArc(
                                    color = primaryColor,
                                    startAngle = -90f,
                                    sweepAngle = progress * 360f,
                                    useCenter = false,
                                    topLeft = Offset(center.x - radius, center.y - radius),
                                    size = Size(radius * 2, radius * 2),
                                    style = Stroke(width = 6.dp.toPx())
                                )
                                val visualBeads = 36
                                val filledVisual = (progress * visualBeads).toInt()
                                for (i in 0 until visualBeads) {
                                    val angleRad = (-90.0 + i * (360.0 / visualBeads)) * PI / 180.0
                                    val bx = center.x + (radius * cos(angleRad)).toFloat()
                                    val by = center.y + (radius * sin(angleRad)).toFloat()
                                    drawCircle(
                                        color = if (i < filledVisual) secondaryColor else trackColor,
                                        radius = if (i == 0) 5.5.dp.toPx() else 3.2.dp.toPx(),
                                        center = Offset(bx, by)
                                    )
                                }
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${localPrefs.japaBeadCount}",
                                    style = MaterialTheme.typography.displayLarge.copy(fontFamily = JetBrainsMonoFamily),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "of 108 beads",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "Tap to Chant",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                        }

                        Text(
                            text = "Each round is logged automatically only when all 108 beads are chanted.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )

                        // Controls: Undo last bead or Reset current mala (no manual round-skipping)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { viewModel.undoJapaBead() },
                                enabled = localPrefs.japaBeadCount > 0,
                                modifier = Modifier.weight(1f).testTag("japa_undo_button")
                            ) {
                                Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("-1 Bead")
                            }
                            OutlinedButton(
                                onClick = { viewModel.resetJapaBeads() },
                                enabled = localPrefs.japaBeadCount > 0,
                                modifier = Modifier.weight(1f).testTag("japa_reset_button")
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Reset Mala")
                            }
                        }
                    }
                }
            }

            // 2. Daily Sadhana Check-ins (Reading, Hearing, Mangal Aarti, Sandhya, Puja, Seva)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Daily Sadhana Pillars", style = MaterialTheme.typography.headlineSmall)

                        // Reading & Hearing Quick Counters
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Reading", style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "${todayLog.readingMinutes} / ${profile.readingTargetMinutes} min",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                    Button(
                                        onClick = {
                                            viewModel.updateTodaySadhanaLog(
                                                { it.copy(readingMinutes = it.readingMinutes + 15) },
                                                "+15 min reading logged"
                                            )
                                        },
                                        modifier = Modifier.fillMaxWidth().testTag("add_reading_15m_button")
                                    ) { Text("+15 min") }
                                }
                            }

                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Hearing", style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "${todayLog.hearingMinutes} / ${profile.hearingTargetMinutes} min",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                    Button(
                                        onClick = {
                                            viewModel.updateTodaySadhanaLog(
                                                { it.copy(hearingMinutes = it.hearingMinutes + 15) },
                                                "+15 min hearing logged"
                                            )
                                        },
                                        modifier = Modifier.fillMaxWidth().testTag("add_hearing_15m_button")
                                    ) { Text("+15 min") }
                                }
                            }
                        }

                        // Mangal Aarti & Altar Puja
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Mangal Aarti Attended", style = MaterialTheme.typography.bodyLarge)
                            Switch(
                                checked = todayLog.mangalAartiAttended,
                                onCheckedChange = { checked ->
                                    viewModel.updateTodaySadhanaLog({ it.copy(mangalAartiAttended = checked) })
                                }
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Home Altar Puja / Tulasi Offering", style = MaterialTheme.typography.bodyLarge)
                            Switch(
                                checked = todayLog.pujaDone,
                                onCheckedChange = { checked ->
                                    viewModel.updateTodaySadhanaLog({ it.copy(pujaDone = checked) })
                                }
                            )
                        }

                        // Discreet Gayatri Sandhya Check-Ins (Zero mantra text ever shown)
                        if (profile.gayatriInitiated) {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Discreet Sandhya Check-In", style = MaterialTheme.typography.titleSmall)
                                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Checkbox(
                                                checked = todayLog.gayatriMorningDone,
                                                onCheckedChange = { v -> viewModel.updateTodaySadhanaLog({ it.copy(gayatriMorningDone = v) }) }
                                            )
                                            Text("Morning", style = MaterialTheme.typography.bodySmall)
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Checkbox(
                                                checked = todayLog.gayatriAfternoonDone,
                                                onCheckedChange = { v -> viewModel.updateTodaySadhanaLog({ it.copy(gayatriAfternoonDone = v) }) }
                                            )
                                            Text("Midday", style = MaterialTheme.typography.bodySmall)
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Checkbox(
                                                checked = todayLog.gayatriEveningDone,
                                                onCheckedChange = { v -> viewModel.updateTodaySadhanaLog({ it.copy(gayatriEveningDone = v) }) }
                                            )
                                            Text("Evening", style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }

                        // Optional Daily Regulative Principles Check-In (Stored locally in DataStore)
                        val vowsToday = localPrefs.regulativeVowsDateKey == todayKey
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text("Optional Daily Regulative Vows (Private On-Device)", style = MaterialTheme.typography.titleSmall)
                                val vowLabels = listOf(
                                    "Sattvic vegetarian diet (Ahimsa)",
                                    "Clarity & no intoxication",
                                    "Truthfulness & no gambling",
                                    "Cleanliness & peaceful self-restraint"
                                )
                                val vowValues = listOf(
                                    vowsToday && localPrefs.vowNoMeat,
                                    vowsToday && localPrefs.vowNoIntoxication,
                                    vowsToday && localPrefs.vowNoGambling,
                                    vowsToday && localPrefs.vowCleanLiving
                                )
                                vowLabels.forEachIndexed { idx, label ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(
                                            checked = vowValues[idx],
                                            onCheckedChange = { viewModel.setDailyVow(idx, it) }
                                        )
                                        Text(label, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }

                        // Personal Seva Logger
                        OutlinedButton(
                            onClick = { showSevaDialog = true },
                            modifier = Modifier.fillMaxWidth().testTag("log_seva_button")
                        ) {
                            Text(
                                if (todayLog.sevaMinutes > 0) "Personal Seva Logged: ${todayLog.sevaMinutes}m (${todayLog.sevaNote.ifBlank { "Update" }})"
                                else "+ Log Personal Seva Today"
                            )
                        }
                    }
                }
            }

            // 3. 7-Day Japa Consistency Chart with Goal Line
            item {
                val primaryColor = MaterialTheme.colorScheme.primary
                val secondaryColor = MaterialTheme.colorScheme.secondary
                val outlineColor = MaterialTheme.colorScheme.outline

                val last7 = remember(allLogs, todayKey, profile.timezoneId) {
                    val map = allLogs.associateBy { it.dateKey }
                    val tz = java.util.TimeZone.getTimeZone(profile.timezoneId.ifBlank { "Asia/Kolkata" })
                    val cal = java.util.Calendar.getInstance(tz)
                    val keyFmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).apply { timeZone = tz }
                    val dayFmt = java.text.SimpleDateFormat("EE", java.util.Locale.US).apply { timeZone = tz }
                    (6 downTo 0).map { offset ->
                        val c = (cal.clone() as java.util.Calendar).apply { add(java.util.Calendar.DAY_OF_YEAR, -offset) }
                        val key = keyFmt.format(c.time)
                        val dayLabel = dayFmt.format(c.time).take(2)
                        dayLabel to (map[key]?.japaRounds?.toInt() ?: 0)
                    }
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionHeader("7-Day Japa Rhythm", "Goal line: ${profile.japaTargetRounds} rounds")
                        val goal = profile.japaTargetRounds.toFloat().coerceAtLeast(1f)
                        val maxVal = maxOf(goal, (last7.maxOfOrNull { it.second } ?: 16).toFloat(), 4f)

                        Canvas(modifier = Modifier.fillMaxWidth().height(130.dp)) {
                            val barCount = last7.size
                            val slotWidth = size.width / barCount
                            val barWidth = slotWidth * 0.52f
                            val chartH = size.height - 12.dp.toPx()

                            // Dashed Goal Line
                            val goalY = chartH * (1f - (goal / maxVal))
                            drawLine(
                                color = secondaryColor,
                                start = Offset(0f, goalY),
                                end = Offset(size.width, goalY),
                                strokeWidth = 2.dp.toPx(),
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f))
                            )

                            last7.forEachIndexed { idx, (_, rounds) ->
                                val barH = (rounds / maxVal) * chartH
                                val left = idx * slotWidth + (slotWidth - barWidth) / 2f
                                val top = chartH - barH
                                drawRoundRect(
                                    color = if (rounds >= goal) primaryColor else outlineColor.copy(alpha = 0.55f),
                                    topLeft = Offset(left, top),
                                    size = Size(barWidth, barH.coerceAtLeast(4f)),
                                    cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
                                )
                            }
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                            last7.forEach { (dayLabel, rounds) ->
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("$rounds", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                    Text(dayLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }

            // 4. Devotional Media Hub (Offline Tanpura + Portals)
            item {
                SectionHeader("Devotional Audio & Media Hub", "Ad-free offline Tanpura + sacred listening portals")
                Spacer(Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(20.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_kirtan_banner),
                        contentDescription = "Mridanga and kartals kirtan sanctuary",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC240B10))))
                    )
                    Column(modifier = Modifier.align(Alignment.BottomStart).padding(14.dp)) {
                        Text("Built-In Offline Sa–Pa–Sa Tanpura", style = MaterialTheme.typography.titleMedium, color = Color(0xFFFFF8EE))
                        Text("Synthesized 100% on-device • Credits hearing automatically once daily", style = MaterialTheme.typography.bodySmall, color = Color(0xFFF2DFC7))
                    }
                }
            }

            items(viewModel.audioPlayer.builtInTanpuraTracks.size) { index ->
                val track = viewModel.audioPlayer.builtInTanpuraTracks[index]
                val isThisPlaying = audioState.currentTrack?.id == track.id && audioState.isPlaying
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("tanpura_track_${track.id}"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isThisPlaying) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(track.title, style = MaterialTheme.typography.titleSmall)
                            Text(track.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { viewModel.audioPlayer.toggleTrack(track) }) {
                            Icon(
                                imageVector = if (isThisPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isThisPlaying) "Pause" else "Play",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            item {
                Text("Sacred Portals & Live Darshan", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 4.dp))
            }

            items(viewModel.audioPlayer.devotionalPortals.size) { idx ->
                val portal = viewModel.audioPlayer.devotionalPortals[idx]
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.creditPortalVisit(portal)
                            try {
                                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(portal.portalUrl)))
                            } catch (_: Exception) {
                                viewModel.showToast("Visit ${portal.portalUrl}")
                            }
                        },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(portal.title, style = MaterialTheme.typography.titleSmall)
                            Text(portal.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(Icons.Default.OpenInNew, contentDescription = "Open ${portal.title}", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    // Focused Japa Fullscreen Overlay (KEEP_SCREEN_ON + Generous Tap Area)
    if (showFocusedJapaOverlay) {
        Dialog(
            onDismissRequest = { showFocusedJapaOverlay = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                Column(
                    modifier = Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Keep Screen On", style = MaterialTheme.typography.labelLarge)
                            Spacer(Modifier.width(8.dp))
                            Switch(
                                checked = localPrefs.keepScreenOnJapa,
                                onCheckedChange = { viewModel.setKeepScreenOnJapa(it) }
                            )
                        }
                        IconButton(onClick = { showFocusedJapaOverlay = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Close Focused Japa")
                        }
                    }

                    // Generous Full-Center Tap Target
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(vertical = 18.dp)
                            .testTag("focused_japa_tap_zone")
                            .clickable {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                viewModel.tapJapaBead()
                            },
                        shape = RoundedCornerShape(32.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                        border = BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "Round ${todayLog.japaRounds + 1} of ${profile.japaTargetRounds}",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(Modifier.height(14.dp))
                            Text(
                                text = "${localPrefs.japaBeadCount} / 108",
                                style = MaterialTheme.typography.displayLarge.copy(fontFamily = JetBrainsMonoFamily),
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(Modifier.height(14.dp))
                            Text(
                                text = "Tap anywhere in this sacred space for each bead.\nA gentle celebratory vibration marks bead 108.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { viewModel.undoJapaBead() }, modifier = Modifier.weight(1f)) {
                            Text("-1 Bead")
                        }
                        OutlinedButton(onClick = { viewModel.resetJapaBeads() }, modifier = Modifier.weight(1f)) {
                            Text("Reset Mala")
                        }
                    }
                }
            }
        }
    }

    // Edit Today's Log Dialog (Reading, Hearing & Reflection only — Japa rounds are earned exclusively via 108 beads)
    if (showEditLogDialog) {
        var readStr by remember(todayLog) { mutableStateOf(todayLog.readingMinutes.toString()) }
        var hearStr by remember(todayLog) { mutableStateOf(todayLog.hearingMinutes.toString()) }
        var note by remember(todayLog) { mutableStateOf(todayLog.reflectionNote) }

        AlertDialog(
            onDismissRequest = { showEditLogDialog = false },
            title = { Text("Edit Today's Sadhana Log") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Japa Rounds Today: ${todayLog.japaRounds} (logged strictly by completing 108 beads)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    OutlinedTextField(value = readStr, onValueChange = { readStr = it.filter(Char::isDigit).take(3) }, label = { Text("Reading Minutes") })
                    OutlinedTextField(value = hearStr, onValueChange = { hearStr = it.filter(Char::isDigit).take(3) }, label = { Text("Hearing Minutes") })
                    OutlinedTextField(value = note, onValueChange = { note = it.take(400) }, label = { Text("Daily Reflection Note") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.updateTodaySadhanaLog(
                        {
                            it.copy(
                                readingMinutes = (readStr.toLongOrNull() ?: it.readingMinutes).coerceIn(0L, 720L),
                                hearingMinutes = (hearStr.toLongOrNull() ?: it.hearingMinutes).coerceIn(0L, 720L),
                                reflectionNote = note.trim()
                            )
                        },
                        "Today's Sadhana log updated"
                    )
                    showEditLogDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showEditLogDialog = false }) { Text("Cancel") } }
        )
    }

    // Personal Seva Dialog
    if (showSevaDialog) {
        var sevaMinStr by remember(todayLog) { mutableStateOf(todayLog.sevaMinutes.takeIf { it > 0 }?.toString() ?: "30") }
        var sevaNote by remember(todayLog) { mutableStateOf(todayLog.sevaNote) }
        AlertDialog(
            onDismissRequest = { showSevaDialog = false },
            title = { Text("Log Personal Seva") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(value = sevaMinStr, onValueChange = { sevaMinStr = it.filter(Char::isDigit).take(3) }, label = { Text("Duration (minutes)") })
                    OutlinedTextField(value = sevaNote, onValueChange = { sevaNote = it.take(300) }, label = { Text("Service offered (e.g., Cooking prasadam, temple cleaning)") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.updateTodaySadhanaLog(
                        {
                            it.copy(
                                sevaMinutes = (sevaMinStr.toLongOrNull() ?: 30L).coerceIn(0L, 720L),
                                sevaNote = sevaNote.trim()
                            )
                        },
                        "Seva logged gratefully"
                    )
                    showSevaDialog = false
                }) { Text("Save Seva") }
            },
            dismissButton = { TextButton(onClick = { showSevaDialog = false }) { Text("Cancel") } }
        )
    }
}
