package com.example.focus

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.MainActivity
import com.example.data.local.SadhanaLocalDatabase
import com.example.model.FocusStrictness
import com.example.ui.theme.SadhyaTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class FocusInterruptionActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val blockedPkg = intent.getStringExtra(EXTRA_PACKAGE) ?: "com.instagram.android"
        val appLabel = intent.getStringExtra(EXTRA_APP_LABEL) ?: "Distracting App"
        val strictness = FocusStrictness.fromRaw(intent.getStringExtra(EXTRA_STRICTNESS))

        setContent {
            SadhyaTheme {
                MindfulPauseScreen(
                    appLabel = appLabel,
                    strictness = strictness,
                    onReturnToSadhana = {
                        val backIntent = Intent(this, MainActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        }
                        startActivity(backIntent)
                        finish()
                    },
                    onGrantException = { reason ->
                        val db = SadhanaLocalDatabase.getInstance(applicationContext)
                        val untilMs = System.currentTimeMillis() + 5 * 60_000L
                        CoroutineScope(Dispatchers.IO).launch {
                            db.focusRuleDao().setExceptionUntil(blockedPkg, untilMs)
                        }
                        finish()
                    }
                )
            }
        }
    }

    companion object {
        const val EXTRA_PACKAGE = "extra_package"
        const val EXTRA_APP_LABEL = "extra_app_label"
        const val EXTRA_STRICTNESS = "extra_strictness"
    }
}

@Composable
private fun MindfulPauseScreen(
    appLabel: String,
    strictness: FocusStrictness,
    onReturnToSadhana: () -> Unit,
    onGrantException: (String) -> Unit
) {
    var secondsLeft by remember { mutableIntStateOf(strictness.waitSeconds) }
    var reasonText by remember { mutableStateOf("") }

    LaunchedEffect(strictness) {
        while (secondsLeft > 0) {
            delay(1000L)
            secondsLeft--
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.SelfImprovement,
                contentDescription = "Mindful Pause",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(56.dp)
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = "Mindful Pause",
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "What were you supposed to be doing?",
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "You opened $appLabel during an active Sadhana Focus Shield (${strictness.label}). Take a gentle breath and choose mindfully.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(24.dp))

            Button(
                onClick = onReturnToSadhana,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("return_to_sadhana_button")
            ) {
                Text("Return to Sadhana")
            }

            Spacer(Modifier.height(20.dp))

            if (strictness.allowsBypass) {
                if (strictness == FocusStrictness.BALANCED) {
                    OutlinedTextField(
                        value = reasonText,
                        onValueChange = { reasonText = it.take(160) },
                        label = { Text("Brief mindful reason (required)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(12.dp))
                }

                val canProceed = secondsLeft == 0 &&
                    (strictness == FocusStrictness.GENTLE || reasonText.trim().length >= 3)

                OutlinedButton(
                    onClick = { onGrantException(reasonText.trim()) },
                    enabled = canProceed,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("mindful_exception_button")
                ) {
                    Text(
                        if (secondsLeft > 0) "Pause Mindfully (${secondsLeft}s)"
                        else "Allow 5-Minute Exception"
                    )
                }
            } else {
                Text(
                    text = if (secondsLeft > 0) {
                        "Strict mode active (${secondsLeft}s calm breath). Emergency bypass is disabled during this session."
                    } else {
                        "Strict mode protects this entire session without bypass. You can end the session inside Sadhya if truly urgent."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
