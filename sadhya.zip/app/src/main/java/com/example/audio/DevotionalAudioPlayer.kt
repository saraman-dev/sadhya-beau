package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

data class DevotionalTrack(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String,
    val baseFrequencyHz: Double = 138.59, // C#3 default
    val portalUrl: String = "",
    val creditMinutes: Int = 10,
    val isBuiltInTanpura: Boolean = false
)

data class AudioPlaybackState(
    val currentTrack: DevotionalTrack? = null,
    val isPlaying: Boolean = false,
    val elapsedSeconds: Int = 0,
    val statusMessage: String = ""
)

class DevotionalAudioPlayer(
    private val onHearingCreditEarned: (trackId: String, minutes: Int) -> Unit = { _, _ -> }
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var synthJob: Job? = null
    private var timerJob: Job? = null
    private var audioTrack: AudioTrack? = null

    private val _state = MutableStateFlow(AudioPlaybackState())
    val state: StateFlow<AudioPlaybackState> = _state.asStateFlow()

    val builtInTanpuraTracks: List<DevotionalTrack> = listOf(
        DevotionalTrack(
            id = "tanpura_c_sharp",
            title = "Sa–Pa–Sa Tanpura (C# / Kali 1)",
            subtitle = "100% offline ad-free meditative drone for Japa & morning reading",
            category = "Offline Tanpura",
            baseFrequencyHz = 138.59,
            creditMinutes = 10,
            isBuiltInTanpura = true
        ),
        DevotionalTrack(
            id = "tanpura_d_natural",
            title = "Sa–Pa–Sa Tanpura (D / Safed 2)",
            subtitle = "Warm temple harmonium pitch for Kirtan & Tulasi Puja",
            category = "Offline Tanpura",
            baseFrequencyHz = 146.83,
            creditMinutes = 10,
            isBuiltInTanpura = true
        ),
        DevotionalTrack(
            id = "tanpura_g_scale",
            title = "Sa–Pa–Sa Tanpura (G / Calm Evening)",
            subtitle = "Gentle resonant shruti for evening Bhagavatam & Sandhya",
            category = "Offline Tanpura",
            baseFrequencyHz = 196.00,
            creditMinutes = 10,
            isBuiltInTanpura = true
        )
    )

    val devotionalPortals: List<DevotionalTrack> = listOf(
        DevotionalTrack(
            id = "portal_mayapur_tv",
            title = "Mayapur TV — Live Darshan & Mangal Aarti",
            subtitle = "Sri Mayapur Chandrodaya Mandir live temple broadcasts",
            category = "Live Darshan",
            portalUrl = "https://www.mayapur.tv",
            creditMinutes = 15
        ),
        DevotionalTrack(
            id = "portal_vedabase",
            title = "Vedabase — Bhagavad-gita & Srimad-Bhagavatam",
            subtitle = "Complete authorized Vaishnava scripture library",
            category = "Scripture",
            portalUrl = "https://vedabase.io",
            creditMinutes = 15
        ),
        DevotionalTrack(
            id = "portal_prabhupadavani",
            title = "PrabhupadaVani — Lectures & Bhajans",
            subtitle = "Classic recordings of lectures, conversations & kirtans",
            category = "Audio Lectures",
            portalUrl = "https://prabhupadavani.org",
            creditMinutes = 15
        ),
        DevotionalTrack(
            id = "portal_desire_tree",
            title = "ISKCON Desire Tree Audio",
            subtitle = "Curated kirtans, japa sessions & Vaishnava seminars",
            category = "Kirtan & Classes",
            portalUrl = "https://audio.iskcondesiretree.com",
            creditMinutes = 15
        )
    )

    fun toggleTrack(track: DevotionalTrack) {
        val current = _state.value
        if (current.currentTrack?.id == track.id && current.isPlaying) {
            stopPlaybackKeepTrack()
            return
        }
        val preserveElapsed = current.currentTrack?.id == track.id
        startTanpura(track, resetElapsed = !preserveElapsed)
    }

    fun togglePlayPause() {
        val current = _state.value
        val track = current.currentTrack ?: builtInTanpuraTracks.first()
        if (current.isPlaying) {
            stopPlaybackKeepTrack()
        } else {
            startTanpura(track, resetElapsed = false)
        }
    }

    fun startTanpura(track: DevotionalTrack, resetElapsed: Boolean = true) {
        stopInternal()
        val initialElapsed = if (resetElapsed) 0 else _state.value.elapsedSeconds
        _state.value = AudioPlaybackState(
            currentTrack = track,
            isPlaying = true,
            elapsedSeconds = initialElapsed,
            statusMessage = "Playing offline Sa–Pa–Sa drone"
        )

        synthJob = scope.launch {
            var localTrack: AudioTrack? = null
            try {
                val sampleRate = 22050
                val bufferBytes = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(4096)

                val trackObj = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferBytes)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                localTrack = trackObj
                audioTrack = trackObj
                trackObj.play()

                val sa = track.baseFrequencyHz
                val pa = sa * 1.5          // Panchama (perfect fifth)
                val saHigh = sa * 2.0      // Upper Sa
                val saLow = sa * 0.5       // Kharaja lower Sa

                val chunkSamples = 1024
                val pcm = ShortArray(chunkSamples)
                var sampleIndex = 0L
                val cycleSamples = sampleRate * 4 // 4-second plucked cycle (Pa, Sa+, Sa+, Sa-)

                while (isActive) {
                    for (i in 0 until chunkSamples) {
                        val t = sampleIndex.toDouble() / sampleRate.toDouble()
                        val posInCycle = (sampleIndex % cycleSamples).toDouble() / sampleRate.toDouble()

                        val envPa = pluckEnvelope(posInCycle, 0.0)
                        val envSa1 = pluckEnvelope(posInCycle, 1.0)
                        val envSa2 = pluckEnvelope(posInCycle, 2.0)
                        val envSaLow = pluckEnvelope(posInCycle, 3.0)

                        val wavePa = envPa * (0.55 * sin(2 * PI * pa * t) + 0.25 * sin(2 * PI * pa * 2 * t) + 0.12 * sin(2 * PI * pa * 3 * t))
                        val waveSa1 = envSa1 * (0.55 * sin(2 * PI * saHigh * t) + 0.22 * sin(2 * PI * saHigh * 2 * t))
                        val waveSa2 = envSa2 * (0.55 * sin(2 * PI * saHigh * 1.002 * t) + 0.22 * sin(2 * PI * saHigh * 2 * t))
                        val waveSaLow = envSaLow * (0.65 * sin(2 * PI * saLow * t) + 0.30 * sin(2 * PI * sa * t) + 0.15 * sin(2 * PI * sa * 2 * t))

                        val mixed = ((wavePa + waveSa1 + waveSa2 + waveSaLow) * 0.24).coerceIn(-0.95, 0.95)
                        pcm[i] = (mixed * Short.MAX_VALUE).toInt().toShort()
                        sampleIndex++
                    }
                    if (!isActive) break
                    val written = trackObj.write(pcm, 0, chunkSamples)
                    if (written < 0) break
                }
            } catch (e: Exception) {
                Log.w("DevotionalAudio", "AudioTrack playback ended: ${e.message}")
            } finally {
                try {
                    localTrack?.pause()
                    localTrack?.flush()
                    localTrack?.stop()
                    localTrack?.release()
                } catch (_: Exception) {
                }
                if (audioTrack === localTrack) {
                    audioTrack = null
                }
            }
        }

        timerJob = scope.launch {
            var credited = initialElapsed >= 30
            while (isActive) {
                delay(1000L)
                val nextSec = _state.value.elapsedSeconds + 1
                _state.value = _state.value.copy(elapsedSeconds = nextSec)
                // Credit daily hearing once after 30s of attentive listening (deduplicated per track/day)
                if (!credited && nextSec >= 30) {
                    credited = true
                    onHearingCreditEarned(track.id, track.creditMinutes)
                }
            }
        }
    }

    private fun pluckEnvelope(posSec: Double, startSec: Double): Double {
        val elapsed = ((posSec - startSec) + 4.0) % 4.0
        val attack = (elapsed / 0.08).coerceIn(0.0, 1.0)
        val decay = exp(-elapsed * 0.55)
        return (attack * decay).coerceIn(0.18, 1.0)
    }

    private fun stopPlaybackKeepTrack() {
        stopInternal()
        _state.value = _state.value.copy(isPlaying = false, statusMessage = "Paused")
    }

    fun stop() {
        stopInternal()
        _state.value = AudioPlaybackState()
    }

    private fun stopInternal() {
        synthJob?.cancel()
        synthJob = null
        timerJob?.cancel()
        timerJob = null
    }
}
