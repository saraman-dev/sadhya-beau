package com.example.alarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

class SadhanaAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val type = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_TYPE) ?: AlarmScheduler.TYPE_TASK_REMINDER
        val title = intent.getStringExtra(AlarmScheduler.EXTRA_TITLE) ?: "Sadhya Reminder"
        val message = intent.getStringExtra(AlarmScheduler.EXTRA_MESSAGE) ?: "Hare Krishna! Time for your scheduled Sadhana."
        val requestCode = intent.getIntExtra(AlarmScheduler.EXTRA_REQUEST_CODE, 2000)

        ensureChannels(context)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (type == AlarmScheduler.TYPE_WAKE_UP) {
            val wakeIntent = Intent(context, WakeUpAlarmActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(WakeUpAlarmActivity.EXTRA_FROM_ALARM, true)
            }
            val fullScreenPi = PendingIntent.getActivity(
                context,
                9101,
                wakeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(context, CHANNEL_ALARM)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setFullScreenIntent(fullScreenPi, true)
                .setAutoCancel(true)
                .setContentIntent(fullScreenPi)
                .build()
            nm.notify(9101, notification)
            try {
                context.startActivity(wakeIntent)
            } catch (_: Exception) {
                // Full-screen intent notification serves as fallback on Android 10+
            }
        } else {
            val openIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val openPi = PendingIntent.getActivity(
                context,
                requestCode,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(openPi)
                .build()
            nm.notify(requestCode, notification)
        }
    }

    companion object {
        const val CHANNEL_ALARM = "sadhya_wake_alarm"
        const val CHANNEL_REMINDERS = "sadhya_reminders"

        fun ensureChannels(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val alarmChannel = NotificationChannel(
                    CHANNEL_ALARM,
                    "Brahma Muhurta Wake-Up",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Full-screen Brahma Muhurta morning wake-up alarms"
                }
                val reminderChannel = NotificationChannel(
                    CHANNEL_REMINDERS,
                    "Sadhana & Wind-Down Reminders",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Bedtime wind-down, Sandhya, and personal task reminders"
                }
                nm.createNotificationChannel(alarmChannel)
                nm.createNotificationChannel(reminderChannel)
            }
        }
    }
}
