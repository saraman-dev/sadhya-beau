package com.example.data

import android.content.Context
import com.example.model.CalendarTradition
import com.example.model.DailyTask
import com.example.model.DarkModePreference
import com.example.model.DevoteePersona
import com.example.model.FocusLog
import com.example.model.FocusOutcome
import com.example.model.FocusStrictness
import com.example.model.FontScaleLevel
import com.example.model.RoutineMode
import com.example.model.RoutineTemplates
import com.example.model.SadhanaDailyLog
import com.example.model.ScheduleItem
import com.example.model.TaskPriority
import com.example.model.TempleCommunity
import com.example.model.TemplePost
import com.example.model.ThemeStyle
import com.example.model.UserProfile
import com.example.model.WakeStatus
import com.google.firebase.Timestamp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

class GuestLocalRepository(private val context: Context) : SadhanaDataRepository {

    override val isGuestMode: Boolean = true

    private val storageFile: File
        get() = File(context.applicationContext.filesDir, "sadhya_guest_store.json")

    private val profileFlow = MutableStateFlow<UserProfile?>(null)
    private val scheduleFlow = MutableStateFlow<List<ScheduleItem>>(emptyList())
    private val tasksFlow = MutableStateFlow<List<DailyTask>>(emptyList())
    private val logsFlow = MutableStateFlow<List<SadhanaDailyLog>>(emptyList())
    private val focusLogsFlow = MutableStateFlow<List<FocusLog>>(emptyList())
    private val templesFlow = MutableStateFlow<List<TempleCommunity>>(emptyList())
    private val postsFlow = MutableStateFlow<List<TemplePost>>(emptyList())

    init {
        loadOrSeedSync()
    }

    private fun todayKey(offsetDays: Int = 0): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, offsetDays)
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    }

    private fun loadOrSeedSync() {
        val file = storageFile
        if (file.exists()) {
            try {
                val root = JSONObject(file.readText())
                parseFromJson(root)
                if (profileFlow.value != null) return
            } catch (_: Exception) {
                // Fall back to fresh seed on corrupted file
            }
        }
        seedDefaults()
        persistSync()
    }

    private fun seedDefaults() {
        val tzId = TimeZone.getDefault().id.ifBlank { "Asia/Kolkata" }
        profileFlow.value = UserProfile(
            userId = GUEST_UID,
            displayName = "Guest Devotee",
            email = "guest@local",
            routineMode = RoutineMode.CONGREGATIONAL.name,
            wakeTime = "04:45",
            sleepTime = "21:45",
            japaTargetRounds = 16L,
            readingTargetMinutes = 30L,
            hearingTargetMinutes = 30L,
            attendOnlineMangalAarti = true,
            gayatriInitiated = false,
            gayatriMorningTime = "06:15",
            gayatriAfternoonTime = "12:15",
            gayatriEveningTime = "18:15",
            responsibilities = listOf("Morning Sadhana", "Family & Work Seva"),
            distractingPackages = listOf(
                "com.instagram.android",
                "com.google.android.youtube",
                "com.zhiliaoapp.musically",
                "com.twitter.android"
            ),
            focusStrictness = FocusStrictness.BALANCED.name,
            calendarTradition = CalendarTradition.ISKCON_MAYAPUR.name,
            locationName = "Mayapur, India",
            latitude = 23.4231,
            longitude = 88.3880,
            timezoneId = tzId,
            followedTempleId = "ref_mayapur",
            activeFestivalMode = "",
            themeStyle = ThemeStyle.IVORY_MAROON.name,
            darkModePreference = DarkModePreference.SYSTEM.name,
            fontScaleLevel = FontScaleLevel.STANDARD.name,
            bedtimeModeEnabled = true,
            onboardingCompleted = true,
            createdAt = Timestamp.now(),
            updatedAt = Timestamp.now()
        )

        scheduleFlow.value = RoutineTemplates.scheduleForPersona(DevoteePersona.CONGREGATIONAL)
            .mapIndexed { idx, item -> item.copy(id = "guest_sched_${idx + 1}", sortOrder = (idx + 1).toLong()) }

        val today = todayKey(0)
        tasksFlow.value = listOf(
            DailyTask(
                id = "guest_task_1",
                title = "Read Bhagavad-gita Chapter 12 (15 mins)",
                category = "Reading",
                dueDateKey = today,
                reminderTime = "07:15",
                priority = TaskPriority.HIGH.name,
                completed = false,
                notes = "Reflect gently on one verse",
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            ),
            DailyTask(
                id = "guest_task_2",
                title = "Offer fresh Tulasi & water at home altar",
                category = "Seva",
                dueDateKey = today,
                reminderTime = "06:45",
                priority = TaskPriority.MEDIUM.name,
                completed = false,
                notes = "Simple daily devotional offering",
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            ),
            DailyTask(
                id = "guest_task_3",
                title = "Prepare Ekadashi groceries for upcoming fast",
                category = "Festival",
                dueDateKey = todayKey(1),
                reminderTime = "17:00",
                priority = TaskPriority.LOW.name,
                completed = false,
                notes = "Fruits, roots, and simple sattvic foods",
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            )
        )

        // Seed 6 prior days of sample Sadhana history + fresh 0-round start for today
        val sampleRounds = listOf(12L, 16L, 14L, 16L, 16L, 15L, 0L)
        logsFlow.value = (6 downTo 0).map { daysAgo ->
            val key = todayKey(-daysAgo)
            val rounds = sampleRounds[6 - daysAgo]
            SadhanaDailyLog(
                dateKey = key,
                japaRounds = rounds,
                readingMinutes = if (daysAgo == 0) 0L else 30L,
                hearingMinutes = if (daysAgo == 0) 0L else 25L,
                mangalAartiAttended = daysAgo % 2 == 0,
                wakeStatus = if (daysAgo == 0) WakeStatus.PENDING.name else WakeStatus.ON_TIME.name,
                wakeActualTime = if (daysAgo == 0) "" else "04:45",
                sevaMinutes = if (daysAgo == 2) 45L else 15L,
                sevaNote = if (daysAgo == 2) "Temple kitchen seva" else "Home altar care",
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            )
        }.sortedByDescending { it.dateKey }

        focusLogsFlow.value = listOf(
            FocusLog(
                id = "guest_focus_1",
                packageName = "com.instagram.android",
                appLabel = "Instagram",
                strictness = FocusStrictness.BALANCED.name,
                outcome = FocusOutcome.RETURNED_TO_SADHANA.name,
                reason = "Chose to finish morning Japa first",
                durationMinutes = 30L,
                createdAt = Timestamp.now()
            )
        )

        templesFlow.value = RoutineTemplates.referenceTemples
        postsFlow.value = RoutineTemplates.referencePosts
    }

    private suspend fun persist() = withContext(Dispatchers.IO) { persistSync() }

    private fun persistSync() {
        try {
            val root = JSONObject()
            profileFlow.value?.let { p ->
                root.put("profile", JSONObject().apply {
                    put("userId", p.userId)
                    put("displayName", p.displayName)
                    put("email", p.email)
                    put("routineMode", p.routineMode)
                    put("wakeTime", p.wakeTime)
                    put("sleepTime", p.sleepTime)
                    put("japaTargetRounds", p.japaTargetRounds)
                    put("readingTargetMinutes", p.readingTargetMinutes)
                    put("hearingTargetMinutes", p.hearingTargetMinutes)
                    put("attendOnlineMangalAarti", p.attendOnlineMangalAarti)
                    put("gayatriInitiated", p.gayatriInitiated)
                    put("gayatriMorningTime", p.gayatriMorningTime)
                    put("gayatriAfternoonTime", p.gayatriAfternoonTime)
                    put("gayatriEveningTime", p.gayatriEveningTime)
                    put("responsibilities", JSONArray(p.responsibilities))
                    put("distractingPackages", JSONArray(p.distractingPackages))
                    put("focusStrictness", p.focusStrictness)
                    put("calendarTradition", p.calendarTradition)
                    put("locationName", p.locationName)
                    put("latitude", p.latitude)
                    put("longitude", p.longitude)
                    put("timezoneId", p.timezoneId)
                    put("followedTempleId", p.followedTempleId)
                    put("activeFestivalMode", p.activeFestivalMode)
                    put("themeStyle", p.themeStyle)
                    put("darkModePreference", p.darkModePreference)
                    put("fontScaleLevel", p.fontScaleLevel)
                    put("bedtimeModeEnabled", p.bedtimeModeEnabled)
                    put("onboardingCompleted", p.onboardingCompleted)
                })
            }
            root.put("schedule", JSONArray().apply {
                scheduleFlow.value.forEach { s ->
                    put(JSONObject().apply {
                        put("id", s.id)
                        put("title", s.title)
                        put("category", s.category)
                        put("startTime", s.startTime)
                        put("endTime", s.endTime)
                        put("essential", s.essential)
                        put("completedDateKey", s.completedDateKey)
                        put("notes", s.notes)
                        put("sortOrder", s.sortOrder)
                    })
                }
            })
            root.put("tasks", JSONArray().apply {
                tasksFlow.value.forEach { t ->
                    put(JSONObject().apply {
                        put("id", t.id)
                        put("title", t.title)
                        put("category", t.category)
                        put("dueDateKey", t.dueDateKey)
                        put("reminderTime", t.reminderTime)
                        put("priority", t.priority)
                        put("completed", t.completed)
                        put("notes", t.notes)
                    })
                }
            })
            root.put("logs", JSONArray().apply {
                logsFlow.value.forEach { l ->
                    put(JSONObject().apply {
                        put("dateKey", l.dateKey)
                        put("japaRounds", l.japaRounds)
                        put("readingMinutes", l.readingMinutes)
                        put("hearingMinutes", l.hearingMinutes)
                        put("mangalAartiAttended", l.mangalAartiAttended)
                        put("gayatriMorningDone", l.gayatriMorningDone)
                        put("gayatriAfternoonDone", l.gayatriAfternoonDone)
                        put("gayatriEveningDone", l.gayatriEveningDone)
                        put("pujaDone", l.pujaDone)
                        put("wakeStatus", l.wakeStatus)
                        put("wakeActualTime", l.wakeActualTime)
                        put("sevaMinutes", l.sevaMinutes)
                        put("sevaNote", l.sevaNote)
                        put("reflectionNote", l.reflectionNote)
                        put("creditedAudioIds", JSONArray(l.creditedAudioIds))
                    })
                }
            })
            root.put("focusLogs", JSONArray().apply {
                focusLogsFlow.value.forEach { f ->
                    put(JSONObject().apply {
                        put("id", f.id)
                        put("packageName", f.packageName)
                        put("appLabel", f.appLabel)
                        put("strictness", f.strictness)
                        put("outcome", f.outcome)
                        put("reason", f.reason)
                        put("durationMinutes", f.durationMinutes)
                    })
                }
            })
            root.put("temples", JSONArray().apply {
                templesFlow.value.forEach { tc ->
                    put(JSONObject().apply {
                        put("id", tc.id)
                        put("name", tc.name)
                        put("city", tc.city)
                        put("country", tc.country)
                        put("tradition", tc.tradition)
                        put("adminUid", tc.adminUid)
                        put("mangalAartiTime", tc.mangalAartiTime)
                        put("darshanAartiTime", tc.darshanAartiTime)
                        put("bhagavatamClassTime", tc.bhagavatamClassTime)
                        put("sandhyaAartiTime", tc.sandhyaAartiTime)
                        put("description", tc.description)
                        put("liveStreamUrl", tc.liveStreamUrl)
                    })
                }
            })
            root.put("posts", JSONArray().apply {
                postsFlow.value.forEach { tp ->
                    put(JSONObject().apply {
                        put("id", tp.id)
                        put("templeId", tp.templeId)
                        put("authorUid", tp.authorUid)
                        put("authorName", tp.authorName)
                        put("postType", tp.postType)
                        put("title", tp.title)
                        put("body", tp.body)
                        put("eventDateKey", tp.eventDateKey)
                        put("eventTime", tp.eventTime)
                        put("volunteerUids", JSONArray(tp.volunteerUids))
                    })
                }
            })
            storageFile.writeText(root.toString())
        } catch (_: Exception) {
            // Keep in-memory state alive even if storage write fails
        }
    }

    private fun parseFromJson(root: JSONObject) {
        root.optJSONObject("profile")?.let { p ->
            profileFlow.value = UserProfile(
                userId = p.optString("userId", GUEST_UID),
                displayName = p.optString("displayName", "Guest Devotee"),
                email = p.optString("email", "guest@local"),
                routineMode = p.optString("routineMode", RoutineMode.CONGREGATIONAL.name),
                wakeTime = p.optString("wakeTime", "04:45"),
                sleepTime = p.optString("sleepTime", "21:45"),
                japaTargetRounds = p.optLong("japaTargetRounds", 16L),
                readingTargetMinutes = p.optLong("readingTargetMinutes", 30L),
                hearingTargetMinutes = p.optLong("hearingTargetMinutes", 30L),
                attendOnlineMangalAarti = p.optBoolean("attendOnlineMangalAarti", true),
                gayatriInitiated = p.optBoolean("gayatriInitiated", false),
                gayatriMorningTime = p.optString("gayatriMorningTime", "06:15"),
                gayatriAfternoonTime = p.optString("gayatriAfternoonTime", "12:15"),
                gayatriEveningTime = p.optString("gayatriEveningTime", "18:15"),
                responsibilities = p.optJSONArray("responsibilities").toStringList(),
                distractingPackages = p.optJSONArray("distractingPackages").toStringList(),
                focusStrictness = p.optString("focusStrictness", FocusStrictness.BALANCED.name),
                calendarTradition = p.optString("calendarTradition", CalendarTradition.ISKCON_MAYAPUR.name),
                locationName = p.optString("locationName", "Mayapur, India"),
                latitude = p.optDouble("latitude", 23.4231),
                longitude = p.optDouble("longitude", 88.3880),
                timezoneId = p.optString("timezoneId", TimeZone.getDefault().id),
                followedTempleId = p.optString("followedTempleId", "ref_mayapur"),
                activeFestivalMode = p.optString("activeFestivalMode", ""),
                themeStyle = p.optString("themeStyle", ThemeStyle.IVORY_MAROON.name),
                darkModePreference = p.optString("darkModePreference", DarkModePreference.SYSTEM.name),
                fontScaleLevel = p.optString("fontScaleLevel", FontScaleLevel.STANDARD.name),
                bedtimeModeEnabled = p.optBoolean("bedtimeModeEnabled", true),
                onboardingCompleted = p.optBoolean("onboardingCompleted", true),
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            )
        }
        root.optJSONArray("schedule")?.let { arr ->
            val items = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                ScheduleItem(
                    id = o.optString("id"),
                    title = o.optString("title"),
                    category = o.optString("category"),
                    startTime = o.optString("startTime", "05:00"),
                    endTime = o.optString("endTime", "06:00"),
                    essential = o.optBoolean("essential", false),
                    completedDateKey = o.optString("completedDateKey", ""),
                    notes = o.optString("notes", ""),
                    sortOrder = o.optLong("sortOrder", i.toLong())
                )
            }
            scheduleFlow.value = items.sortedWith(compareBy<ScheduleItem> { it.startTime }.thenBy { it.sortOrder })
        }
        root.optJSONArray("tasks")?.let { arr ->
            tasksFlow.value = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                DailyTask(
                    id = o.optString("id"),
                    title = o.optString("title"),
                    category = o.optString("category", "Devotion"),
                    dueDateKey = o.optString("dueDateKey", ""),
                    reminderTime = o.optString("reminderTime", ""),
                    priority = o.optString("priority", TaskPriority.MEDIUM.name),
                    completed = o.optBoolean("completed", false),
                    notes = o.optString("notes", "")
                )
            }
        }
        root.optJSONArray("logs")?.let { arr ->
            logsFlow.value = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                SadhanaDailyLog(
                    dateKey = o.optString("dateKey"),
                    japaRounds = o.optLong("japaRounds", 0L),
                    readingMinutes = o.optLong("readingMinutes", 0L),
                    hearingMinutes = o.optLong("hearingMinutes", 0L),
                    mangalAartiAttended = o.optBoolean("mangalAartiAttended", false),
                    gayatriMorningDone = o.optBoolean("gayatriMorningDone", false),
                    gayatriAfternoonDone = o.optBoolean("gayatriAfternoonDone", false),
                    gayatriEveningDone = o.optBoolean("gayatriEveningDone", false),
                    pujaDone = o.optBoolean("pujaDone", false),
                    wakeStatus = o.optString("wakeStatus", WakeStatus.PENDING.name),
                    wakeActualTime = o.optString("wakeActualTime", ""),
                    sevaMinutes = o.optLong("sevaMinutes", 0L),
                    sevaNote = o.optString("sevaNote", ""),
                    reflectionNote = o.optString("reflectionNote", ""),
                    creditedAudioIds = o.optJSONArray("creditedAudioIds").toStringList()
                )
            }.sortedByDescending { it.dateKey }
        }
        root.optJSONArray("focusLogs")?.let { arr ->
            focusLogsFlow.value = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                FocusLog(
                    id = o.optString("id"),
                    packageName = o.optString("packageName"),
                    appLabel = o.optString("appLabel"),
                    strictness = o.optString("strictness", FocusStrictness.BALANCED.name),
                    outcome = o.optString("outcome", FocusOutcome.RETURNED_TO_SADHANA.name),
                    reason = o.optString("reason", ""),
                    durationMinutes = o.optLong("durationMinutes", 0L)
                )
            }
        }
        root.optJSONArray("temples")?.let { arr ->
            val list = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                TempleCommunity(
                    id = o.optString("id"),
                    name = o.optString("name"),
                    city = o.optString("city"),
                    country = o.optString("country"),
                    tradition = o.optString("tradition", CalendarTradition.ISKCON_MAYAPUR.name),
                    adminUid = o.optString("adminUid", "reference_temple"),
                    mangalAartiTime = o.optString("mangalAartiTime", "04:30"),
                    darshanAartiTime = o.optString("darshanAartiTime", "07:00"),
                    bhagavatamClassTime = o.optString("bhagavatamClassTime", "07:45"),
                    sandhyaAartiTime = o.optString("sandhyaAartiTime", "19:00"),
                    description = o.optString("description", ""),
                    liveStreamUrl = o.optString("liveStreamUrl", "")
                )
            }
            templesFlow.value = if (list.isEmpty()) RoutineTemplates.referenceTemples else list
        }
        root.optJSONArray("posts")?.let { arr ->
            postsFlow.value = (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                TemplePost(
                    id = o.optString("id"),
                    templeId = o.optString("templeId"),
                    authorUid = o.optString("authorUid"),
                    authorName = o.optString("authorName"),
                    postType = o.optString("postType"),
                    title = o.optString("title"),
                    body = o.optString("body"),
                    eventDateKey = o.optString("eventDateKey", ""),
                    eventTime = o.optString("eventTime", ""),
                    volunteerUids = o.optJSONArray("volunteerUids").toStringList()
                )
            }
        }
    }

    private fun JSONArray?.toStringList(): List<String> {
        if (this == null) return emptyList()
        return (0 until length()).mapNotNull { optString(it).takeIf { s -> s.isNotBlank() } }
    }

    override suspend fun ensureUserProfileExists(
        uid: String,
        displayName: String,
        email: String
    ): Result<UserProfile> {
        val current = profileFlow.value ?: run {
            seedDefaults()
            persist()
            profileFlow.value!!
        }
        return Result.success(current)
    }

    override fun observeUserProfile(uid: String): Flow<UserProfile?> = profileFlow

    override suspend fun updateUserProfileFields(uid: String, fields: Map<String, Any>): Result<Unit> {
        val p = profileFlow.value ?: UserProfile(userId = GUEST_UID)
        var next = p
        fields.forEach { (k, v) ->
            next = when (k) {
                "displayName" -> next.copy(displayName = (v as? String)?.trim()?.take(80)?.ifBlank { next.displayName } ?: next.displayName)
                "email" -> next.copy(email = (v as? String) ?: next.email)
                "routineMode" -> next.copy(routineMode = (v as? String) ?: next.routineMode)
                "wakeTime" -> next.copy(wakeTime = (v as? String) ?: next.wakeTime)
                "sleepTime" -> next.copy(sleepTime = (v as? String) ?: next.sleepTime)
                "japaTargetRounds" -> next.copy(japaTargetRounds = ((v as? Number)?.toLong() ?: next.japaTargetRounds).coerceIn(1L, 192L))
                "readingTargetMinutes" -> next.copy(readingTargetMinutes = ((v as? Number)?.toLong() ?: next.readingTargetMinutes).coerceIn(0L, 600L))
                "hearingTargetMinutes" -> next.copy(hearingTargetMinutes = ((v as? Number)?.toLong() ?: next.hearingTargetMinutes).coerceIn(0L, 600L))
                "attendOnlineMangalAarti" -> next.copy(attendOnlineMangalAarti = (v as? Boolean) ?: next.attendOnlineMangalAarti)
                "gayatriInitiated" -> next.copy(gayatriInitiated = (v as? Boolean) ?: next.gayatriInitiated)
                "gayatriMorningTime" -> next.copy(gayatriMorningTime = (v as? String) ?: next.gayatriMorningTime)
                "gayatriAfternoonTime" -> next.copy(gayatriAfternoonTime = (v as? String) ?: next.gayatriAfternoonTime)
                "gayatriEveningTime" -> next.copy(gayatriEveningTime = (v as? String) ?: next.gayatriEveningTime)
                "responsibilities" -> next.copy(responsibilities = (v as? List<*>)?.filterIsInstance<String>()?.take(15) ?: next.responsibilities)
                "distractingPackages" -> next.copy(distractingPackages = (v as? List<*>)?.filterIsInstance<String>()?.take(30) ?: next.distractingPackages)
                "focusStrictness" -> next.copy(focusStrictness = (v as? String) ?: next.focusStrictness)
                "calendarTradition" -> next.copy(calendarTradition = (v as? String) ?: next.calendarTradition)
                "locationName" -> next.copy(locationName = (v as? String) ?: next.locationName)
                "latitude" -> next.copy(latitude = (v as? Number)?.toDouble() ?: next.latitude)
                "longitude" -> next.copy(longitude = (v as? Number)?.toDouble() ?: next.longitude)
                "timezoneId" -> next.copy(timezoneId = (v as? String) ?: next.timezoneId)
                "followedTempleId" -> next.copy(followedTempleId = (v as? String) ?: next.followedTempleId)
                "activeFestivalMode" -> next.copy(activeFestivalMode = (v as? String) ?: next.activeFestivalMode)
                "themeStyle" -> next.copy(themeStyle = (v as? String) ?: next.themeStyle)
                "darkModePreference" -> next.copy(darkModePreference = (v as? String) ?: next.darkModePreference)
                "fontScaleLevel" -> next.copy(fontScaleLevel = (v as? String) ?: next.fontScaleLevel)
                "bedtimeModeEnabled" -> next.copy(bedtimeModeEnabled = (v as? Boolean) ?: next.bedtimeModeEnabled)
                "onboardingCompleted" -> next.copy(onboardingCompleted = (v as? Boolean) ?: next.onboardingCompleted)
                else -> next
            }
        }
        profileFlow.value = next.copy(updatedAt = Timestamp.now())
        persist()
        return Result.success(Unit)
    }

    override fun observeSchedule(uid: String): Flow<List<ScheduleItem>> = scheduleFlow

    override suspend fun saveScheduleItem(uid: String, item: ScheduleItem): Result<String> {
        val id = item.id.ifBlank { "sched_${UUID.randomUUID().toString().take(8)}" }
        val saved = item.copy(id = id, updatedAt = Timestamp.now())
        val updatedList = scheduleFlow.value.filterNot { it.id == id } + saved
        scheduleFlow.value = updatedList.sortedWith(compareBy<ScheduleItem> { it.startTime }.thenBy { it.sortOrder })
        persist()
        return Result.success(id)
    }

    override suspend fun replaceSchedule(uid: String, items: List<ScheduleItem>): Result<Unit> {
        scheduleFlow.value = items.mapIndexed { idx, it ->
            it.copy(
                id = it.id.ifBlank { "sched_${idx + 1}_${UUID.randomUUID().toString().take(4)}" },
                sortOrder = (idx + 1).toLong()
            )
        }.sortedWith(compareBy<ScheduleItem> { it.startTime }.thenBy { it.sortOrder })
        persist()
        return Result.success(Unit)
    }

    override suspend fun toggleScheduleCompletion(uid: String, itemId: String, dateKey: String?): Result<Unit> {
        scheduleFlow.value = scheduleFlow.value.map { item ->
            if (item.id == itemId) item.copy(completedDateKey = dateKey.orEmpty()) else item
        }
        persist()
        return Result.success(Unit)
    }

    override suspend fun deleteScheduleItem(uid: String, itemId: String): Result<Unit> {
        scheduleFlow.value = scheduleFlow.value.filterNot { it.id == itemId }
        persist()
        return Result.success(Unit)
    }

    override fun observeTasks(uid: String): Flow<List<DailyTask>> = tasksFlow

    override suspend fun saveTask(uid: String, task: DailyTask): Result<String> {
        val id = task.id.ifBlank { "task_${UUID.randomUUID().toString().take(8)}" }
        val saved = task.copy(id = id, updatedAt = Timestamp.now())
        tasksFlow.value = (listOf(saved) + tasksFlow.value.filterNot { it.id == id })
            .sortedBy { it.completed }
        persist()
        return Result.success(id)
    }

    override suspend fun toggleTaskCompleted(uid: String, taskId: String, completed: Boolean): Result<Unit> {
        tasksFlow.value = tasksFlow.value.map { t ->
            if (t.id == taskId) t.copy(completed = completed) else t
        }.sortedBy { it.completed }
        persist()
        return Result.success(Unit)
    }

    override suspend fun deleteTask(uid: String, taskId: String): Result<Unit> {
        tasksFlow.value = tasksFlow.value.filterNot { it.id == taskId }
        persist()
        return Result.success(Unit)
    }

    override fun observeRecentSadhanaLogs(uid: String): Flow<List<SadhanaDailyLog>> = logsFlow

    override suspend fun upsertSadhanaLog(
        uid: String,
        dateKey: String,
        transform: (SadhanaDailyLog) -> SadhanaDailyLog
    ): Result<SadhanaDailyLog> {
        val existing = logsFlow.value.firstOrNull { it.dateKey == dateKey } ?: SadhanaDailyLog(dateKey = dateKey)
        val updated = transform(existing).copy(
            dateKey = dateKey,
            updatedAt = Timestamp.now()
        )
        logsFlow.value = (logsFlow.value.filterNot { it.dateKey == dateKey } + updated)
            .sortedByDescending { it.dateKey }
            .take(30)
        persist()
        return Result.success(updated)
    }

    override fun observeFocusLogs(uid: String): Flow<List<FocusLog>> = focusLogsFlow

    override suspend fun addFocusLog(uid: String, log: FocusLog): Result<Unit> {
        val id = log.id.ifBlank { "focus_${UUID.randomUUID().toString().take(8)}" }
        focusLogsFlow.value = (listOf(log.copy(id = id, createdAt = Timestamp.now())) + focusLogsFlow.value).take(30)
        persist()
        return Result.success(Unit)
    }

    override suspend fun deleteFocusLog(uid: String, logId: String): Result<Unit> {
        focusLogsFlow.value = focusLogsFlow.value.filterNot { it.id == logId }
        persist()
        return Result.success(Unit)
    }

    override fun observeTemples(): Flow<List<TempleCommunity>> = templesFlow

    override suspend fun createTemple(uid: String, temple: TempleCommunity): Result<String> {
        val id = "temple_${UUID.randomUUID().toString().take(8)}"
        val saved = temple.copy(id = id, adminUid = uid, visibility = "PUBLIC", createdAt = Timestamp.now(), updatedAt = Timestamp.now())
        templesFlow.value = (templesFlow.value + saved).sortedBy { it.name }
        persist()
        return Result.success(id)
    }

    override fun observeTemplePosts(templeId: String): Flow<List<TemplePost>> =
        postsFlow.map { all -> all.filter { it.templeId == templeId } }

    override suspend fun createTemplePost(uid: String, post: TemplePost): Result<String> {
        val id = "post_${UUID.randomUUID().toString().take(8)}"
        val saved = post.copy(id = id, authorUid = uid, visibility = "PUBLIC", createdAt = Timestamp.now(), updatedAt = Timestamp.now())
        postsFlow.value = listOf(saved) + postsFlow.value
        persist()
        return Result.success(id)
    }

    override suspend fun deleteTemplePost(templeId: String, postId: String): Result<Unit> {
        postsFlow.value = postsFlow.value.filterNot { it.id == postId && it.templeId == templeId }
        persist()
        return Result.success(Unit)
    }

    override suspend fun toggleSevaVolunteer(uid: String, templeId: String, postId: String): Result<Unit> {
        postsFlow.value = postsFlow.value.map { post ->
            if (post.id == postId && post.templeId == templeId) {
                val updated = if (uid in post.volunteerUids) post.volunteerUids - uid else (post.volunteerUids + uid).take(100)
                post.copy(volunteerUids = updated)
            } else post
        }
        persist()
        return Result.success(Unit)
    }

    override suspend fun deleteAccountAndData(uid: String): Result<Unit> {
        if (storageFile.exists()) storageFile.delete()
        seedDefaults()
        persist()
        return Result.success(Unit)
    }

    companion object {
        const val GUEST_UID = "guest_local_devotee"
    }
}
