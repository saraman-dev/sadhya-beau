package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddBusiness
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TempleHindu
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.CalendarTradition
import com.example.model.TempleCommunity
import com.example.model.TemplePost
import com.example.model.TemplePostType
import com.example.ui.components.SectionHeader
import com.example.ui.components.TimePickerField

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TempleCommunitySection(
    temples: List<TempleCommunity>,
    selectedTempleId: String,
    followedTempleId: String,
    posts: List<TemplePost>,
    currentUserId: String,
    isGuestMode: Boolean,
    onSelectTemple: (String) -> Unit,
    onFollowTemple: (TempleCommunity) -> Unit,
    onApplyAratiSchedule: (TempleCommunity) -> Unit,
    onRegisterTemple: (TempleCommunity) -> Unit,
    onPublishPost: (templeId: String, type: TemplePostType, title: String, body: String, eventTime: String) -> Unit,
    onToggleSevaVolunteer: (TemplePost) -> Unit
) {
    var showRegisterDialog by remember { mutableStateOf(false) }
    var showCreatePostDialog by remember { mutableStateOf(false) }

    val activeTemple = temples.firstOrNull { it.id == selectedTempleId } ?: temples.firstOrNull()
    val canAdminPost = activeTemple != null && (activeTemple.adminUid == currentUserId || (isGuestMode && !activeTemple.id.startsWith("ref_")))

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionHeader(
                title = "Temple Community Hub",
                subtitle = "Follow reference shrines or register your local mandir",
                actionLabel = "Register",
                onAction = { showRegisterDialog = true }
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                temples.forEach { temple ->
                    FilterChip(
                        selected = activeTemple?.id == temple.id,
                        onClick = { onSelectTemple(temple.id) },
                        label = { Text(temple.name) },
                        leadingIcon = if (followedTempleId == temple.id) {
                            { Icon(Icons.Default.Check, contentDescription = "Followed") }
                        } else null,
                        modifier = Modifier.testTag("temple_chip_${temple.id}")
                    )
                }
            }

            if (activeTemple != null) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.TempleHindu,
                                contentDescription = activeTemple.name,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(activeTemple.name, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "${activeTemple.city}, ${activeTemple.country} • ${CalendarTradition.fromRaw(activeTemple.tradition).label}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (activeTemple.description.isNotBlank()) {
                            Text(activeTemple.description, style = MaterialTheme.typography.bodySmall)
                        }

                        Text(
                            text = "Mangal ${activeTemple.mangalAartiTime} • Darshan ${activeTemple.darshanAartiTime} • SB Class ${activeTemple.bhagavatamClassTime} • Sandhya ${activeTemple.sandhyaAartiTime}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { onFollowTemple(activeTemple) },
                                modifier = Modifier.testTag("temple_follow_button")
                            ) {
                                Text(if (followedTempleId == activeTemple.id) "Following" else "Follow Temple")
                            }
                            OutlinedButton(
                                onClick = { onApplyAratiSchedule(activeTemple) },
                                modifier = Modifier.testTag("temple_apply_arati_button")
                            ) {
                                Icon(Icons.Default.Schedule, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("Add Aratis to Schedule")
                            }
                            if (canAdminPost) {
                                OutlinedButton(
                                    onClick = { showCreatePostDialog = true },
                                    modifier = Modifier.testTag("temple_create_post_button")
                                ) {
                                    Icon(Icons.Default.Campaign, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("New Post")
                                }
                            }
                        }
                    }
                }

                HorizontalDivider()

                Text("Temple Board & Seva Opportunities", style = MaterialTheme.typography.titleSmall)
                if (posts.isEmpty()) {
                    Text(
                        text = if (canAdminPost) "No announcements yet. Tap 'New Post' to share festival notices or Seva opportunities."
                        else "No posts published yet for this temple.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    posts.forEach { post ->
                        val isSeva = post.postType == TemplePostType.SEVA.name
                        val isVolunteered = currentUserId in post.volunteerUids
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = TemplePostType.fromRaw(post.postType).label.uppercase(),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    if (post.eventTime.isNotBlank()) {
                                        Text(
                                            text = post.eventTime,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Text(post.title, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    post.body,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (isSeva) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "${post.volunteerUids.size} volunteer(s) signed up",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        OutlinedButton(
                                            onClick = { onToggleSevaVolunteer(post) },
                                            modifier = Modifier.testTag("seva_volunteer_button_${post.id}")
                                        ) {
                                            Icon(Icons.Default.VolunteerActivism, contentDescription = null)
                                            Spacer(Modifier.width(6.dp))
                                            Text(if (isVolunteered) "Volunteered" else "Offer Seva")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showRegisterDialog) {
        RegisterTempleDialog(
            onDismiss = { showRegisterDialog = false },
            onSubmit = { temple ->
                onRegisterTemple(temple)
                showRegisterDialog = false
            }
        )
    }

    if (showCreatePostDialog && activeTemple != null) {
        CreateTemplePostDialog(
            templeName = activeTemple.name,
            onDismiss = { showCreatePostDialog = false },
            onSubmit = { type, title, body, eventTime ->
                onPublishPost(activeTemple.id, type, title, body, eventTime)
                showCreatePostDialog = false
            }
        )
    }
}

@Composable
private fun RegisterTempleDialog(
    onDismiss: () -> Unit,
    onSubmit: (TempleCommunity) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var country by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var mangal by remember { mutableStateOf("04:30") }
    var darshan by remember { mutableStateOf("07:15") }
    var sbClass by remember { mutableStateOf("07:45") }
    var sandhya by remember { mutableStateOf("19:00") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.AddBusiness, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Text("Register Local Temple")
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(value = name, onValueChange = { name = it.take(100) }, label = { Text("Temple Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = city, onValueChange = { city = it.take(60) }, label = { Text("City") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = country, onValueChange = { country = it.take(60) }, label = { Text("Country") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = description, onValueChange = { description = it.take(250) }, label = { Text("Short Description") }, maxLines = 2, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TimePickerField("Mangal", mangal, { mangal = it }, modifier = Modifier.weight(1f))
                    TimePickerField("Sandhya", sandhya, { sandhya = it }, modifier = Modifier.weight(1f))
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSubmit(
                        TempleCommunity(
                            name = name.trim(),
                            city = city.trim(),
                            country = country.trim(),
                            description = description.trim(),
                            mangalAartiTime = mangal,
                            darshanAartiTime = darshan,
                            bhagavatamClassTime = sbClass,
                            sandhyaAartiTime = sandhya
                        )
                    )
                },
                enabled = name.isNotBlank() && city.isNotBlank() && country.isNotBlank()
            ) {
                Text("Register")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CreateTemplePostDialog(
    templeName: String,
    onDismiss: () -> Unit,
    onSubmit: (TemplePostType, String, String, String) -> Unit
) {
    var postType by remember { mutableStateOf(TemplePostType.SEVA) }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var eventTime by remember { mutableStateOf("18:30") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Post to $templeName") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TemplePostType.entries.forEach { t ->
                        FilterChip(selected = postType == t, onClick = { postType = t }, label = { Text(t.label) })
                    }
                }
                OutlinedTextField(value = title, onValueChange = { title = it.take(120) }, label = { Text("Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = body, onValueChange = { body = it.take(600) }, label = { Text("Details") }, minLines = 2, maxLines = 4, modifier = Modifier.fillMaxWidth())
                TimePickerField("Event Time", eventTime, { eventTime = it })
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(postType, title.trim(), body.trim(), eventTime) },
                enabled = title.isNotBlank() && body.isNotBlank()
            ) {
                Text("Publish")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
