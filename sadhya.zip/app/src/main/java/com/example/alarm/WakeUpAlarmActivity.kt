package com.example.alarm

import android.Manifest
import android.content.pm.PackageManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.example.data.local.PrivateCheckInEntity
import com.example.data.local.SadhanaLocalDatabase
import com.example.engine.VaishnavaCalendarEngine
import com.example.model.WakeStatus
import com.example.ui.theme.SadhyaTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WakeUpAlarmActivity : ComponentActivity() {

    private var ringtone: Ringtone? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        val fromAlarm = intent.getBooleanExtra(EXTRA_FROM_ALARM, false)
        if (fromAlarm) {
            try {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ringtone = RingtoneManager.getRingtone(this, uri)?.apply { play() }
            } catch (_: Exception) {
            }
        }

        setContent {
            SadhyaTheme {
                WakeUpCheckInScreen(
                    onCompleteCheckIn = { photoPath ->
                        stopAlarmAudio()
                        savePrivateCheckInAndFinish(photoPath, mantraHoldDone = true)
                    },
                    onSnoozeFiveMin = {
                        stopAlarmAudio()
                        AlarmScheduler.scheduleFiveMinuteSnooze(this)
                        finish()
                    },
                    onDismiss = {
                        stopAlarmAudio()
                        finish()
                    }
                )
            }
        }
    }

    private fun stopAlarmAudio() {
        try {
            ringtone?.stop()
        } catch (_: Exception) {
        }
    }

    private fun savePrivateCheckInAndFinish(photoPath: String, mantraHoldDone: Boolean) {
        val db = SadhanaLocalDatabase.getInstance(applicationContext)
        val dateKey = VaishnavaCalendarEngine.todayDateKey()
        val nowHHmm = SimpleDateFormat("HH:mm", Locale.US).format(Date())
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                db.privateCheckInDao().upsert(
                    PrivateCheckInEntity(
                        dateKey = dateKey,
                        wakeStatus = WakeStatus.ON_TIME.name,
                        actualWakeTime = nowHHmm,
                        privatePhotoPath = photoPath,
                        mantraHoldCompleted = mantraHoldDone
                    )
                )
            }
            setResult(RESULT_OK)
            finish()
        }
    }

    override fun onDestroy() {
        stopAlarmAudio()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_FROM_ALARM = "extra_from_alarm"
    }
}

@Composable
private fun WakeUpCheckInScreen(
    onCompleteCheckIn: (photoPath: String) -> Unit,
    onSnoozeFiveMin: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isHolding by remember { mutableStateOf(false) }
    var holdProgress by remember { mutableFloatStateOf(0f) }
    var mantraCompleted by remember { mutableStateOf(false) }
    var capturedPhotoPath by remember { mutableStateOf("") }
    var pendingPhotoFile by remember { mutableStateOf<File?>(null) }
    var cameraNotice by remember { mutableStateOf<String?>(null) }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            capturedPhotoPath = pendingPhotoFile?.absolutePath.orEmpty()
            cameraNotice = null
        }
    }

    fun launchPrivateCamera() {
        try {
            val dir = File(context.filesDir, "private_checkins").apply { mkdirs() }
            val file = File(dir, "wake_${System.currentTimeMillis()}.jpg")
            pendingPhotoFile = file
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            takePictureLauncher.launch(uri)
        } catch (_: Exception) {
            cameraNotice = "No camera app is available on this device — you can still complete check-in without a photo."
        }
    }

    val cameraPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            launchPrivateCamera()
        } else {
            cameraNotice = "Camera permission declined — check-in photo is completely optional."
        }
    }

    LaunchedEffect(isHolding) {
        if (isHolding && !mantraCompleted) {
            val steps = 30
            val start = (holdProgress * steps).toInt()
            for (i in start..steps) {
                if (!isHolding) break
                holdProgress = i / steps.toFloat()
                if (i >= steps) {
                    mantraCompleted = true
                    break
                }
                delay(100L)
            }
        } else if (!mantraCompleted) {
            holdProgress = 0f
        }
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp, Alignment.CenterVertically)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(16.dp))
                Icon(
                    imageVector = Icons.Default.SelfImprovement,
                    contentDescription = "Brahma Muhurta Dawn",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    text = "Brahma Muhurta Check-In",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Hare Krishna! Hold the sacred circle for 3 seconds while chanting one peaceful breath.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }

            // 3-Second Mantra Hold Circle
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(210.dp)
                    .testTag("mantra_hold_circle")
                    .pointerInput(mantraCompleted) {
                        detectTapGestures(
                            onPress = {
                                if (!mantraCompleted) {
                                    isHolding = true
                                    tryAwaitRelease()
                                    isHolding = false
                                }
                            }
                        )
                    }
            ) {
                CircularProgressIndicator(
                    progress = { if (mantraCompleted) 1f else holdProgress },
                    modifier = Modifier.fillMaxSize(),
                    strokeWidth = 10.dp,
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                Surface(
                    shape = CircleShape,
                    color = if (mantraCompleted) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp,
                    modifier = Modifier.size(168.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        if (mantraCompleted) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Mantra Hold Complete",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = "Awake & Centered",
                                style = MaterialTheme.typography.titleSmall,
                                textAlign = TextAlign.Center
                            )
                        } else {
                            Text(
                                text = if (isHolding) "Keep Holding..." else "Hold 3 Seconds",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary,
                                textAlign = TextAlign.Center
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "Hare Krishna",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        val hasCam = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                            PackageManager.PERMISSION_GRANTED
                        if (hasCam) {
                            launchPrivateCamera()
                        } else {
                            cameraPermLauncher.launch(Manifest.permission.CAMERA)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("private_selfie_button")
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null)
                    Spacer(Modifier.size(8.dp))
                    Text(
                        if (capturedPhotoPath.isNotBlank()) "Private On-Device Photo Saved"
                        else "Optional Private Check-In Photo (Stays On-Device)"
                    )
                }

                if (!cameraNotice.isNullOrBlank()) {
                    Text(
                        text = cameraNotice.orEmpty(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Button(
                    onClick = {
                        scope.launch { onCompleteCheckIn(capturedPhotoPath) }
                    },
                    enabled = mantraCompleted,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("complete_wakeup_button")
                ) {
                    Text("Complete Brahma Muhurta Check-In")
                }

                OutlinedButton(
                    onClick = onSnoozeFiveMin,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("snooze_5min_button")
                ) {
                    Icon(Icons.Default.Snooze, contentDescription = null)
                    Spacer(Modifier.size(8.dp))
                    Text("Snooze 5 Minutes")
                }

                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Return to Sadhya")
                }
            }
        }
    }
}
