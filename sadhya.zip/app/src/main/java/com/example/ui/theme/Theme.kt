package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import com.example.model.DarkModePreference
import com.example.model.FontScaleLevel
import com.example.model.ThemeStyle

val SadhyaShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun SadhyaTheme(
    themeStyle: ThemeStyle = ThemeStyle.IVORY_MAROON,
    darkModePreference: DarkModePreference = DarkModePreference.SYSTEM,
    fontScaleLevel: FontScaleLevel = FontScaleLevel.STANDARD,
    elderModeEnabled: Boolean = false,
    content: @Composable () -> Unit
) {
    val useDark = when (darkModePreference) {
        DarkModePreference.LIGHT -> false
        DarkModePreference.DARK -> true
        DarkModePreference.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = when (themeStyle) {
        ThemeStyle.IVORY_MAROON -> if (useDark) IvoryMaroonDarkScheme else IvoryMaroonLightScheme
        ThemeStyle.SAFFRON_SAND -> if (useDark) SaffronSandDarkScheme else SaffronSandLightScheme
        ThemeStyle.VRINDAVAN_FOREST -> if (useDark) VrindavanForestDarkScheme else VrindavanForestLightScheme
    }

    val scale = if (elderModeEnabled) {
        1.18f
    } else {
        when (fontScaleLevel) {
            FontScaleLevel.COMPACT -> 0.92f
            FontScaleLevel.STANDARD -> 1.0f
            FontScaleLevel.LARGE -> 1.14f
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = sadhyaTypography(scale),
        shapes = SadhyaShapes,
        content = content
    )
}
