package com.example.data

import com.example.model.DailyTask
import com.example.model.FocusLog
import com.example.model.SadhanaDailyLog
import com.example.model.ScheduleItem
import com.example.model.TempleCommunity
import com.example.model.TemplePost
import com.example.model.UserProfile
import kotlinx.coroutines.flow.Flow

interface SadhanaDataRepository {
    val isGuestMode: Boolean

    suspend fun ensureUserProfileExists(
        uid: String,
        displayName: String,
        email: String
    ): Result<UserProfile>

    fun observeUserProfile(uid: String): Flow<UserProfile?>
    suspend fun updateUserProfileFields(uid: String, fields: Map<String, Any>): Result<Unit>

    fun observeSchedule(uid: String): Flow<List<ScheduleItem>>
    suspend fun saveScheduleItem(uid: String, item: ScheduleItem): Result<String>
    suspend fun replaceSchedule(uid: String, items: List<ScheduleItem>): Result<Unit>
    suspend fun toggleScheduleCompletion(uid: String, itemId: String, dateKey: String?): Result<Unit>
    suspend fun deleteScheduleItem(uid: String, itemId: String): Result<Unit>

    fun observeTasks(uid: String): Flow<List<DailyTask>>
    suspend fun saveTask(uid: String, task: DailyTask): Result<String>
    suspend fun toggleTaskCompleted(uid: String, taskId: String, completed: Boolean): Result<Unit>
    suspend fun deleteTask(uid: String, taskId: String): Result<Unit>

    fun observeRecentSadhanaLogs(uid: String): Flow<List<SadhanaDailyLog>>
    suspend fun upsertSadhanaLog(uid: String, dateKey: String, transform: (SadhanaDailyLog) -> SadhanaDailyLog): Result<SadhanaDailyLog>

    fun observeFocusLogs(uid: String): Flow<List<FocusLog>>
    suspend fun addFocusLog(uid: String, log: FocusLog): Result<Unit>
    suspend fun deleteFocusLog(uid: String, logId: String): Result<Unit>

    fun observeTemples(): Flow<List<TempleCommunity>>
    suspend fun createTemple(uid: String, temple: TempleCommunity): Result<String>

    fun observeTemplePosts(templeId: String): Flow<List<TemplePost>>
    suspend fun createTemplePost(uid: String, post: TemplePost): Result<String>
    suspend fun deleteTemplePost(templeId: String, postId: String): Result<Unit>
    suspend fun toggleSevaVolunteer(uid: String, templeId: String, postId: String): Result<Unit>

    suspend fun deleteAccountAndData(uid: String): Result<Unit>
}
