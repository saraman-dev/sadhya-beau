package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.alarm.WakeUpAlarmActivity
import com.example.model.DailyTask
import com.example.model.ParsedTaskDraft
import com.example.model.RoutineMode
import com.example.model.SadhanaDailyLog
import com.example.model.ScheduleCategory
import com.example.model.ScheduleItem
import com.example.model.TaskPriority
import com.example.model.TimeMath
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.model.WakeStatus
import com.example.ui.components.ResponsiveContentColumn
import com.example.ui.components.SectionHeader
import com.example.ui.components.TimePickerField
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.viewmodel.AiTaskParseState
import com.example.viewmodel.SadhanaViewModel
import kotlinx.coroutines.delay
import java.util.Calendar
import java.util.TimeZone

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    viewModel: SadhanaViewModel,
    profile: UserProfile,
    onOpenGuide: () -> Unit,
    onJumpToTab: (Int) -> Unit
) {
    val context = LocalContext.current
    val localPrefs by viewModel.localPrefs.collectAsStateWithLifecycle()
    val scheduleState by viewModel.scheduleState.collectAsStateWithLifecycle()
    val tasksState by viewModel.tasksState.collectAsStateWithLifecycle()
    val logsState by viewModel.sadhanaLogsState.collectAsStateWithLifecycle()
    val todayInfo by viewModel.todayInfo.collectAsStateWithLifecycle()
    val audioState by viewModel.audioState.collectAsStateWithLifecycle()
    val taskParseState by viewModel.aiTaskParseState.collectAsStateWithLifecycle()
    val wakeReflection by viewModel.wakeLateReflection.collectAsStateWithLifecycle()
    val isWakeReflectionLoading by viewModel.isWakeReflectionLoading.collectAsStateWithLifecycle()

    val todayKey = viewModel.todayKey()
    val todayLog = (logsState as? UiState.Success)?.data?.firstOrNull { it.dateKey == todayKey }
        ?: SadhanaDailyLog(dateKey = todayKey)
    val scheduleItems = (scheduleState as? UiState.Success)?.data.orEmpty()
    val taskItems = (tasksState as? UiState.Success)?.data.orEmpty()

    var editingScheduleItem by remember { mutableStateOf<ScheduleItem?>(null) }
    var showAddScheduleDialog by remember { mutableStateOf(false) }
    var showAddTaskDialog by remember { mutableStateOf(false) }
    var prefilledTaskDraft by remember { mutableStateOf<ParsedTaskDraft?>(null) }
    var naturalTaskInput by remember { mutableStateOf("") }
    var showWakeLateDialog by remember { mutableStateOf(false) }

    val wakeCheckInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.syncWakeStatusOnTime()
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { res ->
        val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            naturalTaskInput = spoken
            viewModel.parseTaskWithGemini(spoken)
        }
    }

    var clockTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000L)
            clockTick += 1
        }
    }

    val nowCal = remember(clockTick, profile.timezoneId) {
        val tz = TimeZone.getTimeZone(profile.timezoneId.ifBlank { "Asia/Kolkata" })
        Calendar.getInstance(tz)
    }
    val hourOfDay = nowCal.get(Calendar.HOUR_OF_DAY)
    val nowMinutes = hourOfDay * 60 + nowCal.get(Calendar.MINUTE)
    val greeting = when (hourOfDay) {
        in 3..6 -> "Brahma Muhurta Blessings"
        in 7..11 -> "Suprabhatam"
        in 12..16 -> "Peaceful Afternoon"
        in 17..20 -> "Shubh Sandhya"
        else -> "Peaceful Evening Rest"
    }

    val currentOrNext = remember(scheduleItems, nowMinutes) {
        TimeMath.findCurrentOrNextActivity(scheduleItems, nowMinutes)
    }

    val japaGoal = profile.japaTargetRounds.coerceAtLeast(1L)
    val sadhanaProgress = remember(todayLog, japaGoal, profile.readingTargetMinutes, profile.hearingTargetMinutes) {
        val japaPct = (todayLog.japaRounds.toFloat() / japaGoal.toFloat()).coerceIn(0f, 1f)
        val readPct = if (profile.readingTargetMinutes > 0) {
            (todayLog.readingMinutes.toFloat() / profile.readingTargetMinutes.toFloat()).coerceIn(0f, 1f)
        } else 1f
        val hearPct = if (profile.hearingTargetMinutes > 0) {
            (todayLog.hearingMinutes.toFloat() / profile.hearingTargetMinutes.toFloat()).coerceIn(0f, 1f)
        } else 1f
        (japaPct * 0.55f + readPct * 0.25f + hearPct * 0.20f).coerceIn(0f, 1f)
    }

    ResponsiveContentColumn {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Dawn / Day / Evening Hero Header
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(206.dp)
                        .clip(RoundedCornerShape(24.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_dawn_sanctuary),
                        contentDescription = "Sadhya dawn sanctuary banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0x552B0D14), Color(0xDD250B11))
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = Color(0x44FFF8EE)
                            ) {
                                Text(
                                    text = "${localPrefs.devoteePersona.shortTitle} • ${if (viewModel.isGuestMode) "Guest" else "Cloud"}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color(0xFFFFF8EE),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = Color(0x44F0B45A)
                            ) {
                                Text(
                                    text = "Sunrise ${todayInfo.sunriseHHmm}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFFFFF5DE),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Column {
                            Text(
                                text = "$greeting, ${profile.displayName}",
                                style = MaterialTheme.typography.headlineMedium,
                                color = Color(0xFFFFFAF2)
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "${todayInfo.masaName} Masa • ${todayInfo.paksha} ${todayInfo.tithiName}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFFF3DEC6)
                            )
                            if (profile.activeFestivalMode.isNotBlank()) {
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = "Festival Mode: ${profile.activeFestivalMode}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color(0xFFFFD685)
                                )
                            }
                        }
                    }
                }
            }

            // 2. Dismissible 1-Minute Tour Card
            if (!localPrefs.dismissedTourBanner) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("New to Sadhya? Take a 1-Minute Tour", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "See how Japa, Ekadashi, Focus Shield & Temples work together.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Row {
                                TextButton(onClick = { viewModel.dismissTourBanner() }) { Text("Hide") }
                                Button(
                                    onClick = onOpenGuide,
                                    modifier = Modifier.testTag("open_tour_button")
                                ) { Text("Tour") }
                            }
                        }
                    }
                }
            }

            // 3. Next Scheduled Activity + Daily Sadhana Progress
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = if (currentOrNext?.second == true) "Current Activity" else "Next Scheduled Activity",
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            Text(
                                text = "${(sadhanaProgress * 100).toInt()}% Sadhana",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        if (currentOrNext != null) {
                            val (block, isActive) = currentOrNext
                            val untilMin = TimeMath.minutesUntil(nowMinutes, block.startTime)
                            Text(
                                text = block.title,
                                style = MaterialTheme.typography.headlineSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${block.startTime} – ${block.endTime}" +
                                    if (isActive) " • In Progress Now" else " • Starts in ${untilMin / 60}h ${untilMin % 60}m",
                                style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Text("No schedule blocks yet — tap + Add Block below.", style = MaterialTheme.typography.bodyMedium)
                        }

                        LinearProgressIndicator(
                            progress = { sadhanaProgress },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(8.dp))
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Japa: ${todayLog.japaRounds}/$japaGoal rds", style = MaterialTheme.typography.labelSmall)
                            Text("Read: ${todayLog.readingMinutes}/${profile.readingTargetMinutes}m", style = MaterialTheme.typography.labelSmall)
                            Text("Hear: ${todayLog.hearingMinutes}/${profile.hearingTargetMinutes}m", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            // 4. Quick Devotional Audio & Live Darshan Card
            if (localPrefs.showQuickAudioCard) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.GraphicEq, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                Text("Quick Devotional Audio & Live Darshan", style = MaterialTheme.typography.titleSmall)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                val firstTanpura = viewModel.audioPlayer.builtInTanpuraTracks.first()
                                Button(
                                    onClick = { viewModel.audioPlayer.toggleTrack(firstTanpura) },
                                    modifier = Modifier.weight(1f).testTag("home_tanpura_button")
                                ) {
                                    Text(if (audioState.isPlaying) "Pause Tanpura" else "Offline Tanpura")
                                }
                                OutlinedButton(
                                    onClick = {
                                        val portal = viewModel.audioPlayer.devotionalPortals.first()
                                        viewModel.creditPortalVisit(portal)
                                        try {
                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(portal.portalUrl)))
                                        } catch (_: Exception) {
                                            viewModel.showToast("Open ${portal.portalUrl} in your browser")
                                        }
                                    },
                                    modifier = Modifier.weight(1f).testTag("home_live_darshan_button")
                                ) {
                                    Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Mayapur TV")
                                }
                            }
                        }
                    }
                }
            }

            // 5. Brahma Muhurta Wake-Up Check-In Card
            if (localPrefs.showWakeUpCard) {
                item {
                    val wakeStatus = WakeStatus.fromRaw(todayLog.wakeStatus)
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.WbTwilight, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                    Spacer(Modifier.width(8.dp))
                                    Column {
                                        Text("Brahma Muhurta Check-In", style = MaterialTheme.typography.titleSmall)
                                        Text(
                                            "Target ${profile.wakeTime} • ${wakeStatus.label}" +
                                                if (todayLog.wakeActualTime.isNotBlank()) " (${todayLog.wakeActualTime})" else "",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        wakeCheckInLauncher.launch(Intent(context, WakeUpAlarmActivity::class.java))
                                    },
                                    modifier = Modifier.weight(1f).testTag("launch_wakeup_checkin_button")
                                ) {
                                    Icon(Icons.Default.Alarm, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Check In")
                                }
                                OutlinedButton(
                                    onClick = {
                                        showWakeLateDialog = true
                                        viewModel.markWokeLateAndRequestReflection()
                                    },
                                    modifier = Modifier.weight(1f).testTag("woke_late_button")
                                ) {
                                    Text("Woke Late")
                                }
                            }
                        }
                    }
                }
            }

            // 6. Routine Mode Switcher & Schedule Header
            item {
                SectionHeader(
                    title = "Daily Routine",
                    subtitle = "Tap a block to check off today or edit timings",
                    actionLabel = "+ Add Block",
                    onAction = { showAddScheduleDialog = true }
                )
                Spacer(Modifier.height(6.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val activeMode = RoutineMode.fromRaw(profile.routineMode)
                    RoutineMode.entries.forEach { mode ->
                        FilterChip(
                            selected = activeMode == mode,
                            onClick = { if (activeMode != mode) viewModel.switchRoutineMode(mode) },
                            label = { Text(mode.label) },
                            modifier = Modifier.testTag("routine_mode_${mode.name}")
                        )
                    }
                }
            }

            itemsIndexed(scheduleItems, key = { idx, item -> item.id.ifBlank { "sched_$idx" } }) { _, item ->
                val doneToday = item.completedDateKey == todayKey
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("schedule_item_${item.id}")
                        .clickable { viewModel.toggleScheduleComplete(item) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (doneToday) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                        else MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (doneToday) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                            contentDescription = if (doneToday) "Completed" else "Mark complete",
                            tint = if (doneToday) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${item.startTime}–${item.endTime}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                if (item.essential) {
                                    Spacer(Modifier.width(6.dp))
                                    Icon(
                                        Icons.Default.Star,
                                        contentDescription = "Essential block",
                                        tint = MaterialTheme.colorScheme.tertiary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = " Essential",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                            }
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleSmall,
                                textDecoration = if (doneToday) TextDecoration.LineThrough else TextDecoration.None
                            )
                            if (item.notes.isNotBlank()) {
                                Text(
                                    text = item.notes,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        IconButton(onClick = { editingScheduleItem = item }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit block")
                        }
                        IconButton(onClick = { viewModel.deleteScheduleItem(item.id) }) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Delete block")
                        }
                    }
                }
            }

            // 7. Personal Tasks + Natural Language Gemini Parser
            if (localPrefs.showTasksCard) {
                item {
                    Spacer(Modifier.height(6.dp))
                    SectionHeader(
                        title = "Personal Tasks & Seva",
                        subtitle = "Type naturally (e.g., \"Buy tulasi soil at 17:30\") or add manually",
                        actionLabel = "+ Manual",
                        onAction = {
                            prefilledTaskDraft = null
                            showAddTaskDialog = true
                        }
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = naturalTaskInput,
                            onValueChange = { naturalTaskInput = it.take(180) },
                            placeholder = { Text("e.g., Read Gita Ch 4 at 07:30") },
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("natural_task_input")
                        )
                        IconButton(
                            onClick = {
                                val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your task or reminder")
                                }
                                try {
                                    speechLauncher.launch(speechIntent)
                                } catch (_: Exception) {
                                    viewModel.showToast("Voice recognition is not available on this device.")
                                }
                            },
                            modifier = Modifier.testTag("voice_task_button")
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = "Voice task input")
                        }
                        Button(
                            onClick = { viewModel.parseTaskWithGemini(naturalTaskInput) },
                            enabled = naturalTaskInput.isNotBlank() && taskParseState !is AiTaskParseState.Loading,
                            modifier = Modifier.testTag("parse_task_ai_button")
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = "Parse with Gemini", modifier = Modifier.size(18.dp))
                        }
                    }

                    // Show AI Parse Result or Offline 1-Tap Manual Pre-filled Fallback
                    when (val ps = taskParseState) {
                        AiTaskParseState.Loading -> {
                            Row(modifier = Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                                Text("Parsing task with Gemini...", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        is AiTaskParseState.Parsed -> {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Parsed Task Ready", style = MaterialTheme.typography.labelLarge)
                                    Text("${ps.draft.title} (${ps.draft.category}${if (ps.draft.reminderTime.isNotBlank()) " • ${ps.draft.reminderTime}" else ""})")
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(onClick = {
                                            viewModel.saveTask(
                                                DailyTask(
                                                    title = ps.draft.title,
                                                    category = ps.draft.category,
                                                    dueDateKey = todayKey,
                                                    reminderTime = ps.draft.reminderTime,
                                                    priority = ps.draft.priority.name,
                                                    notes = ps.draft.notes
                                                )
                                            )
                                            naturalTaskInput = ""
                                            viewModel.resetTaskParseState()
                                        }) { Text("Save Task") }
                                        OutlinedButton(onClick = {
                                            prefilledTaskDraft = ps.draft
                                            showAddTaskDialog = true
                                            viewModel.resetTaskParseState()
                                        }) { Text("Edit First") }
                                    }
                                }
                            }
                        }
                        is AiTaskParseState.FallbackNeeded -> {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        "Gemini is offline right now — save directly instead:",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = {
                                                prefilledTaskDraft = ParsedTaskDraft(title = ps.rawInput)
                                                showAddTaskDialog = true
                                                viewModel.resetTaskParseState()
                                            },
                                            modifier = Modifier.testTag("add_manually_prefilled_button")
                                        ) {
                                            Text("Add Manually (Pre-filled)")
                                        }
                                        TextButton(onClick = { viewModel.resetTaskParseState() }) { Text("Dismiss") }
                                    }
                                }
                            }
                        }
                        AiTaskParseState.Idle -> Unit
                    }
                }

                itemsIndexed(taskItems, key = { idx, task -> task.id.ifBlank { "task_$idx" } }) { _, task ->
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("task_card_${task.id}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = task.completed,
                                onCheckedChange = { viewModel.toggleTaskCompleted(task) }
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = task.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    textDecoration = if (task.completed) TextDecoration.LineThrough else TextDecoration.None
                                )
                                Text(
                                    text = buildString {
                                        append(task.category)
                                        if (task.reminderTime.isNotBlank()) append(" • Reminder ${task.reminderTime}")
                                        append(" • ${TaskPriority.fromRaw(task.priority).label}")
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { viewModel.deleteTask(task.id) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete task")
                            }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(72.dp)) }
        }
    }

    // Add / Edit Schedule Dialog
    if (showAddScheduleDialog || editingScheduleItem != null) {
        val editing = editingScheduleItem
        var title by remember(editing) { mutableStateOf(editing?.title ?: "") }
        var startTime by remember(editing) { mutableStateOf(editing?.startTime ?: "05:30") }
        var endTime by remember(editing) { mutableStateOf(editing?.endTime ?: "06:30") }
        var category by remember(editing) { mutableStateOf(ScheduleCategory.fromRaw(editing?.category)) }
        var essential by remember(editing) { mutableStateOf(editing?.essential ?: false) }
        var notes by remember(editing) { mutableStateOf(editing?.notes ?: "") }

        AlertDialog(
            onDismissRequest = {
                showAddScheduleDialog = false
                editingScheduleItem = null
            },
            title = { Text(if (editing == null) "Add Schedule Block" else "Edit Schedule Block") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it.take(120) },
                        label = { Text("Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TimePickerField("Start", startTime, { startTime = it }, Modifier.weight(1f))
                        TimePickerField("End", endTime, { endTime = it }, Modifier.weight(1f))
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(
                            ScheduleCategory.JAPA, ScheduleCategory.AARTI, ScheduleCategory.READING,
                            ScheduleCategory.HEARING, ScheduleCategory.SEVA, ScheduleCategory.WORK,
                            ScheduleCategory.STUDY, ScheduleCategory.REST
                        ).forEach { cat ->
                            FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat.label) })
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Essential Block (Protected by AI)")
                        Switch(checked = essential, onCheckedChange = { essential = it })
                    }
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it.take(300) },
                        label = { Text("Optional Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveScheduleItem(
                            ScheduleItem(
                                id = editing?.id ?: "",
                                title = title.trim().ifBlank { category.label },
                                category = category.name,
                                startTime = startTime,
                                endTime = endTime,
                                essential = essential,
                                completedDateKey = editing?.completedDateKey ?: "",
                                notes = notes.trim(),
                                sortOrder = editing?.sortOrder ?: (scheduleItems.size + 1L)
                            )
                        )
                        showAddScheduleDialog = false
                        editingScheduleItem = null
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showAddScheduleDialog = false
                    editingScheduleItem = null
                }) { Text("Cancel") }
            }
        )
    }

    // Add Task Dialog (Manual or Pre-filled from Fallback)
    if (showAddTaskDialog) {
        val draft = prefilledTaskDraft
        var title by remember(draft) { mutableStateOf(draft?.title ?: "") }
        var category by remember(draft) { mutableStateOf(draft?.category ?: "Devotion") }
        var reminderTime by remember(draft) { mutableStateOf(draft?.reminderTime ?: "") }
        var priority by remember(draft) { mutableStateOf(draft?.priority ?: TaskPriority.MEDIUM) }
        var notes by remember(draft) { mutableStateOf(draft?.notes ?: "") }

        AlertDialog(
            onDismissRequest = { showAddTaskDialog = false },
            title = { Text("Add Personal Task") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it.take(160) },
                        label = { Text("Task Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it.take(40) },
                        label = { Text("Category") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    TimePickerField("Optional Reminder Time", reminderTime, { reminderTime = it })
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TaskPriority.entries.forEach { pr ->
                            FilterChip(selected = priority == pr, onClick = { priority = pr }, label = { Text(pr.label) })
                        }
                    }
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it.take(400) },
                        label = { Text("Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = title.isNotBlank(),
                    onClick = {
                        viewModel.saveTask(
                            DailyTask(
                                title = title.trim(),
                                category = category.trim().ifBlank { "Devotion" },
                                dueDateKey = todayKey,
                                reminderTime = reminderTime,
                                priority = priority.name,
                                notes = notes.trim()
                            )
                        )
                        naturalTaskInput = ""
                        showAddTaskDialog = false
                    }
                ) { Text("Save Task") }
            },
            dismissButton = {
                TextButton(onClick = { showAddTaskDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Compassionate Woke-Late Reflection Dialog (closing NEVER overwrites saved status)
    if (showWakeLateDialog) {
        AlertDialog(
            onDismissRequest = {
                showWakeLateDialog = false
                viewModel.clearWakeLateReflection()
            },
            title = { Text("Gentle Morning Reflection") },
            text = {
                if (isWakeReflectionLoading) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Preparing an encouraging note...")
                    }
                } else {
                    Text(
                        wakeReflection
                            ?: "Hare Krishna! Begin peacefully right where you are. Even a few attentive rounds now uplift the whole day.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    showWakeLateDialog = false
                    viewModel.clearWakeLateReflection()
                    onJumpToTab(1)
                }) {
                    Text("Go to Japa")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showWakeLateDialog = false
                    viewModel.clearWakeLateReflection()
                }) {
                    Text("Close")
                }
            }
        )
    }
}
