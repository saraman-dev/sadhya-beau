package com.example.engine

import com.example.data.local.ImportedCalendarEventEntity
import java.util.Locale

object IcsCalendarParser {

    fun parse(icsContent: String, sourceName: String = "Imported .ics"): List<ImportedCalendarEventEntity> {
        if (icsContent.isBlank()) return emptyList()

        // Unfold RFC 5545 folded lines (CRLF or LF followed by single space/tab)
        val unfolded = icsContent
            .replace("\r\n ", "")
            .replace("\r\n\t", "")
            .replace("\n ", "")
            .replace("\n\t", "")

        val lines = unfolded.split(Regex("\\r?\\n"))
        val events = mutableListOf<ImportedCalendarEventEntity>()

        var inEvent = false
        var summary = ""
        var description = ""
        var location = ""
        var dtStartRaw = ""
        var dtEndRaw = ""

        for (rawLine in lines) {
            val line = rawLine.trim()
            when {
                line.equals("BEGIN:VEVENT", ignoreCase = true) -> {
                    inEvent = true
                    summary = ""
                    description = ""
                    location = ""
                    dtStartRaw = ""
                    dtEndRaw = ""
                }
                line.equals("END:VEVENT", ignoreCase = true) -> {
                    if (inEvent && summary.isNotBlank() && dtStartRaw.isNotBlank()) {
                        val (dateKey, startTime) = parseIcsDateTime(dtStartRaw)
                        val (_, endTime) = if (dtEndRaw.isNotBlank()) parseIcsDateTime(dtEndRaw) else "" to ""
                        if (dateKey.isNotBlank()) {
                            events.add(
                                ImportedCalendarEventEntity(
                                    dateKey = dateKey,
                                    title = unescapeIcsText(summary).take(140),
                                    startTime = startTime,
                                    endTime = endTime,
                                    description = unescapeIcsText(description).take(400),
                                    location = unescapeIcsText(location).take(120),
                                    sourceName = sourceName.take(60)
                                )
                            )
                        }
                    }
                    inEvent = false
                }
                inEvent -> {
                    val colonIdx = line.indexOf(':')
                    if (colonIdx > 0) {
                        val keyPart = line.substring(0, colonIdx).uppercase(Locale.US)
                        val valuePart = line.substring(colonIdx + 1).trim()
                        val baseKey = keyPart.substringBefore(';')
                        when (baseKey) {
                            "SUMMARY" -> summary = valuePart
                            "DESCRIPTION" -> description = valuePart
                            "LOCATION" -> location = valuePart
                            "DTSTART" -> dtStartRaw = valuePart
                            "DTEND" -> dtEndRaw = valuePart
                        }
                    }
                }
            }
        }
        return events.sortedWith(compareBy<ImportedCalendarEventEntity> { it.dateKey }.thenBy { it.startTime })
    }

    private fun parseIcsDateTime(raw: String): Pair<String, String> {
        val cleaned = raw.trim().removeSuffix("Z")
        val datePart = cleaned.substringBefore('T')
        if (datePart.length < 8) return "" to ""
        val yyyy = datePart.substring(0, 4)
        val mm = datePart.substring(4, 6)
        val dd = datePart.substring(6, 8)
        if (!yyyy.all { it.isDigit() } || !mm.all { it.isDigit() } || !dd.all { it.isDigit() }) {
            return "" to ""
        }
        val dateKey = "$yyyy-$mm-$dd"
        val timePart = if (cleaned.contains('T')) cleaned.substringAfter('T') else ""
        val hhmm = if (timePart.length >= 4 && timePart.substring(0, 4).all { it.isDigit() }) {
            "${timePart.substring(0, 2)}:${timePart.substring(2, 4)}"
        } else ""
        return dateKey to hhmm
    }

    private fun unescapeIcsText(text: String): String =
        text.replace("\\n", "\n")
            .replace("\\,", ",")
            .replace("\\;", ";")
            .replace("\\\\", "\\")
            .trim()
}
