package com.example.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

// ============================================================
// THEME 1: Ivory & Deep Maroon (Default)
// ============================================================
val IvoryBackground = Color(0xFFFAF6EE)
val ParchmentSurface = Color(0xFFFFFDF8)
val ParchmentVariant = Color(0xFFF2E9D8)
val DeepMaroon = Color(0xFF6B1D2B)
val DeepMaroonContainer = Color(0xFFF6D9DF)
val OnDeepMaroonContainer = Color(0xFF3A0913)
val SaffronAccent = Color(0xFFD67222)
val SaffronContainer = Color(0xFFFFE4CC)
val OnSaffronContainer = Color(0xFF472000)
val SacredGold = Color(0xFFB5851A)
val SacredGoldContainer = Color(0xFFF9EBBF)
val OnSacredGoldContainer = Color(0xFF3A2900)
val InkCharcoal = Color(0xFF231819)
val WarmOutline = Color(0xFF8C736B)

val NightUmber = Color(0xFF151012)
val NightUmberSurface = Color(0xFF20181B)
val NightUmberVariant = Color(0xFF2E2226)
val LuminousGold = Color(0xFFF0B45A)
val LuminousGoldContainer = Color(0xFF5A3E10)
val SoftRoseMaroon = Color(0xFFF4A9B8)
val DarkMaroonContainer = Color(0xFF561522)
val WarmIvoryText = Color(0xFFF6EFE4)

val IvoryMaroonLightScheme = lightColorScheme(
    primary = DeepMaroon,
    onPrimary = Color(0xFFFFFBF7),
    primaryContainer = DeepMaroonContainer,
    onPrimaryContainer = OnDeepMaroonContainer,
    secondary = SaffronAccent,
    onSecondary = Color(0xFFFFFBF7),
    secondaryContainer = SaffronContainer,
    onSecondaryContainer = OnSaffronContainer,
    tertiary = SacredGold,
    onTertiary = Color(0xFFFFFBF7),
    tertiaryContainer = SacredGoldContainer,
    onTertiaryContainer = OnSacredGoldContainer,
    background = IvoryBackground,
    onBackground = InkCharcoal,
    surface = ParchmentSurface,
    onSurface = InkCharcoal,
    surfaceVariant = ParchmentVariant,
    onSurfaceVariant = Color(0xFF554340),
    outline = WarmOutline,
    outlineVariant = Color(0xFFDCCEC2)
)

val IvoryMaroonDarkScheme = darkColorScheme(
    primary = LuminousGold,
    onPrimary = Color(0xFF332000),
    primaryContainer = DarkMaroonContainer,
    onPrimaryContainer = Color(0xFFFFD9E0),
    secondary = Color(0xFFFFB77C),
    onSecondary = Color(0xFF4A2500),
    secondaryContainer = Color(0xFF6B380B),
    onSecondaryContainer = Color(0xFFFFDFC7),
    tertiary = SoftRoseMaroon,
    onTertiary = Color(0xFF4F1120),
    tertiaryContainer = LuminousGoldContainer,
    onTertiaryContainer = Color(0xFFFFE6B8),
    background = NightUmber,
    onBackground = WarmIvoryText,
    surface = NightUmberSurface,
    onSurface = WarmIvoryText,
    surfaceVariant = NightUmberVariant,
    onSurfaceVariant = Color(0xFFD7C6C0),
    outline = Color(0xFF9F8B86),
    outlineVariant = Color(0xFF45363B)
)

// ============================================================
// THEME 2: Saffron & Sand
// ============================================================
val SaffronSandLightScheme = lightColorScheme(
    primary = Color(0xFFB8540D),
    onPrimary = Color(0xFFFFFBF7),
    primaryContainer = Color(0xFFFFDFC4),
    onPrimaryContainer = Color(0xFF421900),
    secondary = Color(0xFF7B4B1A),
    onSecondary = Color(0xFFFFFBF7),
    secondaryContainer = Color(0xFFF6DFC3),
    onSecondaryContainer = Color(0xFF341C04),
    tertiary = Color(0xFF8C2D38),
    onTertiary = Color(0xFFFFFBF7),
    tertiaryContainer = Color(0xFFFCD9DC),
    onTertiaryContainer = Color(0xFF3B0910),
    background = Color(0xFFFDF7EE),
    onBackground = Color(0xFF241A12),
    surface = Color(0xFFFFFCF7),
    onSurface = Color(0xFF241A12),
    surfaceVariant = Color(0xFFF3E7D3),
    onSurfaceVariant = Color(0xFF5A493A),
    outline = Color(0xFF8E7966),
    outlineVariant = Color(0xFFE0D1BC)
)

val SaffronSandDarkScheme = darkColorScheme(
    primary = Color(0xFFFFB47B),
    onPrimary = Color(0xFF481C00),
    primaryContainer = Color(0xFF763404),
    onPrimaryContainer = Color(0xFFFFE1C8),
    secondary = Color(0xFFE8C08D),
    onSecondary = Color(0xFF3F2607),
    secondaryContainer = Color(0xFF5D3A13),
    onSecondaryContainer = Color(0xFFFFE4C4),
    tertiary = Color(0xFFF5B2BA),
    onTertiary = Color(0xFF52131D),
    tertiaryContainer = Color(0xFF71222C),
    onTertiaryContainer = Color(0xFFFFDADE),
    background = Color(0xFF17120E),
    onBackground = Color(0xFFF6EDE2),
    surface = Color(0xFF211A14),
    onSurface = Color(0xFFF6EDE2),
    surfaceVariant = Color(0xFF31271E),
    onSurfaceVariant = Color(0xFFD6C4B3),
    outline = Color(0xFF9F8D7D),
    outlineVariant = Color(0xFF4A3D31)
)

// ============================================================
// THEME 3: Vrindavan Forest
// ============================================================
val VrindavanForestLightScheme = lightColorScheme(
    primary = Color(0xFF24573D),
    onPrimary = Color(0xFFF7FBF8),
    primaryContainer = Color(0xFFCDE9D7),
    onPrimaryContainer = Color(0xFF0A2A1A),
    secondary = Color(0xFFB57B1C),
    onSecondary = Color(0xFFFFFBF5),
    secondaryContainer = Color(0xFFFBE7C0),
    onSecondaryContainer = Color(0xFF3A2400),
    tertiary = Color(0xFF7D3443),
    onTertiary = Color(0xFFFFFBF7),
    tertiaryContainer = Color(0xFFF8D9DF),
    onTertiaryContainer = Color(0xFF360B15),
    background = Color(0xFFF5F7F1),
    onBackground = Color(0xFF17211B),
    surface = Color(0xFFFBFCF8),
    onSurface = Color(0xFF17211B),
    surfaceVariant = Color(0xFFE3ECE2),
    onSurfaceVariant = Color(0xFF425247),
    outline = Color(0xFF718376),
    outlineVariant = Color(0xFFC6D4C7)
)

val VrindavanForestDarkScheme = darkColorScheme(
    primary = Color(0xFF8FD5AE),
    onPrimary = Color(0xFF0A3320),
    primaryContainer = Color(0xFF18442E),
    onPrimaryContainer = Color(0xFFCDEFD9),
    secondary = Color(0xFFF2C26B),
    onSecondary = Color(0xFF3D2700),
    secondaryContainer = Color(0xFF5D3E08),
    onSecondaryContainer = Color(0xFFFFE5B8),
    tertiary = Color(0xFFF1B0BD),
    onTertiary = Color(0xFF4E1422),
    tertiaryContainer = Color(0xFF6B2534),
    onTertiaryContainer = Color(0xFFFFD9E0),
    background = Color(0xFF0F1612),
    onBackground = Color(0xFFEBF2EC),
    surface = Color(0xFF17201B),
    onSurface = Color(0xFFEBF2EC),
    surfaceVariant = Color(0xFF233028),
    onSurfaceVariant = Color(0xFFBFCEC3),
    outline = Color(0xFF88998D),
    outlineVariant = Color(0xFF35453B)
)
