package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.FocusRuleEntity
import com.example.focus.FocusInterruptionActivity
import com.example.focus.UsageStatsHelper
import com.example.model.FocusOutcome
import com.example.model.FocusStrictness
import com.example.model.TimeMath
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.ui.components.ResponsiveContentColumn
import com.example.ui.components.SectionHeader
import com.example.ui.components.TimePickerField
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.viewmodel.SadhanaViewModel
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FocusScreen(
    viewModel: SadhanaViewModel,
    profile: UserProfile
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val localPrefs by viewModel.localPrefs.collectAsStateWithLifecycle()
    val focusRemainingSec by viewModel.focusRemainingSec.collectAsStateWithLifecycle()
    val focusRules by viewModel.focusRules.collectAsStateWithLifecycle()
    val focusLogsState by viewModel.focusLogsState.collectAsStateWithLifecycle()

    var hasUsageAccess by remember { mutableStateOf(UsageStatsHelper.hasUsageAccessPermission(context)) }
    var hasOverlayAccess by remember { mutableStateOf(UsageStatsHelper.hasOverlayPermission(context)) }

    DisposableEffect(lifecycleOwner, context) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasUsageAccess = UsageStatsHelper.hasUsageAccessPermission(context)
                hasOverlayAccess = UsageStatsHelper.hasOverlayPermission(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    var selectedDuration by remember { mutableIntStateOf(localPrefs.focusShieldDurationMinutes.coerceIn(15, 60)) }
    var selectedStrictness by remember(profile.focusStrictness) {
        mutableStateOf(FocusStrictness.fromRaw(profile.focusStrictness))
    }
    var showAddAppDialog by remember { mutableStateOf(false) }

    val focusLogs = (focusLogsState as? UiState.Success)?.data.orEmpty()
    val isShieldActive = localPrefs.focusShieldActive && focusRemainingSec > 0L

    ResponsiveContentColumn(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Live Focus Shield Control Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isShieldActive) MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(
                        1.dp,
                        if (isShieldActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Sadhana Focus Shield",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (isShieldActive) "Focus Shield Active" else "Sadhana Focus Shield",
                                    style = MaterialTheme.typography.headlineSmall
                                )
                                Text(
                                    text = if (isShieldActive) {
                                        "Guarding your chanting, reading & study peacefully."
                                    } else {
                                        "Gently pause distracting apps with a calm Mindful Pause."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (isShieldActive) {
                            val mins = focusRemainingSec / 60L
                            val secs = focusRemainingSec % 60L
                            val countdown = String.format(Locale.US, "%02d:%02d", mins, secs)
                            Text(
                                text = countdown,
                                style = MaterialTheme.typography.displayMedium.copy(fontFamily = JetBrainsMonoFamily),
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.testTag("focus_countdown_text")
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = { viewModel.stopFocusShield() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.error,
                                        contentColor = MaterialTheme.colorScheme.onError
                                    ),
                                    modifier = Modifier.testTag("focus_stop_button")
                                ) {
                                    Icon(Icons.Default.Stop, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("End Session")
                                }
                                OutlinedButton(
                                    onClick = {
                                        context.startActivity(
                                            Intent(context, FocusInterruptionActivity::class.java).apply {
                                                putExtra(FocusInterruptionActivity.EXTRA_PACKAGE, "com.instagram.android")
                                                putExtra(FocusInterruptionActivity.EXTRA_APP_LABEL, "Instagram (Preview)")
                                                putExtra(FocusInterruptionActivity.EXTRA_STRICTNESS, selectedStrictness.name)
                                            }
                                        )
                                    },
                                    modifier = Modifier.testTag("focus_preview_pause_button")
                                ) {
                                    Icon(Icons.Default.Visibility, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text("Preview Pause")
                                }
                            }
                        } else {
                            Text("Session Duration", style = MaterialTheme.typography.labelLarge)
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(15, 30, 45, 60).forEach { mins ->
                                    FilterChip(
                                        selected = selectedDuration == mins,
                                        onClick = { selectedDuration = mins },
                                        label = { Text("${mins}m") },
                                        modifier = Modifier.testTag("focus_duration_$mins")
                                    )
                                }
                            }

                            Text("Mindful Pause Strictness", style = MaterialTheme.typography.labelLarge)
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                FocusStrictness.entries.forEach { st ->
                                    FilterChip(
                                        selected = selectedStrictness == st,
                                        onClick = { selectedStrictness = st },
                                        label = { Text(st.label) },
                                        modifier = Modifier.testTag("focus_strictness_${st.name}")
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.startFocusShield(selectedDuration, selectedStrictness) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("focus_start_button")
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        if (hasUsageAccess) "Start Focus Shield"
                                        else "Start Timer-Only Shield"
                                    )
                                }
                                OutlinedButton(
                                    onClick = {
                                        context.startActivity(
                                            Intent(context, FocusInterruptionActivity::class.java).apply {
                                                putExtra(FocusInterruptionActivity.EXTRA_PACKAGE, "com.instagram.android")
                                                putExtra(FocusInterruptionActivity.EXTRA_APP_LABEL, "Instagram (Preview)")
                                                putExtra(FocusInterruptionActivity.EXTRA_STRICTNESS, selectedStrictness.name)
                                            }
                                        )
                                    },
                                    modifier = Modifier.testTag("focus_preview_pause_idle_button")
                                ) {
                                    Text("Preview")
                                }
                            }
                        }
                    }
                }
            }

            // 2. Transparent 2-Step Android 10+ Permission Setup Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SectionHeader(
                            title = "2-Step Android App Shield Setup",
                            subtitle = "Optional permissions for automatic foreground detection on Android 10+. Without them, Sadhya still runs a peaceful focus timer & gentle notifications."
                        )

                        PermissionStepRow(
                            stepLabel = "Step 1: Usage Access",
                            description = "Detects when a guarded app opens during active Focus Shield.",
                            granted = hasUsageAccess,
                            buttonTag = "focus_usage_permission_button",
                            onOpenSettings = {
                                try {
                                    context.startActivity(UsageStatsHelper.usageAccessSettingsIntent())
                                } catch (_: Exception) {
                                    viewModel.showToast("Open Android Settings → Apps → Special Access → Usage Access")
                                }
                            }
                        )

                        PermissionStepRow(
                            stepLabel = "Step 2: Display Over Other Apps",
                            description = "Allows Android 10+ to show the Mindful Pause card above guarded apps (falls back to a high-priority notification if disabled).",
                            granted = hasOverlayAccess,
                            buttonTag = "focus_overlay_permission_button",
                            onOpenSettings = {
                                try {
                                    context.startActivity(UsageStatsHelper.overlaySettingsIntent(context))
                                } catch (_: Exception) {
                                    viewModel.showToast("Open Android Settings → Display over other apps → Sadhya")
                                }
                            }
                        )
                    }
                }
            }

            // 3. 3-Stage Bedtime Wind-Down Card
            item {
                val sleepMins = TimeMath.parseHHmmToMinutes(profile.sleepTime)
                val t30 = TimeMath.formatMinutesToHHmm(sleepMins - 30)
                val t15 = TimeMath.formatMinutesToHHmm(sleepMins - 15)

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Bedtime,
                                    contentDescription = "Bedtime Wind-Down",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Column {
                                    Text("3-Stage Bedtime Wind-Down", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "Reminders at $t30 (-30m), $t15 (-15m) & ${profile.sleepTime}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Switch(
                                checked = localPrefs.bedtimeWindDownEnabled,
                                onCheckedChange = { enabled ->
                                    viewModel.updateAlarms(bedtimeEnabled = enabled)
                                },
                                modifier = Modifier.testTag("focus_bedtime_switch")
                            )
                        }

                        TimePickerField(
                            label = "Target Sleep Time",
                            timeHHmm = profile.sleepTime,
                            onTimeSelected = { nextTime ->
                                viewModel.updateAlarms(bedtimeTime = nextTime)
                            },
                            testTag = "focus_bedtime_picker"
                        )
                    }
                }
            }

            // 4. Guarded Apps List (Room FocusRuleEntity)
            item {
                SectionHeader(
                    title = "Guarded Apps",
                    subtitle = "Saved privately on your device",
                    actionLabel = "+ Add App",
                    onAction = { showAddAppDialog = true }
                )
            }

            items(focusRules, key = { it.packageName }) { rule ->
                FocusRuleCard(
                    rule = rule,
                    onToggleFocus = { checked -> viewModel.toggleFocusRule(rule, blockFocus = checked) },
                    onToggleBedtime = { checked -> viewModel.toggleFocusRule(rule, blockBedtime = checked) },
                    onDelete = { viewModel.deleteFocusRule(rule.packageName) }
                )
            }

            // 5. Recent Focus Sessions Log
            item {
                SectionHeader(
                    title = "Recent Mindful Focus Log",
                    subtitle = if (focusLogs.isEmpty()) "Completed sessions and mindful pauses appear here"
                    else "${focusLogs.size} recent entries"
                )
            }

            if (focusLogs.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "Start a Focus Shield session above to build a serene habit of distraction-free Japa, reading, and study.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(focusLogs.take(10), key = { it.id.ifBlank { "${it.packageName}_${it.createdAt}" } }) { log ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(log.appLabel.ifBlank { log.packageName }, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    text = "${FocusOutcome.fromRaw(log.outcome).label} • ${FocusStrictness.fromRaw(log.strictness).label}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                if (log.reason.isNotBlank()) {
                                    Text(
                                        text = log.reason,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            if (log.durationMinutes > 0L) {
                                Text(
                                    text = "${log.durationMinutes}m",
                                    style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFamily),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddAppDialog) {
        var appLabel by remember { mutableStateOf("") }
        var packageName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddAppDialog = false },
            title = { Text("Add App to Guard") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = appLabel,
                        onValueChange = { appLabel = it.take(40) },
                        label = { Text("App Name (e.g., Threads)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = packageName,
                        onValueChange = { packageName = it.take(100) },
                        label = { Text("Android Package ID (e.g., com.instagram.barcelona)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addCustomFocusRule(packageName, appLabel)
                        showAddAppDialog = false
                    },
                    enabled = appLabel.isNotBlank() && packageName.contains(".")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Add Rule")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddAppDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun PermissionStepRow(
    stepLabel: String,
    description: String,
    granted: Boolean,
    buttonTag: String,
    onOpenSettings: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(
            imageVector = if (granted) Icons.Default.CheckCircle else if (stepLabel.contains("1")) Icons.Default.Security else Icons.Default.Layers,
            contentDescription = stepLabel,
            tint = if (granted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = if (granted) "$stepLabel (Enabled)" else stepLabel,
                style = MaterialTheme.typography.titleSmall
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        if (!granted) {
            OutlinedButton(
                onClick = onOpenSettings,
                modifier = Modifier.testTag(buttonTag)
            ) {
                Text("Enable")
            }
        }
    }
}

@Composable
private fun FocusRuleCard(
    rule: FocusRuleEntity,
    onToggleFocus: (Boolean) -> Unit,
    onToggleBedtime: (Boolean) -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(rule.appLabel, style = MaterialTheme.typography.titleMedium)
                    Text(
                        rule.packageName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Remove ${rule.appLabel}",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Focus Shield", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.width(8.dp))
                    Switch(
                        checked = rule.blockDuringFocus,
                        onCheckedChange = onToggleFocus
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Bedtime", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.width(8.dp))
                    Switch(
                        checked = rule.blockDuringBedtime,
                        onCheckedChange = onToggleBedtime
                    )
                }
            }
        }
    }
}
