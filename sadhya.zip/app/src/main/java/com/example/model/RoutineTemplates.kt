package com.example.model

import java.util.Locale

object TimeMath {
    fun parseHHmmToMinutes(timeStr: String): Int {
        val parts = timeStr.trim().split(":")
        if (parts.size != 2) return 0
        val h = parts[0].toIntOrNull()?.coerceIn(0, 23) ?: return 0
        val m = parts[1].toIntOrNull()?.coerceIn(0, 59) ?: return 0
        return h * 60 + m
    }

    fun formatMinutesToHHmm(totalMinutes: Int): String {
        val normalized = ((totalMinutes % 1440) + 1440) % 1440
        val h = normalized / 60
        val m = normalized % 60
        return String.format(Locale.US, "%02d:%02d", h, m)
    }

    /**
     * Correctly handles overnight blocks where endTime < startTime (e.g., 21:30 -> 04:00).
     */
    fun isTimeInBlock(nowMinutes: Int, startTime: String, endTime: String): Boolean {
        val start = parseHHmmToMinutes(startTime)
        val end = parseHHmmToMinutes(endTime)
        if (start == end) return false
        return if (end > start) {
            nowMinutes in start until end
        } else {
            // Overnight span: [start, 1440) U [0, end)
            nowMinutes >= start || nowMinutes < end
        }
    }

    /**
     * Duration of block in minutes, supporting overnight wrap-around.
     */
    fun blockDurationMinutes(startTime: String, endTime: String): Int {
        val start = parseHHmmToMinutes(startTime)
        val end = parseHHmmToMinutes(endTime)
        return if (end >= start) end - start else (1440 - start) + end
    }

    /**
     * Returns either the currently active block (including overnight blocks) or the soonest upcoming block.
     */
    fun findCurrentOrNextActivity(items: List<ScheduleItem>, nowMinutes: Int): Pair<ScheduleItem, Boolean>? {
        if (items.isEmpty()) return null
        val active = items.firstOrNull { isTimeInBlock(nowMinutes, it.startTime, it.endTime) }
        if (active != null) return active to true

        val next = items.minByOrNull { item ->
            val start = parseHHmmToMinutes(item.startTime)
            val delta = start - nowMinutes
            if (delta >= 0) delta else delta + 1440
        } ?: return null
        return next to false
    }

    fun minutesUntil(nowMinutes: Int, targetHHmm: String): Int {
        val target = parseHHmmToMinutes(targetHHmm)
        val diff = target - nowMinutes
        return if (diff >= 0) diff else diff + 1440
    }
}

object RoutineTemplates {

    fun scheduleForPersona(persona: DevoteePersona): List<ScheduleItem> {
        return when (persona) {
            DevoteePersona.NEWCOMER -> listOf(
                ScheduleItem("tpl_1", "Gentle Morning Japa (4 Rounds)", ScheduleCategory.JAPA.name, "06:15", "06:50", true, notes = "Chant peacefully with clear pronunciation", sortOrder = 1),
                ScheduleItem("tpl_2", "Bhagavad-gita Reading (15 min)", ScheduleCategory.READING.name, "06:55", "07:15", true, notes = "Start with one short section a day", sortOrder = 2),
                ScheduleItem("tpl_3", "Daily Work / Study", ScheduleCategory.WORK.name, "09:00", "17:30", false, notes = "Offer your honest work in a spirit of service", sortOrder = 3),
                ScheduleItem("tpl_4", "Evening Kirtan or Class (15 min)", ScheduleCategory.HEARING.name, "19:30", "19:50", false, notes = "Listen to soothing kirtan or introductory talk", sortOrder = 4),
                ScheduleItem("tpl_5", "Restful Night Sleep", ScheduleCategory.REST.name, "22:30", "06:00", true, notes = "Early rest supports a peaceful morning", sortOrder = 5)
            )
            DevoteePersona.FIRST_INITIATED -> listOf(
                ScheduleItem("tpl_1", "Mangal Aarti & Tulasi Puja", ScheduleCategory.AARTI.name, "04:30", "05:00", true, notes = "Online or home altar darshan", sortOrder = 1),
                ScheduleItem("tpl_2", "Morning Japa Meditation (16 Rounds)", ScheduleCategory.JAPA.name, "05:00", "07:00", true, notes = "Attentive chanting before daily duties", sortOrder = 2),
                ScheduleItem("tpl_3", "Srimad-Bhagavatam Reading", ScheduleCategory.READING.name, "07:15", "07:45", true, notes = "Daily scriptural study", sortOrder = 3),
                ScheduleItem("tpl_4", "Daily Responsibilities & Seva", ScheduleCategory.WORK.name, "09:00", "17:30", false, notes = "Balanced service and vocation", sortOrder = 4),
                ScheduleItem("tpl_5", "Evening Sandhya Aarti & Hearing", ScheduleCategory.HEARING.name, "19:00", "19:45", false, notes = "Gaura Aarti and recorded lecture", sortOrder = 5),
                ScheduleItem("tpl_6", "Early Rest for Brahma Muhurta", ScheduleCategory.REST.name, "21:30", "04:15", true, notes = "Overnight rest block", sortOrder = 6)
            )
            DevoteePersona.SECOND_INITIATED -> listOf(
                ScheduleItem("tpl_1", "Mangal Aarti & Morning Puja", ScheduleCategory.AARTI.name, "04:30", "05:00", true, notes = "Home or temple morning worship", sortOrder = 1),
                ScheduleItem("tpl_2", "Morning Japa (16 Rounds)", ScheduleCategory.JAPA.name, "05:00", "06:45", true, notes = "Dedicated morning rounds", sortOrder = 2),
                ScheduleItem("tpl_3", "Morning Sandhya (Pratah)", ScheduleCategory.GAYATRI.name, "06:15", "06:30", true, notes = "Discreet morning Sandhya reminder", sortOrder = 3),
                ScheduleItem("tpl_4", "Deity Archana & Srimad-Bhagavatam", ScheduleCategory.PUJA.name, "07:00", "08:00", true, notes = "Altar service and scripture", sortOrder = 4),
                ScheduleItem("tpl_5", "Midday Sandhya (Madhyahna)", ScheduleCategory.GAYATRI.name, "12:15", "12:30", true, notes = "Discreet midday Sandhya reminder", sortOrder = 5),
                ScheduleItem("tpl_6", "Evening Sandhya (Sayam)", ScheduleCategory.GAYATRI.name, "18:15", "18:30", true, notes = "Discreet evening Sandhya reminder", sortOrder = 6),
                ScheduleItem("tpl_7", "Evening Kirtan & Study", ScheduleCategory.READING.name, "19:00", "19:45", false, notes = "Reflective evening reading", sortOrder = 7),
                ScheduleItem("tpl_8", "Night Rest", ScheduleCategory.REST.name, "21:30", "04:00", true, notes = "Overnight rest block", sortOrder = 8)
            )
            DevoteePersona.TEMPLE_RESIDENT -> listOf(
                ScheduleItem("tpl_1", "Mangal Aarti & Tulasi Arati", ScheduleCategory.AARTI.name, "04:30", "05:15", true, notes = "Full ashram morning program", sortOrder = 1),
                ScheduleItem("tpl_2", "Japa Meditation in Temple Hall", ScheduleCategory.JAPA.name, "05:15", "07:00", true, notes = "16 attentive rounds", sortOrder = 2),
                ScheduleItem("tpl_3", "Darshan Aarti & Guru Puja", ScheduleCategory.AARTI.name, "07:00", "07:45", true, notes = "Morning greeting of the Deities", sortOrder = 3),
                ScheduleItem("tpl_4", "Srimad-Bhagavatam Class", ScheduleCategory.HEARING.name, "07:45", "08:45", true, notes = "Daily ashram class", sortOrder = 4),
                ScheduleItem("tpl_5", "Temple Department Seva", ScheduleCategory.SEVA.name, "09:30", "13:00", false, notes = "Dedicated practical devotional service", sortOrder = 5),
                ScheduleItem("tpl_6", "Afternoon Study & Seva", ScheduleCategory.READING.name, "15:00", "18:00", false, notes = "Shastra study and outreach", sortOrder = 6),
                ScheduleItem("tpl_7", "Sandhya Gaura Aarti & Gita Class", ScheduleCategory.AARTI.name, "19:00", "20:15", true, notes = "Evening kirtan and class", sortOrder = 7),
                ScheduleItem("tpl_8", "Ashram Rest", ScheduleCategory.REST.name, "21:00", "03:45", true, notes = "Overnight rest for Brahma Muhurta", sortOrder = 8)
            )
            DevoteePersona.STUDENT -> listOf(
                ScheduleItem("tpl_1", "Protected Morning Japa", ScheduleCategory.JAPA.name, "05:15", "06:15", true, notes = "Chant before opening study apps", sortOrder = 1),
                ScheduleItem("tpl_2", "Short Gita Reading", ScheduleCategory.READING.name, "06:20", "06:40", true, notes = "20 minutes of inspiring study", sortOrder = 2),
                ScheduleItem("tpl_3", "Classes & Deep Focus Study", ScheduleCategory.STUDY.name, "08:30", "13:00", false, notes = "Activate Focus Shield during lectures", sortOrder = 3),
                ScheduleItem("tpl_4", "Walk / Exercise & Refresh", ScheduleCategory.HEALTH.name, "17:00", "17:45", false, notes = "Keep body and mind alert", sortOrder = 4),
                ScheduleItem("tpl_5", "Evening Hearing & Assignment Review", ScheduleCategory.HEARING.name, "19:30", "20:30", false, notes = "20 min lecture + focused wrap-up", sortOrder = 5),
                ScheduleItem("tpl_6", "Night Sleep", ScheduleCategory.REST.name, "22:30", "05:00", true, notes = "Consistent sleep for memory & devotion", sortOrder = 6)
            )
            DevoteePersona.CONGREGATIONAL -> listOf(
                ScheduleItem("tpl_1", "Early Morning Japa", ScheduleCategory.JAPA.name, "05:00", "06:45", true, notes = "Complete key rounds before household rush", sortOrder = 1),
                ScheduleItem("tpl_2", "Morning Altar Offering & Reading", ScheduleCategory.READING.name, "06:45", "07:15", true, notes = "Offer prasadam & read 20-30 min", sortOrder = 2),
                ScheduleItem("tpl_3", "Work & Career Service", ScheduleCategory.WORK.name, "09:00", "17:30", false, notes = "Mindful, honest livelihood", sortOrder = 3),
                ScheduleItem("tpl_4", "Family Prasadam & Evening Kirtan", ScheduleCategory.FAMILY.name, "19:00", "20:00", true, notes = "Short kirtan and family check-in", sortOrder = 4),
                ScheduleItem("tpl_5", "Evening Hearing & Wind-Down", ScheduleCategory.HEARING.name, "20:30", "21:15", false, notes = "Listen to Bhagavatam before rest", sortOrder = 5),
                ScheduleItem("tpl_6", "Restful Sleep", ScheduleCategory.REST.name, "22:00", "04:45", true, notes = "Overnight rest block", sortOrder = 6)
            )
            DevoteePersona.ELDER -> listOf(
                ScheduleItem("tpl_1", "Peaceful Morning Japa", ScheduleCategory.JAPA.name, "05:15", "07:00", true, notes = "Seated comfortably at a calm pace", sortOrder = 1),
                ScheduleItem("tpl_2", "Gentle Morning Walk & Sunlight", ScheduleCategory.HEALTH.name, "07:15", "07:45", false, notes = "Light walk according to comfort", sortOrder = 2),
                ScheduleItem("tpl_3", "Scripture Reading & Audio Class", ScheduleCategory.READING.name, "09:00", "09:45", true, notes = "Large-print reading or audio hearing", sortOrder = 3),
                ScheduleItem("tpl_4", "Afternoon Rest & Hydration", ScheduleCategory.REST.name, "13:30", "14:45", true, notes = "Restorative midday pause", sortOrder = 4),
                ScheduleItem("tpl_5", "Evening Sandhya Kirtan & Hearing", ScheduleCategory.HEARING.name, "18:30", "19:30", true, notes = "Soothing evening bhajan & class", sortOrder = 5),
                ScheduleItem("tpl_6", "Night Rest", ScheduleCategory.REST.name, "21:30", "05:00", true, notes = "Peaceful overnight sleep", sortOrder = 6)
            )
        }
    }

    fun scheduleForRoutineMode(mode: RoutineMode, persona: DevoteePersona): List<ScheduleItem> {
        return when (mode) {
            RoutineMode.TEMPLE_RESIDENT -> scheduleForPersona(DevoteePersona.TEMPLE_RESIDENT)
            RoutineMode.STUDENT_PRO -> scheduleForPersona(DevoteePersona.STUDENT)
            RoutineMode.CONGREGATIONAL -> {
                if (persona == DevoteePersona.ELDER || persona == DevoteePersona.NEWCOMER || persona == DevoteePersona.SECOND_INITIATED) {
                    scheduleForPersona(persona)
                } else {
                    scheduleForPersona(DevoteePersona.CONGREGATIONAL)
                }
            }
        }
    }

    val referenceTemples: List<TempleCommunity> = listOf(
        TempleCommunity(
            id = "ref_mayapur",
            name = "Sri Mayapur Chandrodaya Mandir",
            city = "Mayapur",
            country = "India",
            tradition = CalendarTradition.ISKCON_MAYAPUR.name,
            adminUid = "reference_temple",
            mangalAartiTime = "04:30",
            darshanAartiTime = "07:00",
            bhagavatamClassTime = "07:45",
            sandhyaAartiTime = "18:30",
            description = "World headquarters of ISKCON on the sacred banks of the Ganga in Navadvipa Dhama.",
            liveStreamUrl = "https://www.mayapur.tv"
        ),
        TempleCommunity(
            id = "ref_vrindavan",
            name = "Sri Krishna Balaram Mandir",
            city = "Vrindavan",
            country = "India",
            tradition = CalendarTradition.VRINDAVAN.name,
            adminUid = "reference_temple",
            mangalAartiTime = "04:30",
            darshanAartiTime = "07:00",
            bhagavatamClassTime = "07:45",
            sandhyaAartiTime = "19:00",
            description = "24-hour kirtan sanctuary in Raman Reti, Vrindavan Dhama.",
            liveStreamUrl = "https://www.mayapur.tv"
        ),
        TempleCommunity(
            id = "ref_mumbai",
            name = "Sri Sri Radha Rasabihari Temple",
            city = "Mumbai (Juhu)",
            country = "India",
            tradition = CalendarTradition.ISKCON_MAYAPUR.name,
            adminUid = "reference_temple",
            mangalAartiTime = "04:30",
            darshanAartiTime = "07:15",
            bhagavatamClassTime = "08:00",
            sandhyaAartiTime = "19:00",
            description = "Vibrant devotional sanctuary in Juhu, Mumbai with daily Bhagavatam classes and evening kirtan.",
            liveStreamUrl = "https://www.iskconmumbai.com"
        ),
        TempleCommunity(
            id = "ref_london",
            name = "Bhaktivedanta Manor",
            city = "Watford / London",
            country = "United Kingdom",
            tradition = CalendarTradition.ISKCON_MAYAPUR.name,
            adminUid = "reference_temple",
            mangalAartiTime = "04:30",
            darshanAartiTime = "07:00",
            bhagavatamClassTime = "07:45",
            sandhyaAartiTime = "19:00",
            description = "Historic UK sanctuary with goshala, gardens, and daily Sri Sri Radha Gokulananda darshan.",
            liveStreamUrl = "https://www.bhaktivedantamanor.co.uk"
        ),
        TempleCommunity(
            id = "ref_newyork",
            name = "Sri Sri Radha Govinda Mandir",
            city = "New York (Brooklyn)",
            country = "United States",
            tradition = CalendarTradition.ISKCON_MAYAPUR.name,
            adminUid = "reference_temple",
            mangalAartiTime = "04:30",
            darshanAartiTime = "07:00",
            bhagavatamClassTime = "07:45",
            sandhyaAartiTime = "19:00",
            description = "Daily morning program, evening kirtan, and Sunday Love Feast in Brooklyn, NY.",
            liveStreamUrl = "https://www.radhagovinda.net"
        )
    )

    val referencePosts: List<TemplePost> = listOf(
        TemplePost(
            id = "ref_post_1",
            templeId = "ref_mayapur",
            authorUid = "reference_temple",
            authorName = "Mayapur Temple Office",
            postType = TemplePostType.ANNOUNCEMENT.name,
            title = "Daily Live Mangal Aarti & Tulasi Parikrama",
            body = "Join devotees worldwide each morning at 04:30 local temple time for Mangal Aarti, Nrsimha Prayers, and Tulasi Puja.",
            eventDateKey = "",
            eventTime = "04:30"
        ),
        TemplePost(
            id = "ref_post_2",
            templeId = "ref_mayapur",
            authorUid = "reference_temple",
            authorName = "Mayapur Festival Desk",
            postType = TemplePostType.SEVA.name,
            title = "Sunday Feast Flower Garland Seva",
            body = "Devotees of all experience levels are warmly invited to help string fresh marigold garlands on Saturday afternoon.",
            eventDateKey = "",
            eventTime = "15:00",
            volunteerUids = listOf("devotee_radha_1", "devotee_govinda_2")
        ),
        TemplePost(
            id = "ref_post_3",
            templeId = "ref_vrindavan",
            authorUid = "reference_temple",
            authorName = "Vrindavan Kirtan Team",
            postType = TemplePostType.LECTURE.name,
            title = "Srimad-Bhagavatam Morning Study",
            body = "Daily systematic verse-by-verse discussion in the temple courtyard following Guru Puja.",
            eventDateKey = "",
            eventTime = "07:45"
        )
    )
}
