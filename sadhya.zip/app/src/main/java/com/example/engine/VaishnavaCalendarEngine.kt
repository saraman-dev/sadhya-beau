package com.example.engine

import com.example.model.CalendarTradition
import com.example.model.TimeMath
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin
import kotlin.math.tan

data class CityPreset(
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val timezoneId: String
)

enum class EkadashiFastType(val label: String) {
    NONE(""),
    SHUDDHA("Shuddha Ekadashi"),
    MAHADVAADASHI("Mahadvadashi (Dashami-viddha shifted)")
}

data class VaishnavaDayInfo(
    val dateKey: String,
    val year: Int,
    val month: Int, // 1..12
    val dayOfMonth: Int,
    val sunriseHHmm: String,
    val sunsetHHmm: String,
    val sunriseMinutes: Int,
    val sunsetMinutes: Int,
    val tithiNumber: Int, // 1..30 (1..15 Shukla, 16..30 Krishna)
    val tithiName: String,
    val paksha: String, // "Shukla" or "Krishna"
    val masaName: String,
    val isEkadashiFast: Boolean,
    val ekadashiType: EkadashiFastType,
    val ekadashiName: String,
    val paranaWindow: String, // e.g., "06:14 – 09:52 (local)" on the Dvadashi day
    val chaturmasyaPhase: String,
    val festivals: List<String>
)

object VaishnavaCalendarEngine {

    val cityPresets: List<CityPreset> = listOf(
        CityPreset("Mayapur, India", 23.4231, 88.3880, "Asia/Kolkata"),
        CityPreset("Vrindavan, India", 27.5806, 77.7006, "Asia/Kolkata"),
        CityPreset("Mumbai, India", 19.0760, 72.8777, "Asia/Kolkata"),
        CityPreset("Bengaluru, India", 12.9716, 77.5946, "Asia/Kolkata"),
        CityPreset("London, UK", 51.5072, -0.1276, "Europe/London"),
        CityPreset("New York, USA", 40.7128, -74.0060, "America/New_York"),
        CityPreset("Los Angeles, USA", 34.0522, -118.2437, "America/Los_Angeles"),
        CityPreset("Sydney, Australia", -33.8688, 151.2093, "Australia/Sydney"),
        CityPreset("Toronto, Canada", 43.6532, -79.3832, "America/Toronto"),
        CityPreset("Tokyo, Japan", 35.6762, 139.6503, "Asia/Tokyo")
    )

    private val tithiNames = listOf(
        "Pratipat", "Dvitiya", "Tritiya", "Chaturthi", "Panchami",
        "Shashthi", "Saptami", "Ashtami", "Navami", "Dashami",
        "Ekadashi", "Dvadashi", "Trayodashi", "Chaturdashi", "Purnima",
        "Pratipat", "Dvitiya", "Tritiya", "Chaturthi", "Panchami",
        "Shashthi", "Saptami", "Ashtami", "Navami", "Dashami",
        "Ekadashi", "Dvadashi", "Trayodashi", "Chaturdashi", "Amavasya"
    )

    private val vaishnavaMasas = listOf(
        "Vishnu", "Madhusudana", "Trivikrama", "Vamana", "Sridhara", "Hrishikesha",
        "Padmanabha", "Damodara", "Kesava", "Narayana", "Madhava", "Govinda"
    )

    private val ekadashiNamesByMasa = mapOf(
        "Vishnu" to Pair("Kamada Ekadashi", "Varuthini Ekadashi"),
        "Madhusudana" to Pair("Mohini Ekadashi", "Apara Ekadashi"),
        "Trivikrama" to Pair("Pandava Nirjala Ekadashi", "Yogini Ekadashi"),
        "Vamana" to Pair("Sayana Ekadashi", "Kamika Ekadashi"),
        "Sridhara" to Pair("Pavitropana Ekadashi", "Annada Ekadashi"),
        "Hrishikesha" to Pair("Parsva Ekadashi", "Indira Ekadashi"),
        "Padmanabha" to Pair("Pasankusa Ekadashi", "Rama Ekadashi"),
        "Damodara" to Pair("Utthana Ekadashi", "Utpanna Ekadashi"),
        "Kesava" to Pair("Moksada Ekadashi", "Saphala Ekadashi"),
        "Narayana" to Pair("Putrada Ekadashi", "Sat-tila Ekadashi"),
        "Madhava" to Pair("Bhaimi (Jaya) Ekadashi", "Vijaya Ekadashi"),
        "Govinda" to Pair("Amalaki Vrata Ekadashi", "Papamocani Ekadashi")
    )

    fun dateKeyFor(year: Int, month: Int, day: Int): String =
        String.format(Locale.US, "%04d-%02d-%02d", year, month, day)

    fun todayDateKey(timezoneId: String = TimeZone.getDefault().id): String {
        val tz = TimeZone.getTimeZone(timezoneId)
        val cal = Calendar.getInstance(tz)
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = tz }
        return sdf.format(cal.time)
    }

    fun calculateDay(
        year: Int,
        month: Int,
        day: Int,
        latitude: Double,
        longitude: Double,
        timezoneId: String,
        tradition: CalendarTradition = CalendarTradition.ISKCON_MAYAPUR
    ): VaishnavaDayInfo {
        val tz = TimeZone.getTimeZone(timezoneId)
        val (sunriseMin, sunsetMin, sunriseUtcJd) = computeSunriseSunset(year, month, day, latitude, longitude, tz)

        val tithiAtSunrise = tithiIndexAtJd(sunriseUtcJd) // 1..30
        val arunodayaJd = sunriseUtcJd - (96.0 / 1440.0) // 1h 36m before sunrise (Arunodaya)
        val tithiAtArunodaya = tithiIndexAtJd(arunodayaJd)

        val prevCal = Calendar.getInstance(tz).apply {
            set(year, month - 1, day, 12, 0, 0)
            add(Calendar.DAY_OF_YEAR, -1)
        }
        val (_, _, prevSunriseJd) = computeSunriseSunset(
            prevCal.get(Calendar.YEAR),
            prevCal.get(Calendar.MONTH) + 1,
            prevCal.get(Calendar.DAY_OF_MONTH),
            latitude,
            longitude,
            tz
        )
        val prevTithiAtSunrise = tithiIndexAtJd(prevSunriseJd)
        val prevTithiAtArunodaya = tithiIndexAtJd(prevSunriseJd - (96.0 / 1440.0))

        val paksha = if (tithiAtSunrise <= 15) "Shukla" else "Krishna"
        val tithiName = tithiNames[(tithiAtSunrise - 1).coerceIn(0, 29)]
        val masaName = computeVaishnavaMasa(sunriseUtcJd)

        // Check Ekadashi (Shukla 11 or Krishna 26)
        val isShuklaEkadashiToday = tithiAtSunrise == 11
        val isKrishnaEkadashiToday = tithiAtSunrise == 26
        val isDashamiAtArunodaya = (isShuklaEkadashiToday && tithiAtArunodaya == 10) ||
            (isKrishnaEkadashiToday && tithiAtArunodaya == 25)

        val prevWasDashamiViddha = ((prevTithiAtSunrise == 11 && prevTithiAtArunodaya == 10) ||
            (prevTithiAtSunrise == 26 && prevTithiAtArunodaya == 25))
        val isDvadashiToday = tithiAtSunrise == 12 || tithiAtSunrise == 27

        val (isEkadashiFast, ekadashiType) = when {
            (isShuklaEkadashiToday || isKrishnaEkadashiToday) && !isDashamiAtArunodaya ->
                true to EkadashiFastType.SHUDDHA
            isDvadashiToday && prevWasDashamiViddha ->
                true to EkadashiFastType.MAHADVAADASHI
            // Also handle rare Ekadashi-ksaya where Ekadashi begins after yesterday's sunrise and ends before today's sunrise
            isDvadashiToday && (prevTithiAtSunrise == 10 || prevTithiAtSunrise == 25) ->
                true to EkadashiFastType.MAHADVAADASHI
            else -> false to EkadashiFastType.NONE
        }

        val ekadashiPair = ekadashiNamesByMasa[masaName] ?: Pair("Shukla Ekadashi", "Krishna Ekadashi")
        val ekadashiName = if (isEkadashiFast) {
            if (paksha == "Shukla") ekadashiPair.first else ekadashiPair.second
        } else ""

        // Parana window on the day AFTER an Ekadashi fast
        val prevWasShuddhaFast = (prevTithiAtSunrise == 11 && prevTithiAtArunodaya != 10) ||
            (prevTithiAtSunrise == 26 && prevTithiAtArunodaya != 25)
        val prevWasMahadvadashi = (prevTithiAtSunrise == 12 || prevTithiAtSunrise == 27) &&
            isPrevDayFast(prevCal, latitude, longitude, tz)

        val paranaWindow = if (!isEkadashiFast && (prevWasShuddhaFast || prevWasMahadvadashi)) {
            computeParanaWindow(sunriseUtcJd, sunriseMin, sunsetMin, tithiAtSunrise)
        } else ""

        val chaturmasyaPhase = computeChaturmasyaPhase(masaName, paksha, tithiAtSunrise)
        val festivals = detectFestivals(masaName, paksha, tithiAtSunrise, isEkadashiFast, ekadashiName, tradition)

        return VaishnavaDayInfo(
            dateKey = dateKeyFor(year, month, day),
            year = year,
            month = month,
            dayOfMonth = day,
            sunriseHHmm = TimeMath.formatMinutesToHHmm(sunriseMin),
            sunsetHHmm = TimeMath.formatMinutesToHHmm(sunsetMin),
            sunriseMinutes = sunriseMin,
            sunsetMinutes = sunsetMin,
            tithiNumber = tithiAtSunrise,
            tithiName = tithiName,
            paksha = paksha,
            masaName = masaName,
            isEkadashiFast = isEkadashiFast,
            ekadashiType = ekadashiType,
            ekadashiName = ekadashiName,
            paranaWindow = paranaWindow,
            chaturmasyaPhase = chaturmasyaPhase,
            festivals = festivals
        )
    }

    fun calculateMonth(
        year: Int,
        month: Int,
        latitude: Double,
        longitude: Double,
        timezoneId: String,
        tradition: CalendarTradition = CalendarTradition.ISKCON_MAYAPUR
    ): List<VaishnavaDayInfo> {
        val cal = Calendar.getInstance().apply {
            set(year, month - 1, 1)
        }
        val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        return (1..daysInMonth).map { day ->
            calculateDay(year, month, day, latitude, longitude, timezoneId, tradition)
        }
    }

    private fun isPrevDayFast(
        prevCal: Calendar,
        latitude: Double,
        longitude: Double,
        tz: TimeZone
    ): Boolean {
        val prev2 = (prevCal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -1) }
        val (_, _, prev2SunriseJd) = computeSunriseSunset(
            prev2.get(Calendar.YEAR),
            prev2.get(Calendar.MONTH) + 1,
            prev2.get(Calendar.DAY_OF_MONTH),
            latitude,
            longitude,
            tz
        )
        val t2 = tithiIndexAtJd(prev2SunriseJd)
        val a2 = tithiIndexAtJd(prev2SunriseJd - (96.0 / 1440.0))
        return (t2 == 11 && a2 == 10) || (t2 == 26 && a2 == 25) || t2 == 10 || t2 == 25
    }

    /**
     * Computes Parana break-fast window respecting both Hari-vasara (first 1/4 of Dvadashi)
     * and 1/3rd of local daytime (sunrise to sunset), plus Dvadashi end time.
     */
    private fun computeParanaWindow(
        sunriseJd: Double,
        sunriseMin: Int,
        sunsetMin: Int,
        tithiAtSunrise: Int
    ): String {
        val dayLengthMin = (sunsetMin - sunriseMin).coerceAtLeast(360)
        val oneThirdDayEnd = sunriseMin + (dayLengthMin / 3)

        // Estimate remaining fraction of current Dvadashi tithi
        val angleAtSunrise = lunarSolarPhaseDeg(sunriseJd)
        val tithiEndDeg = tithiAtSunrise * 12.0
        val remainingDeg = normalize360(tithiEndDeg - angleAtSunrise)
        val degPerDay = 12.190749
        val hoursLeftInTithi = (remainingDeg / degPerDay) * 24.0

        // Hari-vasara is first 3 degrees of Dvadashi (first quarter of Dvadashi tithi)
        val tithiStartDeg = (tithiAtSunrise - 1) * 12.0
        val elapsedDegInDvadashi = normalize360(angleAtSunrise - tithiStartDeg)
        val hariVasaraDelayMin = if ((tithiAtSunrise == 12 || tithiAtSunrise == 27) && elapsedDegInDvadashi < 3.0) {
            val remainingHvDeg = 3.0 - elapsedDegInDvadashi
            ((remainingHvDeg / degPerDay) * 1440.0).toInt().coerceIn(0, 240)
        } else 0

        val startMin = sunriseMin + hariVasaraDelayMin
        val tithiEndMin = sunriseMin + (hoursLeftInTithi * 60.0).toInt().coerceIn(20, 720)
        val endMin = minOf(oneThirdDayEnd, tithiEndMin).coerceAtLeast(startMin + 15)

        return "${TimeMath.formatMinutesToHHmm(startMin)} – ${TimeMath.formatMinutesToHHmm(endMin)} (local)"
    }

    private fun computeChaturmasyaPhase(masa: String, paksha: String, tithi: Int): String {
        return when (masa) {
            "Vamana" -> if (paksha == "Shukla" && tithi >= 11) "Chaturmasya Month 1 (Shaka / Leafy Greens)" else ""
            "Sridhara" -> "Chaturmasya Month 1–2 (Shaka / Yogurt)"
            "Hrishikesha" -> "Chaturmasya Month 2–3 (Yogurt / Milk)"
            "Padmanabha" -> "Chaturmasya Month 3–4 (Milk / Urad Dal)"
            "Damodara" -> if (paksha == "Shukla" && tithi <= 15) "Kartika / Damodara Month (Chaturmasya Month 4)" else ""
            else -> ""
        }
    }

    private fun detectFestivals(
        masa: String,
        paksha: String,
        tithi: Int,
        isEkadashiFast: Boolean,
        ekadashiName: String,
        tradition: CalendarTradition
    ): List<String> {
        val list = mutableListOf<String>()
        if (isEkadashiFast && ekadashiName.isNotBlank()) {
            list.add(ekadashiName)
        }
        val dayInPaksha = if (tithi <= 15) tithi else tithi - 15
        when (masa) {
            "Govinda" -> {
                if (paksha == "Shukla" && dayInPaksha == 15) list.add("Gaura Purnima — Appearance of Sri Chaitanya Mahaprabhu")
            }
            "Vishnu" -> {
                if (paksha == "Shukla" && dayInPaksha == 9) list.add("Rama Navami — Appearance of Lord Sri Ramachandra")
            }
            "Madhusudana" -> {
                if (paksha == "Shukla" && dayInPaksha == 3) list.add("Akshaya Tritiya & Chandana Yatra Begins")
                if (paksha == "Shukla" && dayInPaksha == 14) list.add("Nrsimha Chaturdashi — Appearance of Lord Nrsimhadeva")
            }
            "Trivikrama" -> {
                if (paksha == "Shukla" && dayInPaksha == 15) list.add("Snana Yatra of Lord Jagannatha")
                if (paksha == "Krishna" && dayInPaksha == 1) list.add("Ratha Yatra Preparation")
            }
            "Vamana" -> {
                if (paksha == "Shukla" && dayInPaksha == 2) list.add("Sri Jagannatha Ratha Yatra")
                if (paksha == "Shukla" && dayInPaksha == 15) list.add("Guru Purnima (Vyasa Puja)")
            }
            "Sridhara" -> {
                if (paksha == "Shukla" && dayInPaksha == 15) list.add("Balarama Purnima — Appearance of Lord Balarama")
            }
            "Hrishikesha" -> {
                if (paksha == "Krishna" && dayInPaksha == 8) list.add("Sri Krishna Janmashtami")
                if (paksha == "Krishna" && dayInPaksha == 9) {
                    list.add(
                        if (tradition == CalendarTradition.ISKCON_MAYAPUR)
                            "Nandotsava & Srila Prabhupada Vyasa Puja"
                        else
                            "Nandotsava Festival"
                    )
                }
                if (paksha == "Shukla" && dayInPaksha == 8) list.add("Sri Radhashtami — Appearance of Srimati Radharani")
                if (paksha == "Shukla" && dayInPaksha == 12) list.add("Vamana Dvadashi — Appearance of Lord Vamanadeva")
            }
            "Damodara" -> {
                if (paksha == "Shukla" && dayInPaksha == 1) list.add("Govardhana Puja & Annakuta Festival")
                if (paksha == "Shukla" && dayInPaksha == 8) list.add("Gopashtami")
                if (paksha == "Shukla" && dayInPaksha == 15) list.add("Kartika Purnima & Tulasi-Shaligrama Vivaha")
                if (paksha == "Krishna" && dayInPaksha == 15) list.add("Deepavali — Festival of Lamps")
            }
            "Kesava" -> {
                if (paksha == "Shukla" && dayInPaksha == 11) list.add("Gita Jayanti — Advent of Srimad Bhagavad-gita")
            }
            "Madhava" -> {
                if (paksha == "Shukla" && dayInPaksha == 5) list.add("Vasanta Panchami")
                if (paksha == "Shukla" && dayInPaksha == 13) list.add("Nityananda Trayodashi — Appearance of Lord Nityananda")
            }
        }
        return list.distinct()
    }

    // --- Astronomical Core (Jean Meeus Algorithms) ---

    internal fun julianDayUtc(year: Int, month: Int, day: Double): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        val b = 2.0 - a + floor(a / 4.0)
        return floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.5
    }

    internal fun solarLongitudeDeg(jd: Double): Double {
        val t = (jd - 2451545.0) / 36525.0
        val l0 = normalize360(280.46646 + 36000.76983 * t + 0.0003032 * t * t)
        val m = normalize360(357.52911 + 35999.05029 * t - 0.0001537 * t * t)
        val mRad = Math.toRadians(m)
        val c = (1.914602 - 0.004817 * t - 0.000014 * t * t) * sin(mRad) +
            (0.019993 - 0.000101 * t) * sin(2 * mRad) +
            0.000289 * sin(3 * mRad)
        return normalize360(l0 + c)
    }

    internal fun lunarLongitudeDeg(jd: Double): Double {
        val t = (jd - 2451545.0) / 36525.0
        val lPrime = normalize360(218.3164477 + 481267.88123421 * t - 0.0015786 * t * t)
        val d = Math.toRadians(normalize360(297.8501921 + 445267.1114034 * t))
        val m = Math.toRadians(normalize360(357.5291092 + 35999.0502909 * t))
        val mPrime = Math.toRadians(normalize360(134.9633964 + 477198.8675055 * t))
        val f = Math.toRadians(normalize360(93.2720950 + 483202.0175233 * t))

        val deltaL =
            6.288774 * sin(mPrime) +
                1.274027 * sin(2 * d - mPrime) +
                0.658314 * sin(2 * d) +
                0.213618 * sin(2 * mPrime) -
                0.185116 * sin(m) -
                0.114332 * sin(2 * f) +
                0.058793 * sin(2 * d - 2 * mPrime) +
                0.057066 * sin(2 * d - m - mPrime) +
                0.053322 * sin(2 * d + mPrime) +
                0.045758 * sin(2 * d - m) -
                0.040923 * sin(m - mPrime) -
                0.034720 * sin(d) -
                0.030383 * sin(m + mPrime)

        return normalize360(lPrime + deltaL)
    }

    private fun lunarSolarPhaseDeg(jd: Double): Double {
        return normalize360(lunarLongitudeDeg(jd) - solarLongitudeDeg(jd))
    }

    internal fun tithiIndexAtJd(jd: Double): Int {
        val phase = lunarSolarPhaseDeg(jd)
        return (floor(phase / 12.0).toInt() % 30) + 1
    }

    private fun computeVaishnavaMasa(jd: Double): String {
        // Approximate Lahiri ayanamsha (~24.2 deg in 2026) for sidereal solar zodiac (Nirayana)
        val siderealSun = normalize360(solarLongitudeDeg(jd) - 24.2)
        // Find approximate longitude at previous Amavasya/Purnima boundary
        val phase = lunarSolarPhaseDeg(jd)
        val daysSinceNewMoon = phase / 12.190749
        val sunAtNewMoon = normalize360(siderealSun - daysSinceNewMoon * 0.9856)
        val rasiIndex = (floor(sunAtNewMoon / 30.0).toInt() % 12 + 12) % 12
        return vaishnavaMasas[rasiIndex]
    }

    private fun computeSunriseSunset(
        year: Int,
        month: Int,
        day: Int,
        latitude: Double,
        longitude: Double,
        tz: TimeZone
    ): Triple<Int, Int, Double> {
        val cal = Calendar.getInstance(tz).apply {
            set(year, month - 1, day, 12, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val tzOffsetHours = tz.getOffset(cal.timeInMillis) / 3_600_000.0
        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)

        // Fractional year gamma (NOAA / Meeus solar equations)
        val gamma = 2.0 * PI / 365.0 * (dayOfYear - 1)
        val eqTime = 229.18 * (
            0.000075 +
                0.001868 * cos(gamma) -
                0.032077 * sin(gamma) -
                0.014615 * cos(2 * gamma) -
                0.040849 * sin(2 * gamma)
            )
        val decl = 0.006918 -
            0.399912 * cos(gamma) +
            0.070257 * sin(gamma) -
            0.006758 * cos(2 * gamma) +
            0.000907 * sin(2 * gamma) -
            0.002697 * cos(3 * gamma) +
            0.00148 * sin(3 * gamma)

        val latRad = Math.toRadians(latitude.coerceIn(-65.0, 65.0))
        val zenithRad = Math.toRadians(90.833)
        val cosHa = ((cos(zenithRad) / (cos(latRad) * cos(decl))) - tan(latRad) * tan(decl))
            .coerceIn(-0.999, 0.999)
        val haDeg = Math.toDegrees(acos(cosHa))

        val solarNoonMin = 720.0 - (4.0 * longitude) - eqTime + (tzOffsetHours * 60.0)
        val sunriseMin = (solarNoonMin - haDeg * 4.0).toInt().coerceIn(0, 1439)
        val sunsetMin = (solarNoonMin + haDeg * 4.0).toInt().coerceIn(0, 1439)

        val sunriseUtcHours = (sunriseMin / 60.0) - tzOffsetHours
        val sunriseUtcJd = julianDayUtc(year, month, day.toDouble() + sunriseUtcHours / 24.0)
        return Triple(sunriseMin, sunsetMin, sunriseUtcJd)
    }

    private fun normalize360(angle: Double): Double {
        val m = angle % 360.0
        return if (m < 0.0) m + 360.0 else m
    }
}
