package com.example.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import com.example.model.TimeMath
import java.util.Calendar

object AlarmScheduler {

    const val EXTRA_ALARM_TYPE = "extra_alarm_type"
    const val EXTRA_TITLE = "extra_title"
    const val EXTRA_MESSAGE = "extra_message"
    const val EXTRA_REQUEST_CODE = "extra_request_code"

    const val TYPE_WAKE_UP = "WAKE_UP"
    const val TYPE_BEDTIME_30 = "BEDTIME_30"
    const val TYPE_BEDTIME_15 = "BEDTIME_15"
    const val TYPE_BEDTIME_NOW = "BEDTIME_NOW"
    const val TYPE_GAYATRI_MORNING = "GAYATRI_MORNING"
    const val TYPE_GAYATRI_AFTERNOON = "GAYATRI_AFTERNOON"
    const val TYPE_GAYATRI_EVENING = "GAYATRI_EVENING"
    const val TYPE_TASK_REMINDER = "TASK_REMINDER"

    private const val RC_WAKE_UP = 1001
    private const val RC_SNOOZE = 1002
    private const val RC_BEDTIME_30 = 1010
    private const val RC_BEDTIME_15 = 1011
    private const val RC_BEDTIME_NOW = 1012
    private const val RC_GAYATRI_M = 1020
    private const val RC_GAYATRI_A = 1021
    private const val RC_GAYATRI_E = 1022

    fun canScheduleExactAlarms(context: Context): Boolean {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            am.canScheduleExactAlarms()
        } else true
    }

    fun exactAlarmSettingsIntent(context: Context): Intent {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
        } else {
            Intent(Settings.ACTION_SETTINGS)
        }
    }

    fun scheduleDailyWakeAlarm(context: Context, hhmm: String, enabled: Boolean) {
        if (!enabled) {
            cancelAlarm(context, RC_WAKE_UP)
            return
        }
        val triggerMs = nextTriggerMillisForHHmm(hhmm)
        scheduleExactOrFallback(
            context = context,
            requestCode = RC_WAKE_UP,
            triggerAtMillis = triggerMs,
            type = TYPE_WAKE_UP,
            title = "Brahma Muhurta Wake-Up",
            message = "Hare Krishna! Rise peacefully for morning Japa and devotion."
        )
    }

    fun scheduleFiveMinuteSnooze(context: Context) {
        val triggerMs = System.currentTimeMillis() + 5 * 60_000L
        scheduleExactOrFallback(
            context = context,
            requestCode = RC_SNOOZE,
            triggerAtMillis = triggerMs,
            type = TYPE_WAKE_UP,
            title = "Gentle 5-Minute Reminder",
            message = "Time to rise softly for Brahma Muhurta."
        )
    }

    fun scheduleBedtimeWindDown(context: Context, sleepHHmm: String, enabled: Boolean) {
        if (!enabled) {
            cancelAlarm(context, RC_BEDTIME_30)
            cancelAlarm(context, RC_BEDTIME_15)
            cancelAlarm(context, RC_BEDTIME_NOW)
            return
        }
        val sleepMin = TimeMath.parseHHmmToMinutes(sleepHHmm)
        val t30 = TimeMath.formatMinutesToHHmm(sleepMin - 30)
        val t15 = TimeMath.formatMinutesToHHmm(sleepMin - 15)

        scheduleExactOrFallback(
            context, RC_BEDTIME_30, nextTriggerMillisForHHmm(t30), TYPE_BEDTIME_30,
            "Evening Wind-Down (-30m)",
            "Begin wrapping up screens and prepare peacefully for rest."
        )
        scheduleExactOrFallback(
            context, RC_BEDTIME_15, nextTriggerMillisForHHmm(t15), TYPE_BEDTIME_15,
            "15 Minutes Until Rest",
            "Consider a short calm reading or gratitude moment before sleep."
        )
        scheduleExactOrFallback(
            context, RC_BEDTIME_NOW, nextTriggerMillisForHHmm(sleepHHmm), TYPE_BEDTIME_NOW,
            "Restful Sleep Time",
            "Early rest nurtures tomorrow's Brahma Muhurta Sadhana."
        )
    }

    fun scheduleGayatriSandhyaAlarms(
        context: Context,
        enabled: Boolean,
        morningHHmm: String,
        afternoonHHmm: String,
        eveningHHmm: String
    ) {
        if (!enabled) {
            cancelAlarm(context, RC_GAYATRI_M)
            cancelAlarm(context, RC_GAYATRI_A)
            cancelAlarm(context, RC_GAYATRI_E)
            return
        }
        scheduleExactOrFallback(
            context, RC_GAYATRI_M, nextTriggerMillisForHHmm(morningHHmm), TYPE_GAYATRI_MORNING,
            "Morning Sandhya Reminder", "Discreet reminder for Morning Sandhya."
        )
        scheduleExactOrFallback(
            context, RC_GAYATRI_A, nextTriggerMillisForHHmm(afternoonHHmm), TYPE_GAYATRI_AFTERNOON,
            "Midday Sandhya Reminder", "Discreet reminder for Midday Sandhya."
        )
        scheduleExactOrFallback(
            context, RC_GAYATRI_E, nextTriggerMillisForHHmm(eveningHHmm), TYPE_GAYATRI_EVENING,
            "Evening Sandhya Reminder", "Discreet reminder for Evening Sandhya."
        )
    }

    fun scheduleOneShotTaskReminder(
        context: Context,
        taskId: String,
        title: String,
        reminderHHmm: String
    ) {
        if (!reminderHHmm.matches(Regex("^([01][0-9]|2[0-3]):[0-5][0-9]$"))) return
        val requestCode = 5000 + (taskId.hashCode() and 0x7FFF) % 4000
        val triggerMs = nextTriggerMillisForHHmm(reminderHHmm)
        scheduleExactOrFallback(
            context = context,
            requestCode = requestCode,
            triggerAtMillis = triggerMs,
            type = TYPE_TASK_REMINDER,
            title = "Sadhya Task Reminder",
            message = title.take(120)
        )
    }

    private fun scheduleExactOrFallback(
        context: Context,
        requestCode: Int,
        triggerAtMillis: Long,
        type: String,
        title: String,
        message: String
    ) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, SadhanaAlarmReceiver::class.java).apply {
            putExtra(EXTRA_ALARM_TYPE, type)
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_MESSAGE, message)
            putExtra(EXTRA_REQUEST_CODE, requestCode)
        }
        val pi = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (canScheduleExactAlarms(context)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
            }
        } catch (_: SecurityException) {
            am.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi)
        }
    }

    private fun cancelAlarm(context: Context, requestCode: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, SadhanaAlarmReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            am.cancel(pi)
            pi.cancel()
        }
    }

    private fun nextTriggerMillisForHHmm(hhmm: String): Long {
        val mins = TimeMath.parseHHmmToMinutes(hhmm)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, mins / 60)
            set(Calendar.MINUTE, mins % 60)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 5_000L) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }
        return cal.timeInMillis
    }
}
