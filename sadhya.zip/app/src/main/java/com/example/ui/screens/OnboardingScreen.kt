package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.engine.CityPreset
import com.example.engine.VaishnavaCalendarEngine
import com.example.model.CalendarTradition
import com.example.model.DevoteePersona
import com.example.model.FocusStrictness
import com.example.model.UserProfile
import com.example.ui.components.TimePickerField

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(
    existingProfile: UserProfile,
    currentPersona: DevoteePersona,
    currentElderMode: Boolean,
    onComplete: (
        persona: DevoteePersona,
        displayName: String,
        wakeTime: String,
        sleepTime: String,
        japaRounds: Int,
        readingMin: Int,
        hearingMin: Int,
        elderMode: Boolean,
        gayatriInitiated: Boolean,
        gayatriM: String,
        gayatriA: String,
        gayatriE: String,
        responsibilities: List<String>,
        distractingPackages: List<String>,
        focusStrictness: FocusStrictness,
        tradition: CalendarTradition,
        cityPreset: CityPreset
    ) -> Unit,
    onSkipDefaults: () -> Unit
) {
    val totalSteps = 10
    var step by remember { mutableIntStateOf(1) }

    var persona by remember { mutableStateOf(currentPersona) }
    var displayName by remember { mutableStateOf(existingProfile.displayName.ifBlank { "Devotee" }) }
    var wakeTime by remember { mutableStateOf(existingProfile.wakeTime) }
    var sleepTime by remember { mutableStateOf(existingProfile.sleepTime) }
    var japaRounds by remember { mutableFloatStateOf(existingProfile.japaTargetRounds.toFloat()) }
    var readingMin by remember { mutableFloatStateOf(existingProfile.readingTargetMinutes.toFloat()) }
    var hearingMin by remember { mutableFloatStateOf(existingProfile.hearingTargetMinutes.toFloat()) }
    var elderMode by remember { mutableStateOf(currentElderMode) }
    var gayatriInitiated by remember { mutableStateOf(existingProfile.gayatriInitiated) }
    var gayatriM by remember { mutableStateOf(existingProfile.gayatriMorningTime) }
    var gayatriA by remember { mutableStateOf(existingProfile.gayatriAfternoonTime) }
    var gayatriE by remember { mutableStateOf(existingProfile.gayatriEveningTime) }

    val availableResponsibilities = listOf(
        "Morning Sadhana", "Family Care", "Career / Office", "University Classes",
        "Temple Seva", "Deity Worship", "Prasadam Cooking", "Health & Walk", "Book Study"
    )
    var selectedResponsibilities by remember {
        mutableStateOf(existingProfile.responsibilities.ifEmpty { listOf("Morning Sadhana", "Family Care") })
    }

    val appChoices = listOf(
        "com.instagram.android" to "Instagram",
        "com.google.android.youtube" to "YouTube",
        "com.zhiliaoapp.musically" to "TikTok",
        "com.twitter.android" to "X / Twitter",
        "com.facebook.katana" to "Facebook",
        "com.reddit.frontpage" to "Reddit"
    )
    var selectedApps by remember {
        mutableStateOf(existingProfile.distractingPackages.ifEmpty { listOf("com.instagram.android", "com.google.android.youtube") })
    }

    var focusStrictness by remember { mutableStateOf(FocusStrictness.fromRaw(existingProfile.focusStrictness)) }
    var tradition by remember { mutableStateOf(CalendarTradition.fromRaw(existingProfile.calendarTradition)) }
    var selectedCity by remember {
        mutableStateOf(
            VaishnavaCalendarEngine.cityPresets.firstOrNull { it.name == existingProfile.locationName }
                ?: VaishnavaCalendarEngine.cityPresets.first()
        )
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxSize()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Step $step of $totalSteps",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    TextButton(
                        onClick = onSkipDefaults,
                        modifier = Modifier.testTag("onboarding_skip_button")
                    ) {
                        Text("Use Defaults")
                    }
                }
                LinearProgressIndicator(
                    progress = { step / totalSteps.toFloat() },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                )

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (step) {
                        1 -> {
                            Text("Which best describes your current journey?", style = MaterialTheme.typography.headlineMedium)
                            Text(
                                "Sadhya respects every stage equally — choose one to pre-fill a gentle, realistic rhythm.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            DevoteePersona.entries.forEach { p ->
                                val selected = persona == p
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("persona_card_${p.name}")
                                        .clickable {
                                            persona = p
                                            wakeTime = p.defaultWakeTime
                                            sleepTime = p.defaultSleepTime
                                            japaRounds = p.defaultRounds.toFloat()
                                            readingMin = p.defaultReadingMin.toFloat()
                                            hearingMin = p.defaultHearingMin.toFloat()
                                            gayatriInitiated = p.defaultGayatri
                                            elderMode = p.defaultElderMode
                                        },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer
                                        else MaterialTheme.colorScheme.surface
                                    ),
                                    border = BorderStroke(
                                        if (selected) 2.dp else 1.dp,
                                        if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                                    ),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text(p.displayTitle, style = MaterialTheme.typography.titleMedium)
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            p.subtitle,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }

                        2 -> {
                            Text("How should Sadhya greet you?", style = MaterialTheme.typography.headlineMedium)
                            OutlinedTextField(
                                value = displayName,
                                onValueChange = { displayName = it.take(80) },
                                label = { Text("Your Name or Spiritual Name") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("onboarding_name_input")
                            )
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Elder-Friendly Mode", style = MaterialTheme.typography.titleMedium)
                                        Text(
                                            "Larger 1.18x typography, calm high-contrast surfaces, and larger Japa tap targets.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Switch(
                                        checked = elderMode,
                                        onCheckedChange = { elderMode = it },
                                        modifier = Modifier.testTag("onboarding_elder_switch")
                                    )
                                }
                            }
                        }

                        3 -> {
                            Text("Wake-Up & Night Rest Times", style = MaterialTheme.typography.headlineMedium)
                            Text(
                                "Consistent sleep makes rising near Brahma Muhurta peaceful and sustainable.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            TimePickerField("Target Morning Wake Time", wakeTime, { wakeTime = it }, testTag = "onboarding_wake_picker")
                            TimePickerField("Target Night Sleep Time", sleepTime, { sleepTime = it }, testTag = "onboarding_sleep_picker")
                        }

                        4 -> {
                            Text("Daily Sadhana Goals", style = MaterialTheme.typography.headlineMedium)
                            Text("Daily Japa Target: ${japaRounds.toInt()} rounds", style = MaterialTheme.typography.titleMedium)
                            Slider(value = japaRounds, onValueChange = { japaRounds = it }, valueRange = 1f..32f, steps = 30)

                            Text("Daily Reading Goal: ${readingMin.toInt()} minutes", style = MaterialTheme.typography.titleMedium)
                            Slider(value = readingMin, onValueChange = { readingMin = it }, valueRange = 0f..120f, steps = 23)

                            Text("Daily Hearing Goal: ${hearingMin.toInt()} minutes", style = MaterialTheme.typography.titleMedium)
                            Slider(value = hearingMin, onValueChange = { hearingMin = it }, valueRange = 0f..120f, steps = 23)
                        }

                        5 -> {
                            Text("Discreet Sandhya Reminders", style = MaterialTheme.typography.headlineMedium)
                            Text(
                                "For second-initiated devotees, Sadhya offers quiet timing reminders only. Confidential mantra texts are never requested, stored, or displayed.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Enable Sandhya Reminders", style = MaterialTheme.typography.titleMedium)
                                    Switch(checked = gayatriInitiated, onCheckedChange = { gayatriInitiated = it })
                                }
                            }
                            if (gayatriInitiated) {
                                TimePickerField("Morning Sandhya", gayatriM, { gayatriM = it })
                                TimePickerField("Midday Sandhya", gayatriA, { gayatriA = it })
                                TimePickerField("Evening Sandhya", gayatriE, { gayatriE = it })
                            }
                        }

                        6 -> {
                            Text("Daily Responsibilities", style = MaterialTheme.typography.headlineMedium)
                            Text("Select what shapes your day so Sadhya respects your real-life commitments.", style = MaterialTheme.typography.bodyMedium)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                availableResponsibilities.forEach { item ->
                                    val selected = item in selectedResponsibilities
                                    FilterChip(
                                        selected = selected,
                                        onClick = {
                                            selectedResponsibilities = if (selected) selectedResponsibilities - item
                                            else (selectedResponsibilities + item).take(15)
                                        },
                                        label = { Text(item) }
                                    )
                                }
                            }
                        }

                        7 -> {
                            Text("Apps to Guard During Focus Shield", style = MaterialTheme.typography.headlineMedium)
                            Text("Choose apps where you would like a gentle Mindful Pause during active Sadhana.", style = MaterialTheme.typography.bodyMedium)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                appChoices.forEach { (pkg, label) ->
                                    val selected = pkg in selectedApps
                                    FilterChip(
                                        selected = selected,
                                        onClick = {
                                            selectedApps = if (selected) selectedApps - pkg else selectedApps + pkg
                                        },
                                        label = { Text(label) }
                                    )
                                }
                            }
                        }

                        8 -> {
                            Text("Focus Shield Strictness", style = MaterialTheme.typography.headlineMedium)
                            FocusStrictness.entries.forEach { st ->
                                val selected = focusStrictness == st
                                Card(
                                    modifier = Modifier.fillMaxWidth().clickable { focusStrictness = st },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                                    ),
                                    border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Text(st.label, style = MaterialTheme.typography.titleMedium)
                                        Text(
                                            when (st) {
                                                FocusStrictness.GENTLE -> "Immediate choice to return to Sadhana or continue."
                                                FocusStrictness.BALANCED -> "5-second calm breath plus a brief mindful reason."
                                                FocusStrictness.STRICT -> "10-second calm breath with emergency bypass disabled."
                                            },
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }

                        9 -> {
                            Text("Vaishnava Calendar & Location", style = MaterialTheme.typography.headlineMedium)
                            Text("Used on-device to calculate your local Sunrise, Ekadashi fasts, and Parana windows.", style = MaterialTheme.typography.bodyMedium)
                            Text("Tradition", style = MaterialTheme.typography.titleSmall)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                CalendarTradition.entries.forEach { tr ->
                                    FilterChip(selected = tradition == tr, onClick = { tradition = tr }, label = { Text(tr.label) })
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text("Nearest City Preset", style = MaterialTheme.typography.titleSmall)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                VaishnavaCalendarEngine.cityPresets.forEach { preset ->
                                    FilterChip(
                                        selected = selectedCity.name == preset.name,
                                        onClick = { selectedCity = preset },
                                        label = { Text(preset.name) }
                                    )
                                }
                            }
                        }

                        10 -> {
                            Text("Ready to Begin", style = MaterialTheme.typography.headlineMedium)
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Devotee: $displayName", style = MaterialTheme.typography.titleMedium)
                                    Text("Stage: ${persona.displayTitle}", style = MaterialTheme.typography.bodyMedium)
                                    Text("Wake / Sleep: $wakeTime / $sleepTime", style = MaterialTheme.typography.bodyMedium)
                                    Text("Daily Goals: ${japaRounds.toInt()} rounds • ${readingMin.toInt()}m reading • ${hearingMin.toInt()}m hearing", style = MaterialTheme.typography.bodyMedium)
                                    Text("Calendar: ${tradition.label} (${selectedCity.name})", style = MaterialTheme.typography.bodyMedium)
                                    if (elderMode) Text("Elder-Friendly Mode enabled (1.18x calm typography)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (step > 1) {
                        OutlinedButton(onClick = { step-- }) { Text("Back") }
                    } else {
                        Spacer(Modifier.height(1.dp))
                    }
                    if (step < totalSteps) {
                        Button(
                            onClick = { step++ },
                            modifier = Modifier.testTag("onboarding_next_button")
                        ) {
                            Text("Continue")
                        }
                    } else {
                        Button(
                            onClick = {
                                onComplete(
                                    persona, displayName, wakeTime, sleepTime,
                                    japaRounds.toInt(), readingMin.toInt(), hearingMin.toInt(),
                                    elderMode, gayatriInitiated, gayatriM, gayatriA, gayatriE,
                                    selectedResponsibilities, selectedApps, focusStrictness,
                                    tradition, selectedCity
                                )
                            },
                            modifier = Modifier.testTag("onboarding_finish_button")
                        ) {
                            Text("Start My Sadhana")
                        }
                    }
                }
            }
        }
    }
}
