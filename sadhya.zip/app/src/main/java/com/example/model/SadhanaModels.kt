package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class DevoteePersona(
    val displayTitle: String,
    val shortTitle: String,
    val subtitle: String,
    val defaultRounds: Int,
    val defaultReadingMin: Int,
    val defaultHearingMin: Int,
    val defaultWakeTime: String,
    val defaultSleepTime: String,
    val defaultRoutineMode: RoutineMode,
    val defaultGayatri: Boolean = false,
    val defaultElderMode: Boolean = false
) {
    NEWCOMER(
        displayTitle = "Newcomer / Seeker",
        shortTitle = "Seeker",
        subtitle = "Warm, jargon-free start — 4 rounds, 15m reading & gentle rhythm",
        defaultRounds = 4,
        defaultReadingMin = 15,
        defaultHearingMin = 15,
        defaultWakeTime = "06:00",
        defaultSleepTime = "22:30",
        defaultRoutineMode = RoutineMode.CONGREGATIONAL
    ),
    FIRST_INITIATED(
        displayTitle = "First-Initiated (Harinama)",
        shortTitle = "Harinama",
        subtitle = "16-round vow, Mangal Aarti & optional daily regulative check-in",
        defaultRounds = 16,
        defaultReadingMin = 30,
        defaultHearingMin = 30,
        defaultWakeTime = "04:15",
        defaultSleepTime = "21:30",
        defaultRoutineMode = RoutineMode.CONGREGATIONAL
    ),
    SECOND_INITIATED(
        displayTitle = "Second-Initiated (Brahmana)",
        shortTitle = "Brahmana",
        subtitle = "16 rounds + discreet Morning, Midday & Evening Sandhya reminders",
        defaultRounds = 16,
        defaultReadingMin = 45,
        defaultHearingMin = 30,
        defaultWakeTime = "04:00",
        defaultSleepTime = "21:30",
        defaultRoutineMode = RoutineMode.CONGREGATIONAL,
        defaultGayatri = true
    ),
    TEMPLE_RESIDENT(
        displayTitle = "Temple Resident / Brahmachari",
        shortTitle = "Temple",
        subtitle = "Full ashram morning-to-evening program, Mangal Aarti & Seva",
        defaultRounds = 16,
        defaultReadingMin = 60,
        defaultHearingMin = 60,
        defaultWakeTime = "03:45",
        defaultSleepTime = "21:00",
        defaultRoutineMode = RoutineMode.TEMPLE_RESIDENT,
        defaultGayatri = true
    ),
    STUDENT(
        displayTitle = "Student Devotee",
        shortTitle = "Student",
        subtitle = "Protected morning Sadhana alongside classes, study & Focus Shield",
        defaultRounds = 8,
        defaultReadingMin = 20,
        defaultHearingMin = 20,
        defaultWakeTime = "05:00",
        defaultSleepTime = "22:30",
        defaultRoutineMode = RoutineMode.STUDENT_PRO
    ),
    CONGREGATIONAL(
        displayTitle = "Congregational / Grihastha",
        shortTitle = "Grihastha",
        subtitle = "Balanced devotion with career, family care, prasadam & evening kirtan",
        defaultRounds = 16,
        defaultReadingMin = 25,
        defaultHearingMin = 30,
        defaultWakeTime = "04:45",
        defaultSleepTime = "22:00",
        defaultRoutineMode = RoutineMode.CONGREGATIONAL
    ),
    ELDER(
        displayTitle = "Elder / Senior Devotee",
        shortTitle = "Senior",
        subtitle = "Larger text, high-contrast calm surfaces, gentle walk & afternoon rest",
        defaultRounds = 16,
        defaultReadingMin = 30,
        defaultHearingMin = 45,
        defaultWakeTime = "05:00",
        defaultSleepTime = "21:30",
        defaultRoutineMode = RoutineMode.CONGREGATIONAL,
        defaultElderMode = true
    );

    companion object {
        fun fromRaw(raw: String?): DevoteePersona =
            entries.firstOrNull { it.name == raw } ?: CONGREGATIONAL
    }
}

enum class RoutineMode(val label: String) {
    TEMPLE_RESIDENT("Temple / Ashram"),
    CONGREGATIONAL("Congregational"),
    STUDENT_PRO("Student / Pro");

    companion object {
        fun fromRaw(raw: String?): RoutineMode =
            entries.firstOrNull { it.name == raw } ?: CONGREGATIONAL
    }
}

enum class FocusStrictness(val label: String, val waitSeconds: Int, val allowsBypass: Boolean) {
    GENTLE("Gentle (0s)", 0, true),
    BALANCED("Balanced (5s + reason)", 5, true),
    STRICT("Strict (10s, no bypass)", 10, false);

    companion object {
        fun fromRaw(raw: String?): FocusStrictness =
            entries.firstOrNull { it.name == raw } ?: BALANCED
    }
}

enum class CalendarTradition(val label: String) {
    ISKCON_MAYAPUR("ISKCON Mayapur"),
    GAUDIYA_MATH("Gaudiya Math"),
    VRINDAVAN("Vrindavan Parikrama");

    companion object {
        fun fromRaw(raw: String?): CalendarTradition =
            entries.firstOrNull { it.name == raw } ?: ISKCON_MAYAPUR
    }
}

enum class ThemeStyle(val label: String) {
    IVORY_MAROON("Ivory & Deep Maroon"),
    SAFFRON_SAND("Saffron & Sand"),
    VRINDAVAN_FOREST("Vrindavan Forest");

    companion object {
        fun fromRaw(raw: String?): ThemeStyle =
            entries.firstOrNull { it.name == raw } ?: IVORY_MAROON
    }
}

enum class DarkModePreference(val label: String) {
    SYSTEM("System"),
    LIGHT("Light"),
    DARK("Dark");

    companion object {
        fun fromRaw(raw: String?): DarkModePreference =
            entries.firstOrNull { it.name == raw } ?: SYSTEM
    }
}

enum class FontScaleLevel(val label: String) {
    COMPACT("Compact"),
    STANDARD("Standard"),
    LARGE("Large");

    companion object {
        fun fromRaw(raw: String?): FontScaleLevel =
            entries.firstOrNull { it.name == raw } ?: STANDARD
    }
}

enum class ScheduleCategory(val label: String) {
    JAPA("Japa"),
    AARTI("Aarti"),
    READING("Reading"),
    HEARING("Hearing"),
    GAYATRI("Sandhya"),
    PUJA("Puja"),
    SEVA("Seva"),
    STUDY("Study"),
    WORK("Work"),
    FAMILY("Family"),
    HEALTH("Health"),
    REST("Rest"),
    FESTIVAL("Festival"),
    OTHER("Other");

    companion object {
        fun fromRaw(raw: String?): ScheduleCategory =
            entries.firstOrNull { it.name == raw } ?: OTHER
    }
}

enum class TaskPriority(val label: String) {
    LOW("Low"),
    MEDIUM("Medium"),
    HIGH("High");

    companion object {
        fun fromRaw(raw: String?): TaskPriority =
            entries.firstOrNull { it.name == raw } ?: MEDIUM
    }
}

enum class WakeStatus(val label: String) {
    PENDING("Not Checked In"),
    ON_TIME("Woke On Time"),
    LATE("Woke Late");

    companion object {
        fun fromRaw(raw: String?): WakeStatus =
            entries.firstOrNull { it.name == raw } ?: PENDING
    }
}

enum class FocusOutcome(val label: String) {
    RETURNED_TO_SADHANA("Returned to Sadhana"),
    GRANTED_EXCEPTION("Mindful Exception"),
    SESSION_COMPLETED("Session Completed");

    companion object {
        fun fromRaw(raw: String?): FocusOutcome =
            entries.firstOrNull { it.name == raw } ?: RETURNED_TO_SADHANA
    }
}

enum class TemplePostType(val label: String) {
    ANNOUNCEMENT("Announcement"),
    FESTIVAL("Festival"),
    LECTURE("Lecture"),
    SEVA("Seva");

    companion object {
        fun fromRaw(raw: String?): TemplePostType =
            entries.firstOrNull { it.name == raw } ?: ANNOUNCEMENT
    }
}

@Keep
@IgnoreExtraProperties
data class UserProfile(
    val userId: String = "",
    val displayName: String = "Devotee",
    val email: String = "",
    val routineMode: String = RoutineMode.CONGREGATIONAL.name,
    val wakeTime: String = "04:45",
    val sleepTime: String = "21:45",
    val japaTargetRounds: Long = 16L,
    val readingTargetMinutes: Long = 30L,
    val hearingTargetMinutes: Long = 30L,
    val attendOnlineMangalAarti: Boolean = true,
    val gayatriInitiated: Boolean = false,
    val gayatriMorningTime: String = "06:15",
    val gayatriAfternoonTime: String = "12:15",
    val gayatriEveningTime: String = "18:15",
    val responsibilities: List<String> = listOf("Morning Sadhana", "Family / Work Seva"),
    val distractingPackages: List<String> = listOf(
        "com.instagram.android",
        "com.google.android.youtube",
        "com.zhiliaoapp.musically",
        "com.twitter.android"
    ),
    val focusStrictness: String = FocusStrictness.BALANCED.name,
    val calendarTradition: String = CalendarTradition.ISKCON_MAYAPUR.name,
    val locationName: String = "Mayapur, India",
    val latitude: Double = 23.4231,
    val longitude: Double = 88.3880,
    val timezoneId: String = "Asia/Kolkata",
    val followedTempleId: String = "ref_mayapur",
    val activeFestivalMode: String = "",
    val themeStyle: String = ThemeStyle.IVORY_MAROON.name,
    val darkModePreference: String = DarkModePreference.SYSTEM.name,
    val fontScaleLevel: String = FontScaleLevel.STANDARD.name,
    val bedtimeModeEnabled: Boolean = true,
    val onboardingCompleted: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class ScheduleItem(
    @DocumentId val id: String = "",
    val title: String = "",
    val category: String = ScheduleCategory.OTHER.name,
    val startTime: String = "05:00",
    val endTime: String = "06:00",
    val essential: Boolean = false,
    val completedDateKey: String = "",
    val notes: String = "",
    val sortOrder: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class DailyTask(
    @DocumentId val id: String = "",
    val title: String = "",
    val category: String = "Devotion",
    val dueDateKey: String = "",
    val reminderTime: String = "",
    val priority: String = TaskPriority.MEDIUM.name,
    val completed: Boolean = false,
    val notes: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class SadhanaDailyLog(
    @DocumentId val dateKey: String = "",
    val japaRounds: Long = 0L,
    val readingMinutes: Long = 0L,
    val hearingMinutes: Long = 0L,
    val mangalAartiAttended: Boolean = false,
    val gayatriMorningDone: Boolean = false,
    val gayatriAfternoonDone: Boolean = false,
    val gayatriEveningDone: Boolean = false,
    val pujaDone: Boolean = false,
    val wakeStatus: String = WakeStatus.PENDING.name,
    val wakeActualTime: String = "",
    val sevaMinutes: Long = 0L,
    val sevaNote: String = "",
    val reflectionNote: String = "",
    val creditedAudioIds: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FocusLog(
    @DocumentId val id: String = "",
    val packageName: String = "",
    val appLabel: String = "",
    val strictness: String = FocusStrictness.BALANCED.name,
    val outcome: String = FocusOutcome.RETURNED_TO_SADHANA.name,
    val reason: String = "",
    val durationMinutes: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class TempleCommunity(
    @DocumentId val id: String = "",
    val name: String = "",
    val city: String = "",
    val country: String = "",
    val tradition: String = CalendarTradition.ISKCON_MAYAPUR.name,
    val adminUid: String = "",
    val mangalAartiTime: String = "04:30",
    val darshanAartiTime: String = "07:00",
    val bhagavatamClassTime: String = "07:45",
    val sandhyaAartiTime: String = "19:00",
    val description: String = "",
    val liveStreamUrl: String = "",
    val visibility: String = "PUBLIC",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class TemplePost(
    @DocumentId val id: String = "",
    val templeId: String = "",
    val authorUid: String = "",
    val authorName: String = "",
    val postType: String = TemplePostType.ANNOUNCEMENT.name,
    val title: String = "",
    val body: String = "",
    val eventDateKey: String = "",
    val eventTime: String = "",
    val visibility: String = "PUBLIC",
    val volunteerUids: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class ChatMessage(
    val id: String,
    val isUser: Boolean,
    val text: String,
    val timestampMillis: Long = System.currentTimeMillis()
)

data class ParsedTaskDraft(
    val title: String,
    val category: String = "Devotion",
    val reminderTime: String = "",
    val priority: TaskPriority = TaskPriority.MEDIUM,
    val notes: String = ""
)
