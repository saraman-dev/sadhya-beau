package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.GuestLocalRepository
import com.example.data.local.FocusRuleEntity
import com.example.data.local.SadhanaLocalDatabase
import com.example.engine.IcsCalendarParser
import com.example.engine.VaishnavaCalendarEngine
import com.example.model.CalendarTradition
import com.example.model.DailyTask
import com.example.model.DevoteePersona
import com.example.model.RoutineTemplates
import com.example.model.ScheduleCategory
import com.example.model.ScheduleItem
import com.example.model.TempleCommunity
import com.example.model.TemplePost
import com.example.model.TemplePostType
import com.example.model.TimeMath
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SadhyaTestSuite {

    @Test
    fun `astronomical calendar calculates Ekadashi and Parana across multiple timezones`() {
        val cities = listOf(
            Triple(23.4231, 88.3880, "Asia/Kolkata"),
            Triple(40.7128, -74.0060, "America/New_York"),
            Triple(51.5074, -0.1278, "Europe/London")
        )
        for ((lat, lon, tz) in cities) {
            val days = VaishnavaCalendarEngine.calculateMonth(
                year = 2026,
                month = 5,
                latitude = lat,
                longitude = lon,
                timezoneId = tz,
                tradition = CalendarTradition.ISKCON_MAYAPUR
            )
            assertEquals("May 2026 should have 31 days for $tz", 31, days.size)
            val ekadashis = days.filter { it.isEkadashiFast }
            assertTrue("Expected at least 1 Ekadashi in May 2026 for $tz", ekadashis.isNotEmpty())
            ekadashis.forEach { ek ->
                assertTrue("Sunrise should be HH:mm format", ek.sunriseHHmm.matches(Regex("^\\d{2}:\\d{2}$")))
                assertTrue("Vaishnava masa should be populated", ek.masaName.isNotBlank())
                assertTrue("Ekadashi name should be populated", ek.ekadashiName.isNotBlank())
            }
            val paranaDays = days.filter { it.paranaWindow.isNotBlank() }
            assertTrue("Expected at least 1 Parana break-fast day in May 2026 for $tz", paranaDays.isNotEmpty())
        }
    }

    @Test
    fun `ics calendar parser handles folded lines, date-times, and escaped punctuation`() {
        val sampleIcs = """
            BEGIN:VCALENDAR
            VERSION:2.0
            BEGIN:VEVENT
            SUMMARY:Gaura Purnima\, Festival
             Evening Kirtan
            DTSTART:20260303T183000Z
            DTEND:20260303T203000Z
            LOCATION:Mayapur\; Temple Hall
            DESCRIPTION:Abhisheka\nPrasadam feast
            END:VEVENT
            END:VCALENDAR
        """.trimIndent()

        val events = IcsCalendarParser.parse(sampleIcs, "Temple.ics")
        assertEquals(1, events.size)
        val ev = events.first()
        assertEquals("2026-03-03", ev.dateKey)
        assertEquals("18:30", ev.startTime)
        assertEquals("20:30", ev.endTime)
        assertEquals("Gaura Purnima, FestivalEvening Kirtan", ev.title)
        assertEquals("Mayapur; Temple Hall", ev.location)
        assertTrue(ev.description.contains("Abhisheka\nPrasadam feast"))
    }

    @Test
    fun `routine templates cover all 7 personas and TimeMath handles overnight wrap-around`() {
        for (persona in DevoteePersona.entries) {
            val items = RoutineTemplates.scheduleForPersona(persona)
            assertTrue("Persona ${persona.name} must produce non-empty schedule", items.size >= 4)
            assertTrue("Persona ${persona.name} must include at least one essential block", items.any { it.essential })
        }

        // Overnight block: 21:30 -> 04:30 (7 hours = 420 minutes)
        assertEquals(420, TimeMath.blockDurationMinutes("21:30", "04:30"))
        assertTrue(TimeMath.isTimeInBlock(TimeMath.parseHHmmToMinutes("23:15"), "21:30", "04:30"))
        assertTrue(TimeMath.isTimeInBlock(TimeMath.parseHHmmToMinutes("02:00"), "21:30", "04:30"))
        assertFalse(TimeMath.isTimeInBlock(TimeMath.parseHHmmToMinutes("10:00"), "21:30", "04:30"))

        val schedule = listOf(
            ScheduleItem("s1", "Japa", ScheduleCategory.JAPA.name, "05:00", "06:30", true),
            ScheduleItem("s2", "Night Rest", ScheduleCategory.REST.name, "21:30", "04:30", true)
        )
        val activeAtMidnight = TimeMath.findCurrentOrNextActivity(schedule, TimeMath.parseHHmmToMinutes("00:30"))
        assertNotNull(activeAtMidnight)
        assertEquals("Night Rest", activeAtMidnight!!.first.title)
        assertTrue(activeAtMidnight.second)
    }

    @Test
    fun `room FocusRuleEntity persists rules and temporary exceptions in memory`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, SadhanaLocalDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val dao = db.focusRuleDao()
            dao.upsert(FocusRuleEntity("com.instagram.android", "Instagram", true, true, 0L))
            val futureMs = System.currentTimeMillis() + 300_000L
            dao.setExceptionUntil("com.instagram.android", futureMs)

            val loaded = dao.getByPackage("com.instagram.android")
            assertNotNull(loaded)
            assertEquals("Instagram", loaded!!.appLabel)
            assertEquals(futureMs, loaded.exceptionUntilMillis)
            assertTrue(loaded.blockDuringFocus)

            dao.deleteByPackage("com.instagram.android")
            assertTrue(dao.getAllRulesSnapshot().isEmpty())
        } finally {
            db.close()
        }
    }

    @Test
    fun `GuestLocalRepository provides full offline CRUD parity and reset`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = GuestLocalRepository(context)
        val uid = GuestLocalRepository.GUEST_UID

        // Ensure seeded profile exists
        val ensured = repo.ensureUserProfileExists(uid, "Guest Devotee", "")
        assertTrue(ensured.isSuccess)
        assertEquals(uid, ensured.getOrThrow().userId)

        // Update profile
        val upd = repo.updateUserProfileFields(uid, mapOf("displayName" to "Gauranga Das", "japaTargetRounds" to 16L))
        assertTrue(upd.isSuccess)
        assertEquals("Gauranga Das", repo.observeUserProfile(uid).first()?.displayName)

        // Schedule & Task CRUD
        val savedSchedId = repo.saveScheduleItem(
            uid,
            ScheduleItem(title = "Tulasi Puja", category = ScheduleCategory.PUJA.name, startTime = "04:50", endTime = "05:05", essential = true)
        ).getOrThrow()
        assertTrue(repo.observeSchedule(uid).first().any { it.id == savedSchedId })

        val savedTaskId = repo.saveTask(uid, DailyTask(title = "Buy fresh flowers", reminderTime = "06:30")).getOrThrow()
        assertTrue(repo.observeTasks(uid).first().any { it.id == savedTaskId })
        repo.toggleTaskCompleted(uid, savedTaskId, true)
        assertTrue(repo.observeTasks(uid).first().first { it.id == savedTaskId }.completed)

        // Sadhana Daily Log upsert
        val logRes = repo.upsertSadhanaLog(uid, "2026-05-15") { it.copy(japaRounds = 12L, readingMinutes = 30L) }
        assertTrue(logRes.isSuccess)
        assertEquals(12L, repo.observeRecentSadhanaLogs(uid).first().first { it.dateKey == "2026-05-15" }.japaRounds)

        // Local Temple + SEVA volunteer toggle
        val templeId = repo.createTemple(uid, TempleCommunity(name = "Test Local Mandir", city = "Pune", country = "India")).getOrThrow()
        val postId = repo.createTemplePost(
            uid,
            TemplePost(templeId = templeId, postType = TemplePostType.SEVA.name, title = "Garland Seva", body = "Morning flowers")
        ).getOrThrow()
        assertTrue(repo.toggleSevaVolunteer(uid, templeId, postId).isSuccess)
        assertTrue(uid in repo.observeTemplePosts(templeId).first().first { it.id == postId }.volunteerUids)

        // Reset guest data cleanly
        assertTrue(repo.deleteAccountAndData(uid).isSuccess)
    }
}
