package com.example.data

import android.content.Context
import com.example.R
import com.example.model.CalendarTradition
import com.example.model.DailyTask
import com.example.model.DarkModePreference
import com.example.model.DevoteePersona
import com.example.model.FocusLog
import com.example.model.FocusOutcome
import com.example.model.FocusStrictness
import com.example.model.FontScaleLevel
import com.example.model.RoutineMode
import com.example.model.RoutineTemplates
import com.example.model.SadhanaDailyLog
import com.example.model.ScheduleCategory
import com.example.model.ScheduleItem
import com.example.model.TaskPriority
import com.example.model.TempleCommunity
import com.example.model.TemplePost
import com.example.model.TemplePostType
import com.example.model.ThemeStyle
import com.example.model.UserProfile
import com.example.model.WakeStatus
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.TimeZone

class SadhanaFirestoreRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) : SadhanaDataRepository {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    override val isGuestMode: Boolean = false

    private fun requireUserId(expectedUid: String): String {
        val currentUid = auth.currentUser?.uid
            ?: throw IllegalStateException("Please sign in with Google to access cloud Sadhana data.")
        check(currentUid == expectedUid) { "Active session changed; refusing cross-user operation." }
        return currentUid
    }

    private fun defaultProfileMap(uid: String, displayName: String, email: String): MutableMap<String, Any> {
        val safeName = displayName.trim().take(80).ifBlank { "Devotee" }
        val safeEmail = email.trim().take(160)
        val tzId = TimeZone.getDefault().id.take(80).ifBlank { "Asia/Kolkata" }
        return mutableMapOf(
            "userId" to uid,
            "displayName" to safeName,
            "email" to safeEmail,
            "routineMode" to RoutineMode.CONGREGATIONAL.name,
            "wakeTime" to "04:45",
            "sleepTime" to "21:45",
            "japaTargetRounds" to 16L,
            "readingTargetMinutes" to 30L,
            "hearingTargetMinutes" to 30L,
            "attendOnlineMangalAarti" to true,
            "gayatriInitiated" to false,
            "gayatriMorningTime" to "06:15",
            "gayatriAfternoonTime" to "12:15",
            "gayatriEveningTime" to "18:15",
            "responsibilities" to listOf("Morning Sadhana", "Daily Seva"),
            "distractingPackages" to listOf(
                "com.instagram.android",
                "com.google.android.youtube",
                "com.zhiliaoapp.musically",
                "com.twitter.android"
            ),
            "focusStrictness" to FocusStrictness.BALANCED.name,
            "calendarTradition" to CalendarTradition.ISKCON_MAYAPUR.name,
            "locationName" to "Mayapur, India",
            "latitude" to 23.4231,
            "longitude" to 88.3880,
            "timezoneId" to tzId,
            "followedTempleId" to "ref_mayapur",
            "activeFestivalMode" to "",
            "themeStyle" to ThemeStyle.IVORY_MAROON.name,
            "darkModePreference" to DarkModePreference.SYSTEM.name,
            "fontScaleLevel" to FontScaleLevel.STANDARD.name,
            "bedtimeModeEnabled" to true,
            "onboardingCompleted" to false,
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
    }

    override suspend fun ensureUserProfileExists(
        uid: String,
        displayName: String,
        email: String
    ): Result<UserProfile> {
        val path = "users/$uid"
        return try {
            val verifiedUid = requireUserId(uid)
            val docRef = db.collection("users").document(verifiedUid)
            val snap = docRef.get().await()
            if (snap.exists()) {
                val existing = snap.toObject(
                    UserProfile::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                ) ?: UserProfile(userId = verifiedUid, displayName = displayName.ifBlank { "Devotee" }, email = email)
                return Result.success(existing)
            }
            val payload = defaultProfileMap(verifiedUid, displayName, email)
            docRef.set(payload).await()

            // Seed starter schedule for brand new cloud devotees
            val starterSchedule = RoutineTemplates.scheduleForPersona(DevoteePersona.CONGREGATIONAL)
            val batch = db.batch()
            val schedCol = docRef.collection("schedule_items")
            starterSchedule.forEachIndexed { idx, item ->
                val itemRef = schedCol.document("starter_${idx + 1}")
                batch.set(itemRef, scheduleItemToCreateMap(item.copy(sortOrder = (idx + 1).toLong())))
            }
            batch.commit().await()

            val createdSnap = docRef.get().await()
            val profile = createdSnap.toObject(
                UserProfile::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            ) ?: UserProfile(userId = verifiedUid, displayName = displayName.ifBlank { "Devotee" }, email = email)
            Result.success(profile)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    override fun observeUserProfile(uid: String): Flow<UserProfile?> {
        val path = "users/$uid"
        return db.collection("users").document(uid)
            .snapshots()
            .map { snap ->
                if (!snap.exists()) null
                else snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(firestoreError ?: error, OperationType.GET, path)
                }
                throw error
            }
    }

    override suspend fun updateUserProfileFields(uid: String, fields: Map<String, Any>): Result<Unit> {
        val path = "users/$uid"
        return try {
            val verifiedUid = requireUserId(uid)
            val docRef = db.collection("users").document(verifiedUid)
            val allowedKeys = setOf(
                "displayName", "email", "routineMode", "wakeTime", "sleepTime",
                "japaTargetRounds", "readingTargetMinutes", "hearingTargetMinutes",
                "attendOnlineMangalAarti", "gayatriInitiated", "gayatriMorningTime",
                "gayatriAfternoonTime", "gayatriEveningTime", "responsibilities",
                "distractingPackages", "focusStrictness", "calendarTradition",
                "locationName", "latitude", "longitude", "timezoneId",
                "followedTempleId", "activeFestivalMode", "themeStyle",
                "darkModePreference", "fontScaleLevel", "bedtimeModeEnabled",
                "onboardingCompleted"
            )
            val sanitized = sanitizeProfileFields(fields.filterKeys { it in allowedKeys })
            if (sanitized.isEmpty()) return Result.success(Unit)

            val snap = docRef.get().await()
            if (!snap.exists()) {
                val base = defaultProfileMap(
                    verifiedUid,
                    auth.currentUser?.displayName ?: "Devotee",
                    auth.currentUser?.email ?: ""
                )
                base.putAll(sanitized)
                docRef.set(base).await()
            } else {
                val updatePayload = sanitized.toMutableMap()
                updatePayload["updatedAt"] = FieldValue.serverTimestamp()
                docRef.update(updatePayload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    private fun sanitizeProfileFields(raw: Map<String, Any>): Map<String, Any> {
        val out = mutableMapOf<String, Any>()
        raw.forEach { (k, v) ->
            when (k) {
                "displayName" -> out[k] = (v as? String)?.trim()?.take(80)?.ifBlank { "Devotee" } ?: "Devotee"
                "email" -> out[k] = (v as? String)?.trim()?.take(160) ?: ""
                "japaTargetRounds" -> out[k] = ((v as? Number)?.toLong() ?: 16L).coerceIn(1L, 192L)
                "readingTargetMinutes", "hearingTargetMinutes" -> out[k] = ((v as? Number)?.toLong() ?: 30L).coerceIn(0L, 600L)
                "responsibilities" -> {
                    val list = (v as? List<*>)?.filterIsInstance<String>()?.map { it.trim().take(60) }?.filter { it.isNotBlank() }?.take(15) ?: emptyList()
                    out[k] = list
                }
                "distractingPackages" -> {
                    val list = (v as? List<*>)?.filterIsInstance<String>()?.map { it.trim().take(120) }?.filter { it.isNotBlank() }?.take(30) ?: emptyList()
                    out[k] = list
                }
                "latitude" -> out[k] = ((v as? Number)?.toDouble() ?: 23.4231).coerceIn(-90.0, 90.0)
                "longitude" -> out[k] = ((v as? Number)?.toDouble() ?: 88.3880).coerceIn(-180.0, 180.0)
                "locationName" -> out[k] = (v as? String)?.trim()?.take(120)?.ifBlank { "Mayapur, India" } ?: "Mayapur, India"
                "timezoneId" -> out[k] = (v as? String)?.trim()?.take(80)?.ifBlank { "Asia/Kolkata" } ?: "Asia/Kolkata"
                "followedTempleId" -> out[k] = (v as? String)?.trim()?.take(128) ?: ""
                "activeFestivalMode" -> out[k] = (v as? String)?.trim()?.take(120) ?: ""
                else -> out[k] = v
            }
        }
        return out
    }

    override fun observeSchedule(uid: String): Flow<List<ScheduleItem>> {
        val path = "users/$uid/schedule_items"
        return db.collection("users").document(uid).collection("schedule_items")
            .snapshots()
            .map { snap ->
                snap.toObjects(ScheduleItem::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedWith(compareBy<ScheduleItem> { it.startTime }.thenBy { it.sortOrder })
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                }
                throw error
            }
    }

    private fun scheduleItemToCreateMap(item: ScheduleItem): Map<String, Any> = mapOf(
        "title" to item.title.trim().take(120).ifBlank { "Sadhana Block" },
        "category" to ScheduleCategory.fromRaw(item.category).name,
        "startTime" to validHHmm(item.startTime, "05:00"),
        "endTime" to validHHmm(item.endTime, "06:00"),
        "essential" to item.essential,
        "completedDateKey" to validOptionalDateKey(item.completedDateKey),
        "notes" to item.notes.trim().take(300),
        "sortOrder" to item.sortOrder.coerceIn(0L, 500L),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
    )

    override suspend fun saveScheduleItem(uid: String, item: ScheduleItem): Result<String> {
        val basePath = "users/$uid/schedule_items"
        return try {
            val verifiedUid = requireUserId(uid)
            val col = db.collection("users").document(verifiedUid).collection("schedule_items")
            val isUpdate = item.id.isNotBlank() && col.document(item.id).get().await().exists()
            if (isUpdate) {
                val docRef = col.document(item.id)
                docRef.update(
                    mapOf(
                        "title" to item.title.trim().take(120).ifBlank { "Sadhana Block" },
                        "category" to ScheduleCategory.fromRaw(item.category).name,
                        "startTime" to validHHmm(item.startTime, "05:00"),
                        "endTime" to validHHmm(item.endTime, "06:00"),
                        "essential" to item.essential,
                        "completedDateKey" to validOptionalDateKey(item.completedDateKey),
                        "notes" to item.notes.trim().take(300),
                        "sortOrder" to item.sortOrder.coerceIn(0L, 500L),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
                Result.success(docRef.id)
            } else {
                val docRef = if (item.id.isNotBlank() && isSafeId(item.id)) col.document(item.id) else col.document()
                docRef.set(scheduleItemToCreateMap(item)).await()
                Result.success(docRef.id)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, basePath)
            Result.failure(e)
        }
    }

    override suspend fun replaceSchedule(uid: String, items: List<ScheduleItem>): Result<Unit> {
        val basePath = "users/$uid/schedule_items"
        return try {
            val verifiedUid = requireUserId(uid)
            val col = db.collection("users").document(verifiedUid).collection("schedule_items")
            val existing = col.get().await()
            val batch = db.batch()
            existing.documents.forEach { batch.delete(it.reference) }
            items.take(40).forEachIndexed { index, item ->
                val ref = col.document()
                batch.set(ref, scheduleItemToCreateMap(item.copy(sortOrder = (index + 1).toLong())))
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, basePath)
            Result.failure(e)
        }
    }

    override suspend fun toggleScheduleCompletion(uid: String, itemId: String, dateKey: String?): Result<Unit> {
        val path = "users/$uid/schedule_items/$itemId"
        return try {
            val verifiedUid = requireUserId(uid)
            require(itemId.isNotBlank()) { "Schedule item ID required" }
            db.collection("users").document(verifiedUid).collection("schedule_items").document(itemId)
                .update(
                    mapOf(
                        "completedDateKey" to validOptionalDateKey(dateKey.orEmpty()),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    override suspend fun deleteScheduleItem(uid: String, itemId: String): Result<Unit> {
        val path = "users/$uid/schedule_items/$itemId"
        return try {
            val verifiedUid = requireUserId(uid)
            db.collection("users").document(verifiedUid).collection("schedule_items").document(itemId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    override fun observeTasks(uid: String): Flow<List<DailyTask>> {
        val path = "users/$uid/tasks"
        return db.collection("users").document(uid).collection("tasks")
            .snapshots()
            .map { snap ->
                snap.toObjects(DailyTask::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedWith(compareBy<DailyTask> { it.completed }.thenByDescending { it.createdAt?.seconds ?: 0L })
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                }
                throw error
            }
    }

    override suspend fun saveTask(uid: String, task: DailyTask): Result<String> {
        val basePath = "users/$uid/tasks"
        return try {
            val verifiedUid = requireUserId(uid)
            val col = db.collection("users").document(verifiedUid).collection("tasks")
            val isUpdate = task.id.isNotBlank() && col.document(task.id).get().await().exists()
            if (isUpdate) {
                val docRef = col.document(task.id)
                docRef.update(
                    mapOf(
                        "title" to task.title.trim().take(160).ifBlank { "Task" },
                        "category" to task.category.trim().take(40).ifBlank { "Devotion" },
                        "dueDateKey" to validOptionalDateKey(task.dueDateKey),
                        "reminderTime" to validOptionalHHmm(task.reminderTime),
                        "priority" to TaskPriority.fromRaw(task.priority).name,
                        "completed" to task.completed,
                        "notes" to task.notes.trim().take(400),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
                Result.success(docRef.id)
            } else {
                val docRef = col.document()
                docRef.set(
                    mapOf(
                        "title" to task.title.trim().take(160).ifBlank { "Task" },
                        "category" to task.category.trim().take(40).ifBlank { "Devotion" },
                        "dueDateKey" to validOptionalDateKey(task.dueDateKey),
                        "reminderTime" to validOptionalHHmm(task.reminderTime),
                        "priority" to TaskPriority.fromRaw(task.priority).name,
                        "completed" to task.completed,
                        "notes" to task.notes.trim().take(400),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
                Result.success(docRef.id)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, basePath)
            Result.failure(e)
        }
    }

    override suspend fun toggleTaskCompleted(uid: String, taskId: String, completed: Boolean): Result<Unit> {
        val path = "users/$uid/tasks/$taskId"
        return try {
            val verifiedUid = requireUserId(uid)
            db.collection("users").document(verifiedUid).collection("tasks").document(taskId)
                .update(mapOf("completed" to completed, "updatedAt" to FieldValue.serverTimestamp()))
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    override suspend fun deleteTask(uid: String, taskId: String): Result<Unit> {
        val path = "users/$uid/tasks/$taskId"
        return try {
            val verifiedUid = requireUserId(uid)
            db.collection("users").document(verifiedUid).collection("tasks").document(taskId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    override fun observeRecentSadhanaLogs(uid: String): Flow<List<SadhanaDailyLog>> {
        val path = "users/$uid/sadhana_logs"
        return db.collection("users").document(uid).collection("sadhana_logs")
            .snapshots()
            .map { snap ->
                snap.toObjects(SadhanaDailyLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.dateKey }
                    .take(30)
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                }
                throw error
            }
    }

    override suspend fun upsertSadhanaLog(
        uid: String,
        dateKey: String,
        transform: (SadhanaDailyLog) -> SadhanaDailyLog
    ): Result<SadhanaDailyLog> {
        val path = "users/$uid/sadhana_logs/$dateKey"
        return try {
            val verifiedUid = requireUserId(uid)
            val docRef = db.collection("users").document(verifiedUid).collection("sadhana_logs").document(dateKey)
            val snap = docRef.get().await()
            val current = if (snap.exists()) {
                snap.toObject(SadhanaDailyLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    ?: SadhanaDailyLog(dateKey = dateKey)
            } else {
                SadhanaDailyLog(dateKey = dateKey)
            }
            val updated = transform(current).copy(dateKey = dateKey)
            val fields = mutableMapOf<String, Any>(
                "japaRounds" to updated.japaRounds.coerceIn(0L, 192L),
                "readingMinutes" to updated.readingMinutes.coerceIn(0L, 720L),
                "hearingMinutes" to updated.hearingMinutes.coerceIn(0L, 720L),
                "mangalAartiAttended" to updated.mangalAartiAttended,
                "gayatriMorningDone" to updated.gayatriMorningDone,
                "gayatriAfternoonDone" to updated.gayatriAfternoonDone,
                "gayatriEveningDone" to updated.gayatriEveningDone,
                "pujaDone" to updated.pujaDone,
                "wakeStatus" to WakeStatus.fromRaw(updated.wakeStatus).name,
                "wakeActualTime" to validOptionalHHmm(updated.wakeActualTime),
                "sevaMinutes" to updated.sevaMinutes.coerceIn(0L, 720L),
                "sevaNote" to updated.sevaNote.trim().take(300),
                "reflectionNote" to updated.reflectionNote.trim().take(600),
                "creditedAudioIds" to updated.creditedAudioIds.distinct().take(30),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (snap.exists()) {
                docRef.update(fields).await()
            } else {
                fields["createdAt"] = FieldValue.serverTimestamp()
                docRef.set(fields).await()
            }
            Result.success(updated)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
            Result.failure(e)
        }
    }

    override fun observeFocusLogs(uid: String): Flow<List<FocusLog>> {
        val path = "users/$uid/focus_logs"
        return db.collection("users").document(uid).collection("focus_logs")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(30)
            .snapshots()
            .map { snap ->
                snap.toObjects(FocusLog::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == uid) {
                    handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                }
                throw error
            }
    }

    override suspend fun addFocusLog(uid: String, log: FocusLog): Result<Unit> {
        val path = "users/$uid/focus_logs"
        return try {
            val verifiedUid = requireUserId(uid)
            val docRef = db.collection("users").document(verifiedUid).collection("focus_logs").document()
            docRef.set(
                mapOf(
                    "packageName" to log.packageName.trim().take(160).ifBlank { "com.sadhya.focus" },
                    "appLabel" to log.appLabel.trim().take(100).ifBlank { "Focus Session" },
                    "strictness" to FocusStrictness.fromRaw(log.strictness).name,
                    "outcome" to FocusOutcome.fromRaw(log.outcome).name,
                    "reason" to log.reason.trim().take(300),
                    "durationMinutes" to log.durationMinutes.coerceIn(0L, 720L),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    override suspend fun deleteFocusLog(uid: String, logId: String): Result<Unit> {
        val path = "users/$uid/focus_logs/$logId"
        return try {
            val verifiedUid = requireUserId(uid)
            db.collection("users").document(verifiedUid).collection("focus_logs").document(logId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    override fun observeTemples(): Flow<List<TempleCommunity>> {
        val path = "temples"
        return db.collection("temples")
            .whereEqualTo("visibility", "PUBLIC")
            .snapshots()
            .map { snap ->
                snap.toObjects(TempleCommunity::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedBy { it.name }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser != null) {
                    handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                }
                throw error
            }
    }

    override suspend fun createTemple(uid: String, temple: TempleCommunity): Result<String> {
        val path = "temples"
        return try {
            val verifiedUid = requireUserId(uid)
            val docRef = db.collection("temples").document()
            docRef.set(
                mapOf(
                    "name" to temple.name.trim().take(120).ifBlank { "Local Vaishnava Temple" },
                    "city" to temple.city.trim().take(80).ifBlank { "City" },
                    "country" to temple.country.trim().take(80).ifBlank { "Country" },
                    "tradition" to CalendarTradition.fromRaw(temple.tradition).name,
                    "adminUid" to verifiedUid,
                    "mangalAartiTime" to validHHmm(temple.mangalAartiTime, "04:30"),
                    "darshanAartiTime" to validHHmm(temple.darshanAartiTime, "07:00"),
                    "bhagavatamClassTime" to validHHmm(temple.bhagavatamClassTime, "07:45"),
                    "sandhyaAartiTime" to validHHmm(temple.sandhyaAartiTime, "19:00"),
                    "description" to temple.description.trim().take(500),
                    "liveStreamUrl" to temple.liveStreamUrl.trim().take(300),
                    "visibility" to "PUBLIC",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    override fun observeTemplePosts(templeId: String): Flow<List<TemplePost>> {
        val path = "temples/$templeId/posts"
        return db.collection("temples").document(templeId).collection("posts")
            .whereEqualTo("visibility", "PUBLIC")
            .snapshots()
            .map { snap ->
                snap.toObjects(TemplePost::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                if (auth.currentUser != null) {
                    handleFirestoreError(firestoreError ?: error, OperationType.LIST, path)
                }
                throw error
            }
    }

    override suspend fun createTemplePost(uid: String, post: TemplePost): Result<String> {
        val path = "temples/${post.templeId}/posts"
        return try {
            val verifiedUid = requireUserId(uid)
            val docRef = db.collection("temples").document(post.templeId).collection("posts").document()
            docRef.set(
                mapOf(
                    "templeId" to post.templeId,
                    "authorUid" to verifiedUid,
                    "authorName" to post.authorName.trim().take(80).ifBlank { "Temple Servant" },
                    "postType" to TemplePostType.fromRaw(post.postType).name,
                    "title" to post.title.trim().take(140).ifBlank { "Temple Update" },
                    "body" to post.body.trim().take(1000).ifBlank { "Hare Krishna!" },
                    "eventDateKey" to validOptionalDateKey(post.eventDateKey),
                    "eventTime" to validOptionalHHmm(post.eventTime),
                    "visibility" to "PUBLIC",
                    "volunteerUids" to emptyList<String>(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    override suspend fun deleteTemplePost(templeId: String, postId: String): Result<Unit> {
        val path = "temples/$templeId/posts/$postId"
        return try {
            db.collection("temples").document(templeId).collection("posts").document(postId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    override suspend fun toggleSevaVolunteer(uid: String, templeId: String, postId: String): Result<Unit> {
        val path = "temples/$templeId/posts/$postId"
        return try {
            val verifiedUid = requireUserId(uid)
            val postRef = db.collection("temples").document(templeId).collection("posts").document(postId)
            db.runTransaction { tx ->
                val snap = tx.get(postRef)
                val existing = (snap.get("volunteerUids") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                val updated = if (verifiedUid in existing) {
                    existing - verifiedUid
                } else {
                    (existing + verifiedUid).take(100)
                }
                tx.update(
                    postRef,
                    mapOf(
                        "volunteerUids" to updated,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }.await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    override suspend fun deleteAccountAndData(uid: String): Result<Unit> {
        val path = "users/$uid"
        return try {
            val verifiedUid = requireUserId(uid)
            val userDoc = db.collection("users").document(verifiedUid)
            for (sub in listOf("schedule_items", "tasks", "sadhana_logs", "focus_logs")) {
                val docs = userDoc.collection(sub).get().await()
                if (!docs.isEmpty) {
                    val batch = db.batch()
                    docs.documents.forEach { batch.delete(it.reference) }
                    batch.commit().await()
                }
            }
            userDoc.delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    private fun isSafeId(id: String): Boolean =
        id.length in 1..128 && id.matches(Regex("^[a-zA-Z0-9_\\-]+$"))

    private fun validHHmm(raw: String, fallback: String): String =
        if (raw.matches(Regex("^([01][0-9]|2[0-3]):[0-5][0-9]$"))) raw else fallback

    private fun validOptionalHHmm(raw: String): String =
        if (raw.matches(Regex("^([01][0-9]|2[0-3]):[0-5][0-9]$"))) raw else ""

    private fun validOptionalDateKey(raw: String): String =
        if (raw.matches(Regex("^[0-9]{4}-[0-9]{2}-[0-9]{2}$"))) raw else ""
}
