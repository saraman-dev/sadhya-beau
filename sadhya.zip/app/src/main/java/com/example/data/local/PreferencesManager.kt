package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.DevoteePersona
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.sadhyaDataStore: DataStore<Preferences> by preferencesDataStore(name = "sadhya_prefs")

data class LocalPrefsState(
    val guestModeEnabled: Boolean = false,
    val hasSeenAppGuide: Boolean = false,
    val dismissedTourBanner: Boolean = false,
    val devoteePersona: DevoteePersona = DevoteePersona.CONGREGATIONAL,
    val elderModeEnabled: Boolean = false,
    val japaBeadCount: Int = 0,
    val keepScreenOnJapa: Boolean = true,
    val wakeAlarmEnabled: Boolean = true,
    val wakeAlarmTime: String = "04:45",
    val bedtimeWindDownEnabled: Boolean = true,
    val bedtimeTime: String = "21:45",
    val gayatriAlarmsEnabled: Boolean = false,
    val gayatriMorningTime: String = "06:15",
    val gayatriAfternoonTime: String = "12:15",
    val gayatriEveningTime: String = "18:15",
    val focusShieldActive: Boolean = false,
    val focusShieldEndEpochMs: Long = 0L,
    val focusShieldDurationMinutes: Int = 45,
    val focusShieldStrictness: String = "BALANCED",
    val showQuickAudioCard: Boolean = true,
    val showWakeUpCard: Boolean = true,
    val showTasksCard: Boolean = true,
    val regulativeVowsDateKey: String = "",
    val vowNoMeat: Boolean = false,
    val vowNoIntoxication: Boolean = false,
    val vowNoGambling: Boolean = false,
    val vowCleanLiving: Boolean = false
)

class PreferencesManager(private val context: Context) {

    private object Keys {
        val GUEST_MODE = booleanPreferencesKey("guest_mode_enabled")
        val HAS_SEEN_GUIDE = booleanPreferencesKey("has_seen_app_guide")
        val DISMISSED_TOUR = booleanPreferencesKey("dismissed_tour_banner")
        val DEVOTEE_PERSONA = stringPreferencesKey("devotee_persona")
        val ELDER_MODE = booleanPreferencesKey("elder_mode_enabled")
        val JAPA_BEAD_COUNT = intPreferencesKey("japa_bead_count")
        val KEEP_SCREEN_ON_JAPA = booleanPreferencesKey("keep_screen_on_japa")
        val WAKE_ALARM_ENABLED = booleanPreferencesKey("wake_alarm_enabled")
        val WAKE_ALARM_TIME = stringPreferencesKey("wake_alarm_time")
        val BEDTIME_ENABLED = booleanPreferencesKey("bedtime_winddown_enabled")
        val BEDTIME_TIME = stringPreferencesKey("bedtime_time")
        val GAYATRI_ALARMS_ENABLED = booleanPreferencesKey("gayatri_alarms_enabled")
        val GAYATRI_MORNING_TIME = stringPreferencesKey("gayatri_morning_time")
        val GAYATRI_AFTERNOON_TIME = stringPreferencesKey("gayatri_afternoon_time")
        val GAYATRI_EVENING_TIME = stringPreferencesKey("gayatri_evening_time")
        val FOCUS_SHIELD_ACTIVE = booleanPreferencesKey("focus_shield_active")
        val FOCUS_SHIELD_END_EPOCH = longPreferencesKey("focus_shield_end_epoch_ms")
        val FOCUS_SHIELD_DURATION_MIN = intPreferencesKey("focus_shield_duration_min")
        val FOCUS_SHIELD_STRICTNESS = stringPreferencesKey("focus_shield_strictness")
        val SHOW_QUICK_AUDIO = booleanPreferencesKey("show_quick_audio_card")
        val SHOW_WAKE_UP = booleanPreferencesKey("show_wake_up_card")
        val SHOW_TASKS = booleanPreferencesKey("show_tasks_card")
        val VOWS_DATE = stringPreferencesKey("regulative_vows_date")
        val VOW_1 = booleanPreferencesKey("vow_no_meat")
        val VOW_2 = booleanPreferencesKey("vow_no_intox")
        val VOW_3 = booleanPreferencesKey("vow_no_gambling")
        val VOW_4 = booleanPreferencesKey("vow_clean_living")
    }

    val prefsFlow: Flow<LocalPrefsState> = context.sadhyaDataStore.data.map { p ->
        LocalPrefsState(
            guestModeEnabled = p[Keys.GUEST_MODE] ?: false,
            hasSeenAppGuide = p[Keys.HAS_SEEN_GUIDE] ?: false,
            dismissedTourBanner = p[Keys.DISMISSED_TOUR] ?: false,
            devoteePersona = DevoteePersona.fromRaw(p[Keys.DEVOTEE_PERSONA]),
            elderModeEnabled = p[Keys.ELDER_MODE] ?: false,
            japaBeadCount = (p[Keys.JAPA_BEAD_COUNT] ?: 0).coerceIn(0, 107),
            keepScreenOnJapa = p[Keys.KEEP_SCREEN_ON_JAPA] ?: true,
            wakeAlarmEnabled = p[Keys.WAKE_ALARM_ENABLED] ?: true,
            wakeAlarmTime = p[Keys.WAKE_ALARM_TIME] ?: "04:45",
            bedtimeWindDownEnabled = p[Keys.BEDTIME_ENABLED] ?: true,
            bedtimeTime = p[Keys.BEDTIME_TIME] ?: "21:45",
            gayatriAlarmsEnabled = p[Keys.GAYATRI_ALARMS_ENABLED] ?: false,
            gayatriMorningTime = p[Keys.GAYATRI_MORNING_TIME] ?: "06:15",
            gayatriAfternoonTime = p[Keys.GAYATRI_AFTERNOON_TIME] ?: "12:15",
            gayatriEveningTime = p[Keys.GAYATRI_EVENING_TIME] ?: "18:15",
            focusShieldActive = p[Keys.FOCUS_SHIELD_ACTIVE] ?: false,
            focusShieldEndEpochMs = p[Keys.FOCUS_SHIELD_END_EPOCH] ?: 0L,
            focusShieldDurationMinutes = p[Keys.FOCUS_SHIELD_DURATION_MIN] ?: 45,
            focusShieldStrictness = p[Keys.FOCUS_SHIELD_STRICTNESS] ?: "BALANCED",
            showQuickAudioCard = p[Keys.SHOW_QUICK_AUDIO] ?: true,
            showWakeUpCard = p[Keys.SHOW_WAKE_UP] ?: true,
            showTasksCard = p[Keys.SHOW_TASKS] ?: true,
            regulativeVowsDateKey = p[Keys.VOWS_DATE] ?: "",
            vowNoMeat = p[Keys.VOW_1] ?: false,
            vowNoIntoxication = p[Keys.VOW_2] ?: false,
            vowNoGambling = p[Keys.VOW_3] ?: false,
            vowCleanLiving = p[Keys.VOW_4] ?: false
        )
    }

    suspend fun setGuestMode(enabled: Boolean) {
        context.sadhyaDataStore.edit { it[Keys.GUEST_MODE] = enabled }
    }

    suspend fun setHasSeenAppGuide(seen: Boolean) {
        context.sadhyaDataStore.edit {
            it[Keys.HAS_SEEN_GUIDE] = seen
            if (seen) it[Keys.DISMISSED_TOUR] = true
        }
    }

    suspend fun setDismissedTourBanner(dismissed: Boolean) {
        context.sadhyaDataStore.edit { it[Keys.DISMISSED_TOUR] = dismissed }
    }

    suspend fun setDevoteePersona(persona: DevoteePersona, updateElderMode: Boolean = false) {
        context.sadhyaDataStore.edit {
            it[Keys.DEVOTEE_PERSONA] = persona.name
            if (updateElderMode) {
                it[Keys.ELDER_MODE] = persona.defaultElderMode
            }
        }
    }

    suspend fun setElderMode(enabled: Boolean) {
        context.sadhyaDataStore.edit { it[Keys.ELDER_MODE] = enabled }
    }

    suspend fun setJapaBeadCount(count: Int) {
        context.sadhyaDataStore.edit { it[Keys.JAPA_BEAD_COUNT] = count.coerceIn(0, 107) }
    }

    /**
     * Atomically increments the bead counter by 1.
     * Returns 108 (and resets stored bead count to 0) when a full round completes.
     */
    suspend fun incrementJapaBead(): Int {
        var resultingCount = 0
        context.sadhyaDataStore.edit { prefs ->
            val current = (prefs[Keys.JAPA_BEAD_COUNT] ?: 0).coerceIn(0, 107)
            val next = current + 1
            if (next >= 108) {
                prefs[Keys.JAPA_BEAD_COUNT] = 0
                resultingCount = 108
            } else {
                prefs[Keys.JAPA_BEAD_COUNT] = next
                resultingCount = next
            }
        }
        return resultingCount
    }

    suspend fun decrementJapaBead() {
        context.sadhyaDataStore.edit { prefs ->
            val current = (prefs[Keys.JAPA_BEAD_COUNT] ?: 0).coerceIn(0, 107)
            if (current > 0) {
                prefs[Keys.JAPA_BEAD_COUNT] = current - 1
            }
        }
    }

    suspend fun setKeepScreenOnJapa(enabled: Boolean) {
        context.sadhyaDataStore.edit { it[Keys.KEEP_SCREEN_ON_JAPA] = enabled }
    }

    suspend fun setAlarmSettings(
        wakeEnabled: Boolean? = null,
        wakeTime: String? = null,
        bedtimeEnabled: Boolean? = null,
        bedtimeTime: String? = null,
        gayatriEnabled: Boolean? = null,
        gayatriMorningTime: String? = null,
        gayatriAfternoonTime: String? = null,
        gayatriEveningTime: String? = null
    ) {
        context.sadhyaDataStore.edit {
            if (wakeEnabled != null) it[Keys.WAKE_ALARM_ENABLED] = wakeEnabled
            if (wakeTime != null) it[Keys.WAKE_ALARM_TIME] = wakeTime
            if (bedtimeEnabled != null) it[Keys.BEDTIME_ENABLED] = bedtimeEnabled
            if (bedtimeTime != null) it[Keys.BEDTIME_TIME] = bedtimeTime
            if (gayatriEnabled != null) it[Keys.GAYATRI_ALARMS_ENABLED] = gayatriEnabled
            if (gayatriMorningTime != null) it[Keys.GAYATRI_MORNING_TIME] = gayatriMorningTime
            if (gayatriAfternoonTime != null) it[Keys.GAYATRI_AFTERNOON_TIME] = gayatriAfternoonTime
            if (gayatriEveningTime != null) it[Keys.GAYATRI_EVENING_TIME] = gayatriEveningTime
        }
    }

    suspend fun setFocusShieldState(
        active: Boolean,
        endEpochMs: Long,
        durationMinutes: Int = 45,
        strictness: String = "BALANCED"
    ) {
        context.sadhyaDataStore.edit {
            it[Keys.FOCUS_SHIELD_ACTIVE] = active
            it[Keys.FOCUS_SHIELD_END_EPOCH] = endEpochMs
            it[Keys.FOCUS_SHIELD_DURATION_MIN] = durationMinutes
            it[Keys.FOCUS_SHIELD_STRICTNESS] = strictness
        }
    }

    suspend fun setHomeCardVisibility(
        showQuickAudio: Boolean? = null,
        showWakeUp: Boolean? = null,
        showTasks: Boolean? = null
    ) {
        context.sadhyaDataStore.edit {
            if (showQuickAudio != null) it[Keys.SHOW_QUICK_AUDIO] = showQuickAudio
            if (showWakeUp != null) it[Keys.SHOW_WAKE_UP] = showWakeUp
            if (showTasks != null) it[Keys.SHOW_TASKS] = showTasks
        }
    }

    suspend fun setDailyVow(dateKey: String, index: Int, checked: Boolean) {
        context.sadhyaDataStore.edit {
            if (it[Keys.VOWS_DATE] != dateKey) {
                it[Keys.VOWS_DATE] = dateKey
                it[Keys.VOW_1] = false
                it[Keys.VOW_2] = false
                it[Keys.VOW_3] = false
                it[Keys.VOW_4] = false
            }
            when (index) {
                0 -> it[Keys.VOW_1] = checked
                1 -> it[Keys.VOW_2] = checked
                2 -> it[Keys.VOW_3] = checked
                3 -> it[Keys.VOW_4] = checked
            }
        }
    }

    suspend fun resetAllForGuestReset() {
        context.sadhyaDataStore.edit {
            it[Keys.JAPA_BEAD_COUNT] = 0
            it[Keys.FOCUS_SHIELD_ACTIVE] = false
            it[Keys.FOCUS_SHIELD_END_EPOCH] = 0L
            it[Keys.DISMISSED_TOUR] = false
            it[Keys.VOWS_DATE] = ""
            it[Keys.VOW_1] = false
            it[Keys.VOW_2] = false
            it[Keys.VOW_3] = false
            it[Keys.VOW_4] = false
        }
    }
}
