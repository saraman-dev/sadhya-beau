package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.alarm.AlarmScheduler
import com.example.auth.AuthHelper
import com.example.model.DarkModePreference
import com.example.model.DevoteePersona
import com.example.model.FontScaleLevel
import com.example.model.ThemeStyle
import com.example.model.UserProfile
import com.example.ui.components.ResponsiveContentColumn
import com.example.ui.components.SectionHeader
import com.example.ui.components.TimePickerField
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.viewmodel.AiTimetableState
import com.example.viewmodel.SadhanaViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileAiScreen(
    viewModel: SadhanaViewModel,
    profile: UserProfile,
    onJumpToTab: (Int) -> Unit,
    onUpgradeToGoogleSuccess: () -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val localPrefs by viewModel.localPrefs.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val isChatStreaming by viewModel.isChatStreaming.collectAsStateWithLifecycle()
    val aiTimetableState by viewModel.aiTimetableState.collectAsStateWithLifecycle()
    val temples by viewModel.templesState.collectAsStateWithLifecycle()
    val selectedTempleId by viewModel.selectedTempleId.collectAsStateWithLifecycle()
    val templePosts by viewModel.selectedTemplePosts.collectAsStateWithLifecycle()

    var chatInput by remember { mutableStateOf("") }
    var timetableRequest by remember { mutableStateOf("") }
    var isUpgrading by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var canExactAlarm by remember(context) { mutableStateOf(AlarmScheduler.canScheduleExactAlarms(context)) }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, context) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                canExactAlarm = AlarmScheduler.canScheduleExactAlarms(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    ResponsiveContentColumn(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Account & Sync Status Header
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = if (viewModel.isGuestMode) Icons.Default.Explore else Icons.Default.CloudDone,
                                contentDescription = "Account Mode",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(profile.displayName.ifBlank { "Devotee" }, style = MaterialTheme.typography.headlineSmall)
                                Text(
                                    text = if (viewModel.isGuestMode) "Guest Mode • Saved locally on this device"
                                    else profile.email.ifBlank { "Signed in with Google • Cloud Sync active" },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                                )
                            }
                        }

                        if (viewModel.isGuestMode) {
                            Button(
                                onClick = {
                                    isUpgrading = true
                                    AuthHelper.onGoogleSignInClicked(
                                        context = context,
                                        credentialManager = credentialManager,
                                        onAuthSuccess = {
                                            isUpgrading = false
                                            onUpgradeToGoogleSuccess()
                                        },
                                        onAuthError = { msg ->
                                            isUpgrading = false
                                            viewModel.showToast(msg)
                                        },
                                        scope = scope,
                                        onAuthCancelled = { isUpgrading = false }
                                    )
                                },
                                enabled = !isUpgrading,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("profile_upgrade_google_button")
                            ) {
                                if (isUpgrading) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                } else {
                                    Icon(Icons.Default.CloudDone, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Sign in with Google to Sync Cloud")
                                }
                            }
                        }
                    }
                }
            }

            // 2. Streaming Gemini Sadhana Companion Chat
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SectionHeader(
                            title = "Sadhana Routine Companion",
                            subtitle = "Powered by Gemini • Humble practical routine helper (for spiritual initiation or deep philosophical questions, always consult your Guru or senior devotees)",
                            actionLabel = "Clear Chat",
                            onAction = { viewModel.clearChat() }
                        )

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            chatMessages.takeLast(8).forEach { msg ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (msg.isUser) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                                    ),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = if (msg.isUser) "You" else "Sadhya Companion",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(Modifier.height(2.dp))
                                        Text(msg.text, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = chatInput,
                                onValueChange = { chatInput = it.take(400) },
                                label = { Text("Ask about Japa timing, sleep, or balance...") },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("ai_chat_input"),
                                maxLines = 3
                            )
                            IconButton(
                                onClick = {
                                    val q = chatInput.trim()
                                    if (q.isNotBlank()) {
                                        chatInput = ""
                                        viewModel.sendCompanionMessage(q)
                                    }
                                },
                                enabled = !isChatStreaming && chatInput.isNotBlank(),
                                modifier = Modifier.testTag("ai_chat_send_button")
                            ) {
                                if (isChatStreaming) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                } else {
                                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send message", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }

            // 3. Gemini Daily Timetable Generator
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SectionHeader(
                            title = "AI Daily Timetable Generator",
                            subtitle = "Crafts a balanced schedule while preserving your Essential Sadhana blocks"
                        )
                        OutlinedTextField(
                            value = timetableRequest,
                            onValueChange = { timetableRequest = it.take(200) },
                            label = { Text("Special focus today (e.g., exam week, Ekadashi, travel)") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("ai_timetable_input")
                        )
                        Button(
                            onClick = { viewModel.generateAiTimetable(timetableRequest) },
                            enabled = aiTimetableState !is AiTimetableState.Loading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("ai_timetable_generate_button")
                        ) {
                            if (aiTimetableState is AiTimetableState.Loading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(8.dp))
                                Text("Crafting Peaceful Schedule...")
                            } else {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Generate Balanced Timetable")
                            }
                        }

                        when (val st = aiTimetableState) {
                            is AiTimetableState.Generated -> {
                                Text(st.summary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    st.items.take(10).forEach { block ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "${block.startTime}–${block.endTime}",
                                                style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFamily),
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Spacer(Modifier.width(8.dp))
                                            Text(
                                                text = if (block.essential) "★ ${block.title}" else block.title,
                                                style = MaterialTheme.typography.bodySmall,
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { viewModel.applyGeneratedTimetable(st.items) },
                                        modifier = Modifier.testTag("ai_timetable_apply_button")
                                    ) {
                                        Icon(Icons.Default.Schedule, contentDescription = null)
                                        Spacer(Modifier.width(6.dp))
                                        Text("Apply Schedule")
                                    }
                                    OutlinedButton(
                                        onClick = { onJumpToTab(0) },
                                        modifier = Modifier.testTag("ai_timetable_view_home_button")
                                    ) {
                                        Text("View on Home")
                                    }
                                }
                            }
                            is AiTimetableState.Error -> {
                                Text(st.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            }
                            else -> Unit
                        }
                    }
                }
            }

            // 4. Temple Community Hub
            item {
                TempleCommunitySection(
                    temples = temples,
                    selectedTempleId = selectedTempleId,
                    followedTempleId = profile.followedTempleId,
                    posts = templePosts,
                    currentUserId = viewModel.currentUserId,
                    isGuestMode = viewModel.isGuestMode,
                    onSelectTemple = { viewModel.selectTemple(it) },
                    onFollowTemple = { viewModel.followTemple(it) },
                    onApplyAratiSchedule = { viewModel.applyTempleAratiSchedule(it) },
                    onRegisterTemple = { viewModel.registerTemple(it) },
                    onPublishPost = { tid, type, title, body, time ->
                        viewModel.publishTemplePost(tid, type, title, body, time)
                    },
                    onToggleSevaVolunteer = { viewModel.toggleSevaVolunteer(it) }
                )
            }

            // 5. Devotee Persona & Elder-Friendly Accessibility
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SectionHeader(
                            title = "Devotee Stage & Accessibility",
                            subtitle = "Switch anytime without losing your logs",
                            actionLabel = "10-Step Setup",
                            onAction = { viewModel.reopenOnboarding() }
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            DevoteePersona.entries.forEach { p ->
                                FilterChip(
                                    selected = localPrefs.devoteePersona == p,
                                    onClick = { viewModel.applyPersonaPreset(p, replaceSchedule = true) },
                                    label = { Text(p.shortTitle) },
                                    modifier = Modifier.testTag("profile_persona_${p.name}")
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Elder-Friendly Mode (1.18x)", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "Enlarges all text, spacing, and Japa controls for effortless reading.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Switch(
                                checked = localPrefs.elderModeEnabled,
                                onCheckedChange = { viewModel.setElderMode(it) },
                                modifier = Modifier.testTag("profile_elder_switch")
                            )
                        }
                    }
                }
            }

            // 6. Sacred Themes, Typography & Home Visibility
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Palette, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("Sacred Appearance & Home Cards", style = MaterialTheme.typography.headlineSmall)
                        }

                        Text("Sacred Palette", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            ThemeStyle.entries.forEach { style ->
                                FilterChip(
                                    selected = profile.themeStyle == style.name,
                                    onClick = { viewModel.setThemeStyle(style) },
                                    label = { Text(style.label) },
                                    modifier = Modifier.testTag("theme_style_${style.name}")
                                )
                            }
                        }

                        Text("Display Mode", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            DarkModePreference.entries.forEach { dm ->
                                FilterChip(
                                    selected = profile.darkModePreference == dm.name,
                                    onClick = { viewModel.setDarkMode(dm) },
                                    label = { Text(dm.label) }
                                )
                            }
                        }

                        Text("Text Scale", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FontScaleLevel.entries.forEach { fs ->
                                FilterChip(
                                    selected = profile.fontScaleLevel == fs.name,
                                    onClick = { viewModel.setFontScale(fs) },
                                    label = { Text(fs.label) }
                                )
                            }
                        }

                        HorizontalDivider()
                        ToggleRow("Show Quick Audio & Darshan on Home", localPrefs.showQuickAudioCard) {
                            viewModel.setHomeCards(showAudio = it)
                        }
                        ToggleRow("Show Brahma Muhurta Check-In on Home", localPrefs.showWakeUpCard) {
                            viewModel.setHomeCards(showWake = it)
                        }
                        ToggleRow("Show Personal Tasks & AI Parser on Home", localPrefs.showTasksCard) {
                            viewModel.setHomeCards(showTasks = it)
                        }
                    }
                }
            }

            // 7. Alarms & Discreet Sandhya Timings
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Alarm, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("Alarms & Sandhya Reminders", style = MaterialTheme.typography.headlineSmall)
                        }

                        ToggleRow("Brahma Muhurta Wake-Up Alarm", localPrefs.wakeAlarmEnabled) {
                            viewModel.updateAlarms(wakeEnabled = it)
                        }
                        TimePickerField("Wake-Up Time", profile.wakeTime, { viewModel.updateAlarms(wakeTime = it) }, testTag = "profile_wake_picker")

                        ToggleRow("3-Stage Bedtime Wind-Down", localPrefs.bedtimeWindDownEnabled) {
                            viewModel.updateAlarms(bedtimeEnabled = it)
                        }
                        TimePickerField("Sleep Time", profile.sleepTime, { viewModel.updateAlarms(bedtimeTime = it) }, testTag = "profile_sleep_picker")

                        ToggleRow("Discreet Sandhya Timing Reminders", localPrefs.gayatriAlarmsEnabled || profile.gayatriInitiated) {
                            viewModel.updateAlarms(gayatriEnabled = it)
                        }
                        if (localPrefs.gayatriAlarmsEnabled || profile.gayatriInitiated) {
                            Text(
                                text = "Quiet timing reminders only — confidential mantra texts are never stored or displayed.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            TimePickerField("Morning Sandhya", profile.gayatriMorningTime, { viewModel.updateAlarms(gayatriM = it) })
                            TimePickerField("Midday Sandhya", profile.gayatriAfternoonTime, { viewModel.updateAlarms(gayatriA = it) })
                            TimePickerField("Evening Sandhya", profile.gayatriEveningTime, { viewModel.updateAlarms(gayatriE = it) })
                        }

                        if (!canExactAlarm) {
                            OutlinedButton(
                                onClick = {
                                    try {
                                        context.startActivity(AlarmScheduler.exactAlarmSettingsIntent(context))
                                    } catch (_: Exception) {
                                        viewModel.showToast("Enable Alarms & Reminders permission in Android Settings.")
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Allow Exact Alarms in Android Settings")
                            }
                        }
                    }
                }
            }

            // 8. Account & Data Control
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SectionHeader(
                            title = "Account & Data Control",
                            subtitle = "Your spiritual journal belongs entirely to you"
                        )
                        OutlinedButton(
                            onClick = { showDeleteConfirmDialog = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("profile_reset_or_delete_button")
                        ) {
                            Icon(
                                imageVector = if (viewModel.isGuestMode) Icons.Default.RestartAlt else Icons.Default.DeleteForever,
                                contentDescription = null
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(if (viewModel.isGuestMode) "Reset Guest Data" else "Delete Account & Cloud Data")
                        }

                        Button(
                            onClick = onSignOut,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("profile_sign_out_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (viewModel.isGuestMode) "Exit Guest Mode" else "Sign Out")
                        }
                    }
                }
            }
        }
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = {
                Text(if (viewModel.isGuestMode) "Reset Guest Data?" else "Delete Account & Cloud Data?")
            },
            text = {
                Text(
                    if (viewModel.isGuestMode) {
                        "This clears your local guest schedule, tasks, Sadhana logs, and private check-ins and resets them to fresh defaults."
                    } else {
                        "This permanently deletes your Firestore profile, schedule, tasks, Sadhana logs, focus logs, and local private check-ins, then signs you out."
                    }
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        viewModel.resetOrDeleteAccountData {
                            if (!viewModel.isGuestMode) onSignOut()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    )
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (viewModel.isGuestMode) "Reset Data" else "Delete Everything")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun ToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
