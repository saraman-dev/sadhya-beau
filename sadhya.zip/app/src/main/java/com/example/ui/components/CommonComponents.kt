package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.audio.AudioPlaybackState
import com.example.model.TimeMath
import com.example.ui.theme.JetBrainsMonoFamily
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimePickerField(
    label: String,
    timeHHmm: String,
    onTimeSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "time_picker_field"
) {
    var showDialog by remember { mutableStateOf(false) }
    val minutes = TimeMath.parseHHmmToMinutes(timeHHmm.ifBlank { "05:00" })

    OutlinedCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag(testTag)
            .clickable { showDialog = true },
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = timeHHmm.ifBlank { "Tap to set" },
                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = JetBrainsMonoFamily),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Icon(
                imageVector = Icons.Default.AccessTime,
                contentDescription = "Select $label",
                tint = MaterialTheme.colorScheme.primary
            )
        }
    }

    if (showDialog) {
        val pickerState = rememberTimePickerState(
            initialHour = minutes / 60,
            initialMinute = minutes % 60,
            is24Hour = true
        )
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text(label, style = MaterialTheme.typography.headlineSmall) },
            text = {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    TimePicker(state = pickerState)
                }
            },
            confirmButton = {
                Button(onClick = {
                    val formatted = String.format(Locale.US, "%02d:%02d", pickerState.hour, pickerState.minute)
                    onTimeSelected(formatted)
                    showDialog = false
                }) {
                    Text("Set Time")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun MiniAudioPlayerBar(
    audioState: AudioPlaybackState,
    onTogglePlayPause: () -> Unit,
    onStop: () -> Unit,
    modifier: Modifier = Modifier
) {
    val track = audioState.currentTrack ?: return
    val mm = audioState.elapsedSeconds / 60
    val ss = audioState.elapsedSeconds % 60
    val elapsed = String.format(Locale.US, "%02d:%02d", mm, ss)

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("mini_audio_bar"),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        tonalElevation = 6.dp,
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.GraphicEq,
                contentDescription = "Devotional audio active",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
            )
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${if (audioState.isPlaying) "Playing" else "Paused"} • $elapsed",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                )
            }
            IconButton(
                onClick = onTogglePlayPause,
                modifier = Modifier.testTag("mini_audio_play_pause")
            ) {
                Icon(
                    imageVector = if (audioState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (audioState.isPlaying) "Pause audio" else "Play audio",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(
                onClick = onStop,
                modifier = Modifier.testTag("mini_audio_stop")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Stop audio",
                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (actionLabel != null && onAction != null) {
            TextButton(onClick = onAction) {
                Text(actionLabel)
            }
        }
    }
}

@Composable
fun ResponsiveContentColumn(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.TopCenter
    ) {
        Box(modifier = Modifier.widthIn(max = 840.dp).fillMaxWidth()) {
            content()
        }
    }
}

@Composable
fun AppGuideDialog(
    onDismiss: () -> Unit,
    onJumpToTab: (Int) -> Unit
) {
    val pages = listOf(
        Triple(
            "1. Welcome to Sadhya",
            "Built warmly for every Vaishnava — newcomers, Harinama/Brahmana initiates, students, grihasthas, temple residents, and elders. Switch your stage or turn on Elder-Friendly Mode anytime in Profile.",
            0
        ),
        Triple(
            "2. Sacred Daily Rhythm (Home)",
            "See today's Vaishnava Masa, Tithi, local Sunrise, your next activity (including overnight rest blocks), Brahma Muhurta check-in, and quick natural-language tasks with reminders.",
            0
        ),
        Triple(
            "3. 108-Bead Japa & Offline Tanpura",
            "Tap the circular 108-bead mala with gentle haptics (and a distinct celebratory pulse at bead 108). Listen to the built-in 100% offline Sa–Pa–Sa Tanpura or open Mayapur TV & Vedabase.",
            1
        ),
        Triple(
            "4. Local Vaishnava Calendar",
            "On-device astronomical Panchanga calculates Shuddha vs Mahadvadashi Ekadashi and Parana break-fast windows for your city, plus .ics import and one-tap Festival Mode.",
            2
        ),
        Triple(
            "5. Mindful Focus, Temples & AI",
            "Protect your Sadhana with Focus Shield's Mindful Pause, follow sacred temples or register your local mandir, and chat with Gemini as a humble routine companion.",
            3
        )
    )
    var pageIndex by remember { mutableIntStateOf(0) }
    val (title, body, targetTab) = pages[pageIndex]

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(title, style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { (pageIndex + 1) / pages.size.toFloat() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(body, style = MaterialTheme.typography.bodyMedium)
                TextButton(
                    onClick = {
                        onJumpToTab(targetTab)
                        onDismiss()
                    },
                    modifier = Modifier.testTag("guide_jump_tab_button")
                ) {
                    Text("Jump to this Tab →")
                }
            }
        },
        confirmButton = {
            if (pageIndex < pages.lastIndex) {
                Button(onClick = { pageIndex++ }) { Text("Next") }
            } else {
                Button(onClick = onDismiss) { Text("Begin Sadhana") }
            }
        },
        dismissButton = {
            if (pageIndex > 0) {
                TextButton(onClick = { pageIndex-- }) { Text("Back") }
            } else {
                TextButton(onClick = onDismiss) { Text("Close") }
            }
        }
    )
}
