package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "private_check_ins")
data class PrivateCheckInEntity(
    @PrimaryKey val dateKey: String,
    val wakeStatus: String,
    val actualWakeTime: String,
    val privatePhotoPath: String = "",
    val mantraHoldCompleted: Boolean = false,
    val checkedInAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "focus_rules")
data class FocusRuleEntity(
    @PrimaryKey val packageName: String,
    val appLabel: String,
    val blockDuringFocus: Boolean = true,
    val blockDuringBedtime: Boolean = true,
    val exceptionUntilMillis: Long = 0L
)

@Entity(tableName = "imported_calendar_events")
data class ImportedCalendarEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val dateKey: String,
    val title: String,
    val startTime: String = "",
    val endTime: String = "",
    val description: String = "",
    val location: String = "",
    val sourceName: String = "Imported .ics"
)

@Dao
interface PrivateCheckInDao {
    @Query("SELECT * FROM private_check_ins ORDER BY dateKey DESC LIMIT 30")
    fun observeRecentCheckIns(): Flow<List<PrivateCheckInEntity>>

    @Query("SELECT * FROM private_check_ins WHERE dateKey = :dateKey LIMIT 1")
    suspend fun getByDate(dateKey: String): PrivateCheckInEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: PrivateCheckInEntity)

    @Query("DELETE FROM private_check_ins")
    suspend fun clearAll()
}

@Dao
interface FocusRuleDao {
    @Query("SELECT * FROM focus_rules ORDER BY appLabel ASC")
    fun observeAllRules(): Flow<List<FocusRuleEntity>>

    @Query("SELECT * FROM focus_rules")
    suspend fun getAllRulesSnapshot(): List<FocusRuleEntity>

    @Query("SELECT * FROM focus_rules WHERE packageName = :packageName LIMIT 1")
    suspend fun getByPackage(packageName: String): FocusRuleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(rule: FocusRuleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(rules: List<FocusRuleEntity>)

    @Query("UPDATE focus_rules SET exceptionUntilMillis = :untilMillis WHERE packageName = :packageName")
    suspend fun setExceptionUntil(packageName: String, untilMillis: Long)

    @Query("DELETE FROM focus_rules WHERE packageName = :packageName")
    suspend fun deleteByPackage(packageName: String)

    @Query("DELETE FROM focus_rules")
    suspend fun clearAll()
}

@Dao
interface ImportedCalendarEventDao {
    @Query("SELECT * FROM imported_calendar_events ORDER BY dateKey ASC, startTime ASC")
    fun observeAllEvents(): Flow<List<ImportedCalendarEventEntity>>

    @Query("SELECT * FROM imported_calendar_events WHERE dateKey = :dateKey ORDER BY startTime ASC")
    suspend fun getEventsForDate(dateKey: String): List<ImportedCalendarEventEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(events: List<ImportedCalendarEventEntity>)

    @Query("DELETE FROM imported_calendar_events WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM imported_calendar_events")
    suspend fun clearAll()
}

@Database(
    entities = [
        PrivateCheckInEntity::class,
        FocusRuleEntity::class,
        ImportedCalendarEventEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SadhanaLocalDatabase : RoomDatabase() {
    abstract fun privateCheckInDao(): PrivateCheckInDao
    abstract fun focusRuleDao(): FocusRuleDao
    abstract fun importedCalendarEventDao(): ImportedCalendarEventDao

    companion object {
        @Volatile
        private var INSTANCE: SadhanaLocalDatabase? = null

        fun getInstance(context: Context): SadhanaLocalDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SadhanaLocalDatabase::class.java,
                    "sadhya_local.db"
                ).fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }

        val defaultFocusRules: List<FocusRuleEntity> = listOf(
            FocusRuleEntity("com.instagram.android", "Instagram", true, true),
            FocusRuleEntity("com.google.android.youtube", "YouTube", true, true),
            FocusRuleEntity("com.zhiliaoapp.musically", "TikTok", true, true),
            FocusRuleEntity("com.twitter.android", "X / Twitter", true, true),
            FocusRuleEntity("com.facebook.katana", "Facebook", true, true),
            FocusRuleEntity("com.reddit.frontpage", "Reddit", true, false)
        )
    }
}
