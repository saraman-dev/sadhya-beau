package com.example.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.SadhyaAiService
import com.example.alarm.AlarmScheduler
import com.example.audio.AudioPlaybackState
import com.example.audio.DevotionalAudioPlayer
import com.example.audio.DevotionalTrack
import com.example.data.SadhanaDataRepository
import com.example.data.local.FocusRuleEntity
import com.example.data.local.ImportedCalendarEventEntity
import com.example.data.local.LocalPrefsState
import com.example.data.local.PreferencesManager
import com.example.data.local.PrivateCheckInEntity
import com.example.data.local.SadhanaLocalDatabase
import com.example.engine.CityPreset
import com.example.engine.IcsCalendarParser
import com.example.engine.VaishnavaCalendarEngine
import com.example.engine.VaishnavaDayInfo
import com.example.focus.FocusMonitorService
import com.example.model.CalendarTradition
import com.example.model.ChatMessage
import com.example.model.DailyTask
import com.example.model.DarkModePreference
import com.example.model.DevoteePersona
import com.example.model.FocusLog
import com.example.model.FocusOutcome
import com.example.model.FocusStrictness
import com.example.model.FontScaleLevel
import com.example.model.ParsedTaskDraft
import com.example.model.RoutineMode
import com.example.model.RoutineTemplates
import com.example.model.SadhanaDailyLog
import com.example.model.ScheduleCategory
import com.example.model.ScheduleItem
import com.example.model.TaskPriority
import com.example.model.TempleCommunity
import com.example.model.TemplePost
import com.example.model.TemplePostType
import com.example.model.ThemeStyle
import com.example.model.UiState
import com.example.model.UserProfile
import com.example.model.WakeStatus
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

sealed interface AiTaskParseState {
    data object Idle : AiTaskParseState
    data object Loading : AiTaskParseState
    data class Parsed(val draft: ParsedTaskDraft) : AiTaskParseState
    data class FallbackNeeded(val rawInput: String, val errorMessage: String) : AiTaskParseState
}

sealed interface AiTimetableState {
    data object Idle : AiTimetableState
    data object Loading : AiTimetableState
    data class Generated(val summary: String, val items: List<ScheduleItem>, val isOfflineFallback: Boolean = false) : AiTimetableState
    data class Error(val message: String) : AiTimetableState
}

@OptIn(ExperimentalCoroutinesApi::class)
class SadhanaViewModel(
    private val appContext: Context,
    private val repository: SadhanaDataRepository,
    private val localDb: SadhanaLocalDatabase,
    private val preferencesManager: PreferencesManager,
    private val aiService: SadhyaAiService,
    val currentUserId: String,
    private val initialDisplayName: String,
    private val initialEmail: String
) : ViewModel() {

    val isGuestMode: Boolean get() = repository.isGuestMode

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _profileEnsured = MutableStateFlow(false)
    private val _profileSyncError = MutableStateFlow<String?>(null)

    private val _profileState = MutableStateFlow<UiState<UserProfile>>(UiState.Loading)
    val profileState: StateFlow<UiState<UserProfile>> = _profileState.asStateFlow()

    val localPrefs: StateFlow<LocalPrefsState> = preferencesManager.prefsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), LocalPrefsState())

    val scheduleState: StateFlow<UiState<List<ScheduleItem>>> = repository.observeSchedule(currentUserId)
        .map<List<ScheduleItem>, UiState<List<ScheduleItem>>> { UiState.Success(it) }
        .catch { err -> emitErrorOrRethrow(err, "Unable to sync schedule") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val tasksState: StateFlow<UiState<List<DailyTask>>> = repository.observeTasks(currentUserId)
        .map<List<DailyTask>, UiState<List<DailyTask>>> { UiState.Success(it) }
        .catch { err -> emitErrorOrRethrow(err, "Unable to sync tasks") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val sadhanaLogsState: StateFlow<UiState<List<SadhanaDailyLog>>> = repository.observeRecentSadhanaLogs(currentUserId)
        .map<List<SadhanaDailyLog>, UiState<List<SadhanaDailyLog>>> { UiState.Success(it) }
        .catch { err -> emitErrorOrRethrow(err, "Unable to sync Sadhana logs") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val focusLogsState: StateFlow<UiState<List<FocusLog>>> = repository.observeFocusLogs(currentUserId)
        .map<List<FocusLog>, UiState<List<FocusLog>>> { UiState.Success(it) }
        .catch { err -> emitErrorOrRethrow(err, "Unable to sync Focus logs") }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    val focusRules: StateFlow<List<FocusRuleEntity>> = localDb.focusRuleDao().observeAllRules()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val importedEvents: StateFlow<List<ImportedCalendarEventEntity>> = localDb.importedCalendarEventDao().observeAllEvents()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val recentPrivateCheckIns: StateFlow<List<PrivateCheckInEntity>> = localDb.privateCheckInDao().observeRecentCheckIns()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // Temples: merge cloud/local temples with built-in reference shrines so reference shrines stay available
    val templesState: StateFlow<List<TempleCommunity>> = repository.observeTemples()
        .map { savedTemples ->
            val merged = savedTemples + RoutineTemplates.referenceTemples.filter { ref ->
                savedTemples.none { it.id == ref.id }
            }
            merged.ifEmpty { RoutineTemplates.referenceTemples }
        }
        .catch { err ->
            if (isPureCancellation(err)) throw err
            emit(RoutineTemplates.referenceTemples)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), RoutineTemplates.referenceTemples)

    private val _selectedTempleId = MutableStateFlow("ref_mayapur")
    val selectedTempleId: StateFlow<String> = _selectedTempleId.asStateFlow()

    val selectedTemplePosts: StateFlow<List<TemplePost>> = _selectedTempleId
        .flatMapLatest { tid ->
            if (!isGuestMode && tid.startsWith("ref_")) {
                flowOf(RoutineTemplates.referencePosts.filter { it.templeId == tid })
            } else {
                repository.observeTemplePosts(tid).catch { err ->
                    if (isPureCancellation(err)) throw err
                    emit(emptyList())
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // Audio player with deduplicated daily hearing credit
    val audioPlayer = DevotionalAudioPlayer { trackId, creditMinutes ->
        creditHearingMinutesOnce(trackId, creditMinutes)
    }
    val audioState: StateFlow<AudioPlaybackState> = audioPlayer.state

    // Calendar month selection
    private val _calendarYearMonth = MutableStateFlow(
        Calendar.getInstance().let { it.get(Calendar.YEAR) to (it.get(Calendar.MONTH) + 1) }
    )
    val calendarYearMonth: StateFlow<Pair<Int, Int>> = _calendarYearMonth.asStateFlow()

    val calendarMonthDays: StateFlow<List<VaishnavaDayInfo>> = combine(
        _calendarYearMonth,
        _profileState
    ) { (year, month), profState ->
        val p = (profState as? UiState.Success)?.data
        VaishnavaCalendarEngine.calculateMonth(
            year = year,
            month = month,
            latitude = p?.latitude ?: 23.4231,
            longitude = p?.longitude ?: 88.3880,
            timezoneId = p?.timezoneId?.ifBlank { "Asia/Kolkata" } ?: "Asia/Kolkata",
            tradition = CalendarTradition.fromRaw(p?.calendarTradition)
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val todayInfo: StateFlow<VaishnavaDayInfo> = _profileState.map { profState ->
        val p = (profState as? UiState.Success)?.data
        val tzId = p?.timezoneId?.ifBlank { "Asia/Kolkata" } ?: "Asia/Kolkata"
        val cal = Calendar.getInstance(java.util.TimeZone.getTimeZone(tzId))
        VaishnavaCalendarEngine.calculateDay(
            year = cal.get(Calendar.YEAR),
            month = cal.get(Calendar.MONTH) + 1,
            day = cal.get(Calendar.DAY_OF_MONTH),
            latitude = p?.latitude ?: 23.4231,
            longitude = p?.longitude ?: 88.3880,
            timezoneId = tzId,
            tradition = CalendarTradition.fromRaw(p?.calendarTradition)
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000L),
        VaishnavaCalendarEngine.calculateDay(
            Calendar.getInstance().get(Calendar.YEAR),
            Calendar.getInstance().get(Calendar.MONTH) + 1,
            Calendar.getInstance().get(Calendar.DAY_OF_MONTH),
            23.4231, 88.3880, "Asia/Kolkata"
        )
    )

    // AI states
    private val _aiTaskParseState = MutableStateFlow<AiTaskParseState>(AiTaskParseState.Idle)
    val aiTaskParseState: StateFlow<AiTaskParseState> = _aiTaskParseState.asStateFlow()

    private val _aiTimetableState = MutableStateFlow<AiTimetableState>(AiTimetableState.Idle)
    val aiTimetableState: StateFlow<AiTimetableState> = _aiTimetableState.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                id = "welcome",
                isUser = false,
                text = "Hare Krishna! I am Sadhya's humble daily routine companion. Ask me for help balancing your Japa, morning wake-up, study/work blocks, or wind-down habits."
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isChatStreaming = MutableStateFlow(false)
    val isChatStreaming: StateFlow<Boolean> = _isChatStreaming.asStateFlow()
    private var chatJob: Job? = null

    // Compassionate Woke-Late reflection
    private val _wakeLateReflection = MutableStateFlow<String?>(null)
    val wakeLateReflection: StateFlow<String?> = _wakeLateReflection.asStateFlow()
    private val _isWakeReflectionLoading = MutableStateFlow(false)
    val isWakeReflectionLoading: StateFlow<Boolean> = _isWakeReflectionLoading.asStateFlow()

    // Live Focus countdown seconds
    private val _focusRemainingSec = MutableStateFlow(0L)
    val focusRemainingSec: StateFlow<Long> = _focusRemainingSec.asStateFlow()

    // Celebratory Japa bead 108 event counter
    private val _japaRoundCompletedPulse = MutableStateFlow(0)
    val japaRoundCompletedPulse: StateFlow<Int> = _japaRoundCompletedPulse.asStateFlow()

    private var profileObserveJob: Job? = null

    init {
        ensureDefaultFocusRules()
        bootstrapProfileAndSync()
        startFocusCountdownLoop()
    }

    private fun ensureDefaultFocusRules() {
        viewModelScope.launch {
            if (localDb.focusRuleDao().getAllRulesSnapshot().isEmpty()) {
                localDb.focusRuleDao().upsertAll(SadhanaLocalDatabase.defaultFocusRules)
            }
        }
    }

    fun retryProfileSync() {
        bootstrapProfileAndSync()
    }

    private fun bootstrapProfileAndSync() {
        profileObserveJob?.cancel()
        _profileState.value = UiState.Loading
        _profileEnsured.value = false
        _profileSyncError.value = null

        profileObserveJob = viewModelScope.launch {
            // CRITICAL SYNC RULE: Keep profileState in UiState.Loading while ensureUserProfileExists() runs
            val ensured = repository.ensureUserProfileExists(
                uid = currentUserId,
                displayName = initialDisplayName,
                email = initialEmail
            )
            if (ensured.isFailure) {
                val msg = ensured.exceptionOrNull()?.localizedMessage ?: "Failed to initialize cloud profile."
                _profileSyncError.value = msg
                _profileState.value = UiState.Error(msg)
                return@launch
            }
            val initialProfile = ensured.getOrThrow()
            _profileEnsured.value = true
            _profileState.value = UiState.Success(initialProfile)
            if (initialProfile.followedTempleId.isNotBlank()) {
                _selectedTempleId.value = initialProfile.followedTempleId
            }

            repository.observeUserProfile(currentUserId)
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    _profileState.value = UiState.Error(
                        firestoreError?.localizedMessage ?: error.localizedMessage ?: "Profile sync interrupted."
                    )
                }
                .collect { profile ->
                    // Never emit Success(null) while profile exists or is syncing
                    if (profile != null) {
                        _profileState.value = UiState.Success(profile)
                    }
                }
        }
    }

    private fun startFocusCountdownLoop() {
        viewModelScope.launch {
            while (true) {
                val prefs = localPrefs.value
                if (prefs.focusShieldActive && prefs.focusShieldEndEpochMs > 0L) {
                    val left = ((prefs.focusShieldEndEpochMs - System.currentTimeMillis()) / 1000L)
                    if (left <= 0L) {
                        _focusRemainingSec.value = 0L
                        preferencesManager.setFocusShieldState(false, 0L)
                        FocusMonitorService.stop(appContext)
                        repository.addFocusLog(
                            currentUserId,
                            FocusLog(
                                packageName = "com.sadhya.focus",
                                appLabel = "Sadhana Focus Shield",
                                strictness = prefs.focusShieldStrictness,
                                outcome = FocusOutcome.SESSION_COMPLETED.name,
                                reason = "Completed mindful focus session peacefully",
                                durationMinutes = prefs.focusShieldDurationMinutes.toLong()
                            )
                        )
                    } else {
                        _focusRemainingSec.value = left
                    }
                } else {
                    _focusRemainingSec.value = 0L
                }
                delay(1000L)
            }
        }
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun todayKey(): String {
        val tzId = (profileState.value as? UiState.Success)?.data?.timezoneId?.ifBlank { "Asia/Kolkata" } ?: "Asia/Kolkata"
        return VaishnavaCalendarEngine.todayDateKey(tzId)
    }

    // --- Onboarding & Persona ---

    fun applyPersonaPreset(persona: DevoteePersona, replaceSchedule: Boolean = true) {
        viewModelScope.launch {
            preferencesManager.setDevoteePersona(persona, updateElderMode = true)
            repository.updateUserProfileFields(
                currentUserId,
                mapOf(
                    "routineMode" to persona.defaultRoutineMode.name,
                    "wakeTime" to persona.defaultWakeTime,
                    "sleepTime" to persona.defaultSleepTime,
                    "japaTargetRounds" to persona.defaultRounds.toLong(),
                    "readingTargetMinutes" to persona.defaultReadingMin.toLong(),
                    "hearingTargetMinutes" to persona.defaultHearingMin.toLong(),
                    "gayatriInitiated" to persona.defaultGayatri
                )
            )
            if (replaceSchedule) {
                repository.replaceSchedule(currentUserId, RoutineTemplates.scheduleForPersona(persona))
            }
            showToast("Applied ${persona.displayTitle} routine")
        }
    }

    fun completeOnboarding(
        persona: DevoteePersona,
        displayName: String,
        wakeTime: String,
        sleepTime: String,
        japaRounds: Int,
        readingMin: Int,
        hearingMin: Int,
        elderMode: Boolean,
        gayatriInitiated: Boolean,
        gayatriM: String,
        gayatriA: String,
        gayatriE: String,
        responsibilities: List<String>,
        distractingPackages: List<String>,
        focusStrictness: FocusStrictness,
        tradition: CalendarTradition,
        cityPreset: CityPreset
    ) {
        viewModelScope.launch {
            preferencesManager.setDevoteePersona(persona, updateElderMode = false)
            preferencesManager.setElderMode(elderMode)
            preferencesManager.setAlarmSettings(
                wakeTime = wakeTime,
                bedtimeTime = sleepTime,
                gayatriEnabled = gayatriInitiated,
                gayatriMorningTime = gayatriM,
                gayatriAfternoonTime = gayatriA,
                gayatriEveningTime = gayatriE
            )
            val res = repository.updateUserProfileFields(
                currentUserId,
                mapOf(
                    "displayName" to displayName.trim().ifBlank { "Devotee" },
                    "routineMode" to persona.defaultRoutineMode.name,
                    "wakeTime" to wakeTime,
                    "sleepTime" to sleepTime,
                    "japaTargetRounds" to japaRounds.toLong(),
                    "readingTargetMinutes" to readingMin.toLong(),
                    "hearingTargetMinutes" to hearingMin.toLong(),
                    "gayatriInitiated" to gayatriInitiated,
                    "gayatriMorningTime" to gayatriM,
                    "gayatriAfternoonTime" to gayatriA,
                    "gayatriEveningTime" to gayatriE,
                    "responsibilities" to responsibilities.take(15),
                    "distractingPackages" to distractingPackages.take(30),
                    "focusStrictness" to focusStrictness.name,
                    "calendarTradition" to tradition.name,
                    "locationName" to cityPreset.name,
                    "latitude" to cityPreset.latitude,
                    "longitude" to cityPreset.longitude,
                    "timezoneId" to cityPreset.timezoneId,
                    "onboardingCompleted" to true
                )
            )
            repository.replaceSchedule(currentUserId, RoutineTemplates.scheduleForPersona(persona))
            AlarmScheduler.scheduleDailyWakeAlarm(appContext, wakeTime, localPrefs.value.wakeAlarmEnabled)
            AlarmScheduler.scheduleBedtimeWindDown(appContext, sleepTime, localPrefs.value.bedtimeWindDownEnabled)
            AlarmScheduler.scheduleGayatriSandhyaAlarms(appContext, gayatriInitiated, gayatriM, gayatriA, gayatriE)
            if (res.isSuccess) showToast("Welcome to Sadhya! Your personal routine is ready.")
        }
    }

    fun skipOnboardingWithDefaults() {
        viewModelScope.launch {
            repository.updateUserProfileFields(currentUserId, mapOf("onboardingCompleted" to true))
        }
    }

    fun reopenOnboarding() {
        viewModelScope.launch {
            repository.updateUserProfileFields(currentUserId, mapOf("onboardingCompleted" to false))
        }
    }

    // --- Profile & Preferences Updates ---

    fun updateProfileFields(fields: Map<String, Any>, toast: String? = null) {
        viewModelScope.launch {
            val res = repository.updateUserProfileFields(currentUserId, fields)
            if (res.isSuccess && toast != null) showToast(toast)
            if (res.isFailure) showToast(res.exceptionOrNull()?.localizedMessage ?: "Failed to update settings")
        }
    }

    fun setThemeStyle(style: ThemeStyle) = updateProfileFields(mapOf("themeStyle" to style.name))
    fun setDarkMode(pref: DarkModePreference) = updateProfileFields(mapOf("darkModePreference" to pref.name))
    fun setFontScale(scale: FontScaleLevel) = updateProfileFields(mapOf("fontScaleLevel" to scale.name))

    fun setElderMode(enabled: Boolean) {
        viewModelScope.launch { preferencesManager.setElderMode(enabled) }
    }

    fun setHomeCards(showAudio: Boolean? = null, showWake: Boolean? = null, showTasks: Boolean? = null) {
        viewModelScope.launch { preferencesManager.setHomeCardVisibility(showAudio, showWake, showTasks) }
    }

    fun markAppGuideSeen() {
        viewModelScope.launch { preferencesManager.setHasSeenAppGuide(true) }
    }

    fun dismissTourBanner() {
        viewModelScope.launch { preferencesManager.setDismissedTourBanner(true) }
    }

    fun switchRoutineMode(mode: RoutineMode) {
        viewModelScope.launch {
            repository.updateUserProfileFields(currentUserId, mapOf("routineMode" to mode.name))
            val persona = localPrefs.value.devoteePersona
            repository.replaceSchedule(currentUserId, RoutineTemplates.scheduleForRoutineMode(mode, persona))
            showToast("Switched routine to ${mode.label}")
        }
    }

    // --- Schedule CRUD ---

    fun saveScheduleItem(item: ScheduleItem) {
        viewModelScope.launch {
            val res = repository.saveScheduleItem(currentUserId, item)
            if (res.isSuccess) showToast("Schedule block saved")
            else showToast("Could not save block: ${res.exceptionOrNull()?.localizedMessage}")
        }
    }

    fun toggleScheduleComplete(item: ScheduleItem) {
        viewModelScope.launch {
            val today = todayKey()
            val nextDate = if (item.completedDateKey == today) "" else today
            repository.toggleScheduleCompletion(currentUserId, item.id, nextDate)
        }
    }

    fun deleteScheduleItem(itemId: String) {
        viewModelScope.launch {
            repository.deleteScheduleItem(currentUserId, itemId)
            showToast("Removed from schedule")
        }
    }

    // --- Personal Tasks CRUD + AI Parser ---

    fun saveTask(task: DailyTask) {
        viewModelScope.launch {
            val res = repository.saveTask(currentUserId, task)
            if (res.isSuccess) {
                val savedId = res.getOrNull().orEmpty()
                if (task.reminderTime.isNotBlank()) {
                    AlarmScheduler.scheduleOneShotTaskReminder(appContext, savedId, task.title, task.reminderTime)
                    showToast("Task saved with ${task.reminderTime} reminder")
                } else {
                    showToast("Task saved")
                }
            } else {
                showToast("Could not save task")
            }
        }
    }

    fun toggleTaskCompleted(task: DailyTask) {
        viewModelScope.launch {
            repository.toggleTaskCompleted(currentUserId, task.id, !task.completed)
        }
    }

    fun deleteTask(taskId: String) {
        viewModelScope.launch {
            repository.deleteTask(currentUserId, taskId)
        }
    }

    fun parseTaskWithGemini(rawInput: String) {
        if (rawInput.isBlank()) return
        viewModelScope.launch {
            _aiTaskParseState.value = AiTaskParseState.Loading
            val res = aiService.parseNaturalLanguageTask(rawInput)
            if (res.isSuccess) {
                _aiTaskParseState.value = AiTaskParseState.Parsed(res.getOrThrow())
            } else {
                val msg = res.exceptionOrNull()?.localizedMessage ?: "AI is currently unreachable."
                _aiTaskParseState.value = AiTaskParseState.FallbackNeeded(rawInput.trim(), msg)
            }
        }
    }

    fun resetTaskParseState() {
        _aiTaskParseState.value = AiTaskParseState.Idle
    }

    // --- Japa & Sadhana Logging ---

    private var lastBeadTapEpochMs: Long = 0L

    fun tapJapaBead() {
        val now = System.currentTimeMillis()
        // Prevent accidental double-taps or rapid mashing while keeping attentive chanting responsive
        if (now - lastBeadTapEpochMs < 400L) return
        lastBeadTapEpochMs = now
        viewModelScope.launch {
            val newCount = preferencesManager.incrementJapaBead()
            if (newCount >= 108) {
                _japaRoundCompletedPulse.value += 1
                recordCompletedJapaRound()
                showToast("Hare Krishna! 108 beads complete — +1 round logged.")
            }
        }
    }

    fun undoJapaBead() {
        viewModelScope.launch {
            preferencesManager.decrementJapaBead()
        }
    }

    fun resetJapaBeads() {
        viewModelScope.launch { preferencesManager.setJapaBeadCount(0) }
    }

    fun setKeepScreenOnJapa(enabled: Boolean) {
        viewModelScope.launch { preferencesManager.setKeepScreenOnJapa(enabled) }
    }

    private fun recordCompletedJapaRound() {
        viewModelScope.launch {
            repository.upsertSadhanaLog(currentUserId, todayKey()) { log ->
                log.copy(japaRounds = (log.japaRounds + 1L).coerceIn(0L, 192L))
            }
        }
    }

    fun updateTodaySadhanaLog(transform: (SadhanaDailyLog) -> SadhanaDailyLog, toast: String? = null) {
        viewModelScope.launch {
            val res = repository.upsertSadhanaLog(currentUserId, todayKey(), transform)
            if (res.isSuccess && toast != null) showToast(toast)
        }
    }

    fun setDailyVow(index: Int, checked: Boolean) {
        viewModelScope.launch {
            preferencesManager.setDailyVow(todayKey(), index, checked)
        }
    }

    private fun creditHearingMinutesOnce(trackId: String, minutes: Int) {
        viewModelScope.launch {
            repository.upsertSadhanaLog(currentUserId, todayKey()) { log ->
                if (trackId in log.creditedAudioIds) log
                else log.copy(
                    hearingMinutes = (log.hearingMinutes + minutes).coerceAtMost(720L),
                    creditedAudioIds = (log.creditedAudioIds + trackId).take(30)
                )
            }
        }
    }

    fun creditPortalVisit(track: DevotionalTrack) {
        creditHearingMinutesOnce(track.id, track.creditMinutes)
    }

    // --- Wake-Up Check-In & Compassionate Woke-Late Reflection ---

    fun syncWakeStatusOnTime() {
        val nowHHmm = SimpleDateFormat("HH:mm", Locale.US).format(Date())
        updateTodaySadhanaLog(
            transform = { it.copy(wakeStatus = WakeStatus.ON_TIME.name, wakeActualTime = nowHHmm) },
            toast = "Brahma Muhurta check-in recorded!"
        )
    }

    fun markWokeLateAndRequestReflection() {
        val nowHHmm = SimpleDateFormat("HH:mm", Locale.US).format(Date())
        val targetWake = (profileState.value as? UiState.Success)?.data?.wakeTime ?: "04:45"
        val persona = localPrefs.value.devoteePersona
        // Only update wake status if not already marked ON_TIME; closing dialog never overwrites saved status
        viewModelScope.launch {
            repository.upsertSadhanaLog(currentUserId, todayKey()) { log ->
                if (log.wakeStatus == WakeStatus.ON_TIME.name) log
                else log.copy(wakeStatus = WakeStatus.LATE.name, wakeActualTime = nowHHmm)
            }
            _isWakeReflectionLoading.value = true
            _wakeLateReflection.value = null
            val res = aiService.generateWokeLateReflection(nowHHmm, targetWake, persona)
            _isWakeReflectionLoading.value = false
            _wakeLateReflection.value = res.getOrElse {
                "Hare Krishna! Every morning is a fresh opportunity. Rather than feeling discouraged, take two calm breaths, chant even 2–4 attentive rounds now, and aim to wind down 15 minutes earlier tonight."
            }
        }
    }

    fun clearWakeLateReflection() {
        _wakeLateReflection.value = null
        _isWakeReflectionLoading.value = false
    }

    // --- Calendar & .ics ---

    fun shiftCalendarMonth(deltaMonths: Int) {
        val (y, m) = _calendarYearMonth.value
        val cal = Calendar.getInstance().apply {
            set(y, m - 1, 1)
            add(Calendar.MONTH, deltaMonths)
        }
        _calendarYearMonth.value = cal.get(Calendar.YEAR) to (cal.get(Calendar.MONTH) + 1)
    }

    fun setCalendarLocation(name: String, lat: Double, lon: Double, tzId: String) {
        updateProfileFields(
            mapOf(
                "locationName" to name,
                "latitude" to lat,
                "longitude" to lon,
                "timezoneId" to tzId
            ),
            toast = "Calendar calibrated to $name"
        )
    }

    fun setCalendarTradition(tradition: CalendarTradition) {
        updateProfileFields(mapOf("calendarTradition" to tradition.name), toast = "Tradition: ${tradition.label}")
    }

    fun activateFestivalMode(festivalName: String) {
        viewModelScope.launch {
            repository.updateUserProfileFields(currentUserId, mapOf("activeFestivalMode" to festivalName))
            if (festivalName.isNotBlank()) {
                repository.saveScheduleItem(
                    currentUserId,
                    ScheduleItem(
                        title = "Festival Observance: $festivalName",
                        category = ScheduleCategory.FESTIVAL.name,
                        startTime = "06:30",
                        endTime = "07:30",
                        essential = true,
                        notes = "Extra kirtan, reading & temple association"
                    )
                )
                showToast("Festival Mode active: $festivalName")
            } else {
                showToast("Festival Mode cleared")
            }
        }
    }

    fun importIcsContent(icsText: String, sourceName: String) {
        viewModelScope.launch {
            val parsed = IcsCalendarParser.parse(icsText, sourceName)
            if (parsed.isEmpty()) {
                showToast("No valid calendar events found in that .ics file.")
            } else {
                localDb.importedCalendarEventDao().insertAll(parsed)
                showToast("Imported ${parsed.size} calendar events")
            }
        }
    }

    // --- Focus Shield & Alarms ---

    fun startFocusShield(durationMinutes: Int, strictness: FocusStrictness) {
        viewModelScope.launch {
            val endEpoch = System.currentTimeMillis() + durationMinutes * 60_000L
            preferencesManager.setFocusShieldState(true, endEpoch, durationMinutes, strictness.name)
            repository.updateUserProfileFields(currentUserId, mapOf("focusStrictness" to strictness.name))
            FocusMonitorService.start(appContext, durationMinutes, endEpoch, strictness.name)
            showToast("Focus Shield started for $durationMinutes min")
        }
    }

    fun stopFocusShield() {
        viewModelScope.launch {
            preferencesManager.setFocusShieldState(false, 0L)
            FocusMonitorService.stop(appContext)
            showToast("Focus Shield ended")
        }
    }

    fun toggleFocusRule(rule: FocusRuleEntity, blockFocus: Boolean? = null, blockBedtime: Boolean? = null) {
        viewModelScope.launch {
            localDb.focusRuleDao().upsert(
                rule.copy(
                    blockDuringFocus = blockFocus ?: rule.blockDuringFocus,
                    blockDuringBedtime = blockBedtime ?: rule.blockDuringBedtime
                )
            )
        }
    }

    fun addCustomFocusRule(packageName: String, label: String) {
        if (packageName.isBlank() || label.isBlank()) return
        viewModelScope.launch {
            localDb.focusRuleDao().upsert(FocusRuleEntity(packageName.trim(), label.trim(), true, true))
            showToast("Added $label to Focus Shield")
        }
    }

    fun deleteFocusRule(packageName: String) {
        viewModelScope.launch { localDb.focusRuleDao().deleteByPackage(packageName) }
    }

    fun recordFocusLog(log: FocusLog) {
        viewModelScope.launch { repository.addFocusLog(currentUserId, log) }
    }

    fun updateAlarms(
        wakeEnabled: Boolean? = null,
        wakeTime: String? = null,
        bedtimeEnabled: Boolean? = null,
        bedtimeTime: String? = null,
        gayatriEnabled: Boolean? = null,
        gayatriM: String? = null,
        gayatriA: String? = null,
        gayatriE: String? = null
    ) {
        viewModelScope.launch {
            val cur = localPrefs.value
            val prof = (profileState.value as? UiState.Success)?.data
            val nextWakeEnabled = wakeEnabled ?: cur.wakeAlarmEnabled
            val nextWakeTime = wakeTime ?: prof?.wakeTime ?: cur.wakeAlarmTime
            val nextBedEnabled = bedtimeEnabled ?: cur.bedtimeWindDownEnabled
            val nextBedTime = bedtimeTime ?: prof?.sleepTime ?: cur.bedtimeTime
            val nextGayatriEnabled = gayatriEnabled ?: cur.gayatriAlarmsEnabled
            val gm = gayatriM ?: prof?.gayatriMorningTime ?: "06:15"
            val ga = gayatriA ?: prof?.gayatriAfternoonTime ?: "12:15"
            val ge = gayatriE ?: prof?.gayatriEveningTime ?: "18:15"

            preferencesManager.setAlarmSettings(
                wakeEnabled = nextWakeEnabled,
                wakeTime = nextWakeTime,
                bedtimeEnabled = nextBedEnabled,
                bedtimeTime = nextBedTime,
                gayatriEnabled = nextGayatriEnabled,
                gayatriMorningTime = gm,
                gayatriAfternoonTime = ga,
                gayatriEveningTime = ge
            )
            val updates = mutableMapOf<String, Any>(
                "wakeTime" to nextWakeTime,
                "sleepTime" to nextBedTime,
                "bedtimeModeEnabled" to nextBedEnabled,
                "gayatriInitiated" to nextGayatriEnabled,
                "gayatriMorningTime" to gm,
                "gayatriAfternoonTime" to ga,
                "gayatriEveningTime" to ge
            )
            repository.updateUserProfileFields(currentUserId, updates)

            AlarmScheduler.scheduleDailyWakeAlarm(appContext, nextWakeTime, nextWakeEnabled)
            AlarmScheduler.scheduleBedtimeWindDown(appContext, nextBedTime, nextBedEnabled)
            AlarmScheduler.scheduleGayatriSandhyaAlarms(appContext, nextGayatriEnabled, gm, ga, ge)
            showToast("Alarm schedule updated")
        }
    }

    // --- Streaming Gemini Companion & Timetable Generator ---

    fun sendCompanionMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isBlank() || _isChatStreaming.value) return
        val userMsg = ChatMessage(UUID.randomUUID().toString(), true, trimmed)
        val botId = UUID.randomUUID().toString()
        _chatMessages.value = _chatMessages.value + userMsg + ChatMessage(botId, false, "Reflecting peacefully...")
        _isChatStreaming.value = true

        chatJob?.cancel()
        chatJob = viewModelScope.launch {
            try {
                val prof = (profileState.value as? UiState.Success)?.data
                aiService.streamCompanionResponse(trimmed, prof, localPrefs.value.devoteePersona)
                    .collect { partial ->
                        _chatMessages.value = _chatMessages.value.map {
                            if (it.id == botId) it.copy(text = partial) else it
                        }
                    }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e("SadhanaVM", "Companion stream failed", e)
                val friendly = "Unable to reach Gemini right now (${e.localizedMessage ?: "offline"}). You can still use all offline Sadhana, Japa, Calendar, and Routine features."
                _chatMessages.value = _chatMessages.value.map {
                    if (it.id == botId) it.copy(text = friendly) else it
                }
            } finally {
                _isChatStreaming.value = false
            }
        }
    }

    fun clearChat() {
        chatJob?.cancel()
        _isChatStreaming.value = false
        _chatMessages.value = listOf(
            ChatMessage(
                id = "welcome_${System.currentTimeMillis()}",
                isUser = false,
                text = "Chat cleared. Hare Krishna — how can I assist with your daily routine today?"
            )
        )
    }

    fun generateAiTimetable(extraRequest: String) {
        val prof = (profileState.value as? UiState.Success)?.data ?: return
        val essentials = (scheduleState.value as? UiState.Success)?.data?.filter { it.essential } ?: emptyList()
        val persona = localPrefs.value.devoteePersona
        viewModelScope.launch {
            _aiTimetableState.value = AiTimetableState.Loading
            val res = aiService.generateTimetable(prof, persona, essentials, extraRequest)
            if (res.isSuccess) {
                val (summary, items) = res.getOrThrow()
                _aiTimetableState.value = AiTimetableState.Generated(summary, items, isOfflineFallback = false)
            } else {
                // Graceful offline template fallback preserving existing Essential blocks
                val template = RoutineTemplates.scheduleForPersona(persona)
                val merged = (essentials + template.filter { t -> essentials.none { e -> e.startTime == t.startTime } })
                    .sortedBy { it.startTime }
                _aiTimetableState.value = AiTimetableState.Generated(
                    summary = "Gemini is currently offline (${res.exceptionOrNull()?.localizedMessage ?: "network"}). Prepared a local ${persona.shortTitle} template preserving your Essential blocks.",
                    items = merged,
                    isOfflineFallback = true
                )
            }
        }
    }

    fun applyGeneratedTimetable(items: List<ScheduleItem>) {
        viewModelScope.launch {
            val res = repository.replaceSchedule(currentUserId, items)
            if (res.isSuccess) {
                _aiTimetableState.value = AiTimetableState.Idle
                showToast("Timetable applied to your Home schedule!")
            }
        }
    }

    // --- Temple Community Hub ---

    fun selectTemple(templeId: String) {
        _selectedTempleId.value = templeId
    }

    fun followTemple(temple: TempleCommunity) {
        _selectedTempleId.value = temple.id
        updateProfileFields(mapOf("followedTempleId" to temple.id), toast = "Following ${temple.name}")
    }

    fun applyTempleAratiSchedule(temple: TempleCommunity) {
        viewModelScope.launch {
            val blocks = listOf(
                ScheduleItem(title = "${temple.name} — Mangal Aarti", category = ScheduleCategory.AARTI.name, startTime = temple.mangalAartiTime, endTime = shiftHHmm(temple.mangalAartiTime, 30), essential = true, notes = "Official temple arati"),
                ScheduleItem(title = "${temple.name} — Darshan Aarti", category = ScheduleCategory.AARTI.name, startTime = temple.darshanAartiTime, endTime = shiftHHmm(temple.darshanAartiTime, 30), essential = false, notes = "Morning Deity greeting"),
                ScheduleItem(title = "${temple.name} — Bhagavatam Class", category = ScheduleCategory.HEARING.name, startTime = temple.bhagavatamClassTime, endTime = shiftHHmm(temple.bhagavatamClassTime, 45), essential = false, notes = "Daily temple class"),
                ScheduleItem(title = "${temple.name} — Sandhya Aarti", category = ScheduleCategory.AARTI.name, startTime = temple.sandhyaAartiTime, endTime = shiftHHmm(temple.sandhyaAartiTime, 30), essential = false, notes = "Evening Gaura Aarti")
            )
            blocks.forEach { repository.saveScheduleItem(currentUserId, it) }
            showToast("Added ${temple.name} arati timings to your schedule")
        }
    }

    fun registerTemple(temple: TempleCommunity) {
        viewModelScope.launch {
            val res = repository.createTemple(currentUserId, temple)
            if (res.isSuccess) {
                val id = res.getOrNull().orEmpty()
                _selectedTempleId.value = id
                repository.updateUserProfileFields(currentUserId, mapOf("followedTempleId" to id))
                showToast("Registered ${temple.name}")
            } else {
                showToast("Could not register temple: ${res.exceptionOrNull()?.localizedMessage}")
            }
        }
    }

    fun publishTemplePost(templeId: String, type: TemplePostType, title: String, body: String, eventTime: String) {
        val prof = (profileState.value as? UiState.Success)?.data
        viewModelScope.launch {
            val res = repository.createTemplePost(
                currentUserId,
                TemplePost(
                    templeId = templeId,
                    authorUid = currentUserId,
                    authorName = prof?.displayName ?: "Temple Servant",
                    postType = type.name,
                    title = title,
                    body = body,
                    eventDateKey = todayKey(),
                    eventTime = eventTime
                )
            )
            if (res.isSuccess) showToast("Published to temple board")
            else showToast("Only temple admins can post to cloud temples.")
        }
    }

    fun toggleSevaVolunteer(post: TemplePost) {
        if (post.templeId.startsWith("ref_") && !isGuestMode) {
            showToast("Register or select a live community temple to save Seva volunteer sign-ups in the cloud.")
            return
        }
        viewModelScope.launch {
            val res = repository.toggleSevaVolunteer(currentUserId, post.templeId, post.id)
            if (res.isFailure) showToast("Could not update Seva sign-up")
        }
    }

    // --- Account & Data Reset/Deletion ---

    fun resetOrDeleteAccountData(onComplete: () -> Unit) {
        viewModelScope.launch {
            val res = repository.deleteAccountAndData(currentUserId)
            preferencesManager.resetAllForGuestReset()
            localDb.privateCheckInDao().clearAll()
            localDb.importedCalendarEventDao().clearAll()
            if (res.isSuccess) {
                showToast(if (isGuestMode) "Guest data reset to fresh defaults." else "Cloud data deleted.")
                onComplete()
            } else {
                showToast("Could not delete data: ${res.exceptionOrNull()?.localizedMessage}")
            }
        }
    }

    private fun shiftHHmm(hhmm: String, addMinutes: Int): String {
        val mins = com.example.model.TimeMath.parseHHmmToMinutes(hhmm)
        return com.example.model.TimeMath.formatMinutesToHHmm(mins + addMinutes)
    }

    private fun isPureCancellation(error: Throwable): Boolean {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        return firestoreError == null && error is CancellationException
    }

    private suspend fun <T> kotlinx.coroutines.flow.FlowCollector<UiState<T>>.emitErrorOrRethrow(
        error: Throwable,
        fallbackMessage: String
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        emit(UiState.Error(firestoreError?.localizedMessage ?: error.localizedMessage ?: fallbackMessage))
    }

    override fun onCleared() {
        audioPlayer.stop()
        super.onCleared()
    }
}
