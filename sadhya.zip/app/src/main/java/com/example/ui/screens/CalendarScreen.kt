package com.example.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.engine.VaishnavaCalendarEngine
import com.example.model.CalendarTradition
import com.example.model.ScheduleCategory
import com.example.model.ScheduleItem
import com.example.model.TimeMath
import com.example.model.UserProfile
import com.example.ui.components.ResponsiveContentColumn
import com.example.ui.components.SectionHeader
import com.example.viewmodel.SadhanaViewModel
import com.google.android.gms.location.LocationServices
import java.text.DateFormatSymbols
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CalendarScreen(
    viewModel: SadhanaViewModel,
    profile: UserProfile
) {
    val context = LocalContext.current
    val yearMonth by viewModel.calendarYearMonth.collectAsStateWithLifecycle()
    val monthDays by viewModel.calendarMonthDays.collectAsStateWithLifecycle()
    val importedEvents by viewModel.importedEvents.collectAsStateWithLifecycle()
    val todayKey = viewModel.todayKey()

    var selectedDateKey by remember { mutableStateOf(todayKey) }
    LaunchedEffect(monthDays, todayKey) {
        if (monthDays.isNotEmpty() && monthDays.none { it.dateKey == selectedDateKey }) {
            selectedDateKey = if (monthDays.any { it.dateKey == todayKey }) todayKey else monthDays.first().dateKey
        }
    }

    val selectedDay = monthDays.firstOrNull { it.dateKey == selectedDateKey } ?: monthDays.firstOrNull()

    val icsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (!text.isNullOrBlank()) {
                    viewModel.importIcsContent(text, uri.lastPathSegment ?: "Vaishnava .ics")
                }
            } catch (_: Exception) {
                viewModel.showToast("Could not read selected .ics file.")
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun fetchCoarseLocation() {
        try {
            val fused = LocationServices.getFusedLocationProviderClient(context)
            fused.lastLocation.addOnSuccessListener { loc ->
                if (loc != null) {
                    viewModel.setCalendarLocation(
                        name = String.format(Locale.US, "My Location (%.2f, %.2f)", loc.latitude, loc.longitude),
                        lat = loc.latitude,
                        lon = loc.longitude,
                        tzId = TimeZone.getDefault().id
                    )
                } else {
                    viewModel.showToast("Location unavailable on emulator; select any city preset below.")
                }
            }
        } catch (_: Exception) {
            viewModel.showToast("Select any city preset below to calibrate sunrise & Parana.")
        }
    }

    val locationPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) fetchCoarseLocation()
        else viewModel.showToast("Using city preset for local Sunrise & Parana.")
    }

    ResponsiveContentColumn {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Festival Hero Banner
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(152.dp)
                        .clip(RoundedCornerShape(22.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_festival_banner),
                        contentDescription = "Vaishnava festival celebration banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Brush.verticalGradient(listOf(Color(0x33240B10), Color(0xD9240B10))))
                    )
                    Column(modifier = Modifier.align(Alignment.BottomStart).padding(16.dp)) {
                        Text("Vaishnava Panchanga & Ekadashi", style = MaterialTheme.typography.headlineSmall, color = Color(0xFFFFF8EE))
                        Text(
                            "${profile.locationName} • ${CalendarTradition.fromRaw(profile.calendarTradition).label}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFF3DEC6)
                        )
                    }
                }
            }

            // 2. Tradition & Location Calibration
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Tradition & City Calibration", style = MaterialTheme.typography.titleSmall)
                            OutlinedButton(
                                onClick = {
                                    val granted = ContextCompat.checkSelfPermission(
                                        context, Manifest.permission.ACCESS_COARSE_LOCATION
                                    ) == PackageManager.PERMISSION_GRANTED
                                    if (granted) fetchCoarseLocation()
                                    else locationPermLauncher.launch(Manifest.permission.ACCESS_COARSE_LOCATION)
                                },
                                modifier = Modifier.testTag("calibrate_gps_button")
                            ) {
                                Icon(Icons.Default.MyLocation, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Use GPS")
                            }
                        }

                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            val currentTrad = CalendarTradition.fromRaw(profile.calendarTradition)
                            CalendarTradition.entries.forEach { tr ->
                                FilterChip(
                                    selected = currentTrad == tr,
                                    onClick = { viewModel.setCalendarTradition(tr) },
                                    label = { Text(tr.label) }
                                )
                            }
                        }

                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            VaishnavaCalendarEngine.cityPresets.forEach { city ->
                                FilterChip(
                                    selected = profile.locationName == city.name,
                                    onClick = {
                                        viewModel.setCalendarLocation(city.name, city.latitude, city.longitude, city.timezoneId)
                                    },
                                    label = { Text(city.name.substringBefore(",")) }
                                )
                            }
                        }
                    }
                }
            }

            // 3. Monthly Grid
            item {
                val monthName = DateFormatSymbols(Locale.US).months[(yearMonth.second - 1).coerceIn(0, 11)]
                val firstDayOfWeek = remember(yearMonth) {
                    Calendar.getInstance().apply { set(yearMonth.first, yearMonth.second - 1, 1) }
                        .get(Calendar.DAY_OF_WEEK) - 1 // 0 = Sun
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = { viewModel.shiftCalendarMonth(-1) },
                                modifier = Modifier.testTag("calendar_prev_month")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous month")
                            }
                            Text("$monthName ${yearMonth.first}", style = MaterialTheme.typography.titleLarge)
                            IconButton(
                                onClick = { viewModel.shiftCalendarMonth(1) },
                                modifier = Modifier.testTag("calendar_next_month")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next month")
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth()) {
                            listOf("Su", "Mo", "Tu", "We", "Th", "Fr", "Sa").forEach { d ->
                                Text(
                                    text = d,
                                    style = MaterialTheme.typography.labelSmall,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        val totalCells = firstDayOfWeek + monthDays.size
                        val rows = (totalCells + 6) / 7
                        for (r in 0 until rows) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                for (c in 0..6) {
                                    val idx = r * 7 + c - firstDayOfWeek
                                    if (idx in monthDays.indices) {
                                        val info = monthDays[idx]
                                        val isSelected = info.dateKey == selectedDay?.dateKey
                                        val isToday = info.dateKey == todayKey
                                        val hasFest = info.festivals.isNotEmpty()
                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .aspectRatio(1f)
                                                .clickable { selectedDateKey = info.dateKey },
                                            shape = RoundedCornerShape(10.dp),
                                            color = when {
                                                isSelected -> MaterialTheme.colorScheme.primary
                                                info.isEkadashiFast -> MaterialTheme.colorScheme.secondaryContainer
                                                hasFest -> MaterialTheme.colorScheme.tertiaryContainer
                                                else -> Color.Transparent
                                            },
                                            border = if (isToday && !isSelected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null
                                        ) {
                                            Column(
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.Center
                                            ) {
                                                Text(
                                                    text = "${info.dayOfMonth}",
                                                    style = MaterialTheme.typography.labelLarge,
                                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                                )
                                                if (info.isEkadashiFast || hasFest) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(5.dp)
                                                            .clip(CircleShape)
                                                            .background(
                                                                if (isSelected) MaterialTheme.colorScheme.onPrimary
                                                                else if (info.isEkadashiFast) MaterialTheme.colorScheme.secondary
                                                                else MaterialTheme.colorScheme.tertiary
                                                            )
                                                    )
                                                }
                                            }
                                        }
                                    } else {
                                        Spacer(Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. Selected Day Detail Card (Ekadashi, Parana, Chaturmasya, Health & Humility Note)
            if (selectedDay != null) {
                item {
                    val dayImported = importedEvents.filter { it.dateKey == selectedDay.dateKey }
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("calendar_day_detail_card"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "${selectedDay.dateKey} • ${selectedDay.masaName} Masa",
                                style = MaterialTheme.typography.headlineSmall
                            )
                            Text(
                                text = "${selectedDay.paksha} ${selectedDay.tithiName}  •  Sunrise ${selectedDay.sunriseHHmm}  •  Sunset ${selectedDay.sunsetHHmm}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (selectedDay.isEkadashiFast) {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(
                                            text = "${selectedDay.ekadashiName} (${selectedDay.ekadashiType.label})",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Observe fasting according to your health, age, and temple/guru guidance. Please cross-check local temple timings.",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }

                            if (selectedDay.paranaWindow.isNotBlank()) {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.tertiaryContainer,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text("Parana Break-Fast Window", style = MaterialTheme.typography.titleSmall)
                                        Text(selectedDay.paranaWindow, style = MaterialTheme.typography.bodyMedium)
                                        Text(
                                            "Calculated from Hari-vasara & 1/3rd local daytime — confirm with your local temple calendar.",
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }

                            if (selectedDay.chaturmasyaPhase.isNotBlank()) {
                                Text(
                                    text = selectedDay.chaturmasyaPhase,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            if (selectedDay.festivals.isNotEmpty()) {
                                selectedDay.festivals.forEach { fest ->
                                    Text("• $fest", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                                }
                            }

                            if (dayImported.isNotEmpty()) {
                                Text("Imported .ics Events:", style = MaterialTheme.typography.labelLarge)
                                dayImported.forEach { ev ->
                                    Text("• ${ev.title} ${ev.startTime}", style = MaterialTheme.typography.bodySmall)
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                                val festTitle = selectedDay.festivals.firstOrNull()
                                    ?: "${selectedDay.paksha} ${selectedDay.tithiName}"
                                Button(
                                    onClick = {
                                        viewModel.saveScheduleItem(
                                            ScheduleItem(
                                                title = festTitle,
                                                category = ScheduleCategory.FESTIVAL.name,
                                                startTime = selectedDay.sunriseHHmm,
                                                endTime = TimeMath.formatMinutesToHHmm(selectedDay.sunriseMinutes + 60),
                                                essential = true,
                                                notes = "Added from Vaishnava Calendar (${selectedDay.dateKey})"
                                            )
                                        )
                                    },
                                    modifier = Modifier.weight(1f).testTag("add_festival_to_schedule_button")
                                ) { Text("Add to Schedule") }

                                OutlinedButton(
                                    onClick = {
                                        if (profile.activeFestivalMode == festTitle) viewModel.activateFestivalMode("")
                                        else viewModel.activateFestivalMode(festTitle)
                                    },
                                    modifier = Modifier.weight(1f).testTag("festival_mode_button")
                                ) {
                                    Icon(Icons.Default.Celebration, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(if (profile.activeFestivalMode == festTitle) "End Mode" else "Festival Mode")
                                }
                            }
                        }
                    }
                }
            }

            // 5. .ics Import & External Vaishnava Calendar Tools
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionHeader("Temple .ics Import & Reference", "Imported events: ${importedEvents.size}")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { icsLauncher.launch(arrayOf("text/calendar", "text/plain", "*/*")) },
                                modifier = Modifier.weight(1f).testTag("import_ics_button")
                            ) {
                                Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Import .ics")
                            }
                            OutlinedButton(
                                onClick = {
                                    try {
                                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.vaishnavacalendar.info")))
                                    } catch (_: Exception) {
                                        viewModel.showToast("Visit vaishnavacalendar.info")
                                    }
                                },
                                modifier = Modifier.weight(1f).testTag("external_calendar_button")
                            ) {
                                Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Web Calendar")
                            }
                        }
                        Text(
                            "Astronomical times are calculated locally on-device for offline reliability. Always cross-check with your local temple for regional fasting observances.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item { Spacer(Modifier.height(72.dp)) }
        }
    }
}
