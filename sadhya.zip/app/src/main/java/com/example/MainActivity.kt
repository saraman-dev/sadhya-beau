package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.ai.SadhyaAiService
import com.example.alarm.SadhanaAlarmReceiver
import com.example.auth.AuthHelper
import com.example.data.GuestLocalRepository
import com.example.data.SadhanaFirestoreRepository
import com.example.data.configureAppCheck
import com.example.data.local.LocalPrefsState
import com.example.data.local.PreferencesManager
import com.example.data.local.SadhanaLocalDatabase
import com.example.model.DarkModePreference
import com.example.model.FontScaleLevel
import com.example.model.ThemeStyle
import com.example.model.UiState
import com.example.ui.components.AppGuideDialog
import com.example.ui.components.MiniAudioPlayerBar
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CalendarScreen
import com.example.ui.screens.FocusScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.ProfileAiScreen
import com.example.ui.screens.SadhanaMediaScreen
import com.example.ui.theme.SadhyaTheme
import com.example.viewmodel.SadhanaViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // CRITICAL: Configure Firebase App Check BEFORE setContent, ViewModels, or any Firebase SDK calls
        configureAppCheck(this, intent)
        enableEdgeToEdge()
        SadhanaAlarmReceiver.ensureChannels(this)

        setContent {
            SadhyaRootApp()
        }
    }
}

private fun observeFirebaseAuthState(): Flow<FirebaseUser?> = callbackFlow {
    val auth = try {
        Firebase.auth
    } catch (_: Exception) {
        trySend(null)
        close()
        return@callbackFlow
    }
    val listener = FirebaseAuth.AuthStateListener { fa ->
        trySend(fa.currentUser)
    }
    auth.addAuthStateListener(listener)
    trySend(auth.currentUser)
    awaitClose { auth.removeAuthStateListener(listener) }
}

private data class NavTabItem(
    val label: String,
    val icon: ImageVector,
    val testTag: String
)

@Composable
private fun SadhyaRootApp() {
    val context = LocalContext.current
    val appContext = context.applicationContext
    val scope = rememberCoroutineScope()
    val preferencesManager = remember(appContext) { PreferencesManager(appContext) }
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val authUser by remember { observeFirebaseAuthState() }
        .collectAsStateWithLifecycle(initialValue = try { Firebase.auth.currentUser } catch (_: Exception) { null })
    val prefsState by preferencesManager.prefsFlow.collectAsStateWithLifecycle(initialValue = null as LocalPrefsState?)

    var justSignedOut by rememberSaveable { mutableStateOf(false) }

    val loadedPrefs = prefsState
    if (loadedPrefs == null) {
        SadhyaTheme {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        return
    }

    val isAuthenticatedCloud = authUser != null
    val isGuestActive = !isAuthenticatedCloud && loadedPrefs.guestModeEnabled

    if (!isAuthenticatedCloud && !isGuestActive) {
        SadhyaTheme(elderModeEnabled = loadedPrefs.elderModeEnabled) {
            AuthScreen(
                justSignedOut = justSignedOut,
                onGoogleAuthSuccess = {
                    justSignedOut = false
                    scope.launch { preferencesManager.setGuestMode(false) }
                },
                onContinueAsGuest = {
                    justSignedOut = false
                    scope.launch { preferencesManager.setGuestMode(true) }
                }
            )
        }
        return
    }

    val sessionUid = if (isAuthenticatedCloud) authUser!!.uid else GuestLocalRepository.GUEST_UID
    val sessionKey = if (isAuthenticatedCloud) "cloud_$sessionUid" else "guest_$sessionUid"

    key(sessionKey) {
        val factory = remember(sessionKey) {
            viewModelFactory {
                initializer {
                    val repo = if (isAuthenticatedCloud) {
                        SadhanaFirestoreRepository(appContext)
                    } else {
                        GuestLocalRepository(appContext)
                    }
                    SadhanaViewModel(
                        appContext = appContext,
                        repository = repo,
                        localDb = SadhanaLocalDatabase.getInstance(appContext),
                        preferencesManager = preferencesManager,
                        aiService = SadhyaAiService(),
                        currentUserId = sessionUid,
                        initialDisplayName = authUser?.displayName ?: "Devotee",
                        initialEmail = authUser?.email ?: ""
                    )
                }
            }
        }
        val viewModel: SadhanaViewModel = viewModel(key = sessionKey, factory = factory)

        SadhyaSessionHost(
            viewModel = viewModel,
            onSwitchToGuestFallback = {
                AuthHelper.signOut(credentialManager, scope) {
                    scope.launch { preferencesManager.setGuestMode(true) }
                }
            },
            onUpgradeToGoogleSuccess = {
                justSignedOut = false
                scope.launch { preferencesManager.setGuestMode(false) }
            },
            onSignOut = {
                justSignedOut = true
                if (isAuthenticatedCloud) {
                    AuthHelper.signOut(credentialManager, scope) {
                        scope.launch { preferencesManager.setGuestMode(false) }
                    }
                } else {
                    scope.launch { preferencesManager.setGuestMode(false) }
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SadhyaSessionHost(
    viewModel: SadhanaViewModel,
    onSwitchToGuestFallback: () -> Unit,
    onUpgradeToGoogleSuccess: () -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val profileState by viewModel.profileState.collectAsStateWithLifecycle()
    val localPrefs by viewModel.localPrefs.collectAsStateWithLifecycle()
    val audioState by viewModel.audioState.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var showGuideDialog by rememberSaveable { mutableStateOf(false) }

    // Request POST_NOTIFICATIONS gently on Android 13+ once signed into the sanctuary
    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    LaunchedEffect(toastMessage) {
        val msg = toastMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    val loadedProfile = (profileState as? UiState.Success)?.data
    SadhyaTheme(
        themeStyle = ThemeStyle.fromRaw(loadedProfile?.themeStyle),
        darkModePreference = DarkModePreference.fromRaw(loadedProfile?.darkModePreference),
        fontScaleLevel = FontScaleLevel.fromRaw(loadedProfile?.fontScaleLevel),
        elderModeEnabled = localPrefs.elderModeEnabled
    ) {
        when (val st = profileState) {
            is UiState.Loading -> {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(32.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(14.dp))
                        Text("Preparing your Sadhana sanctuary...", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            is UiState.Error -> {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(28.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Cloud Sync Interrupted", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = st.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(20.dp))
                        Button(
                            onClick = { viewModel.retryProfileSync() },
                            modifier = Modifier.fillMaxWidth().testTag("sync_retry_button")
                        ) {
                            Text("Retry Cloud Sync")
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = onSwitchToGuestFallback,
                            modifier = Modifier.fillMaxWidth().testTag("sync_offline_guest_button")
                        ) {
                            Text("Continue Offline in Guest Mode")
                        }
                        TextButton(onClick = onSignOut) {
                            Text("Sign Out")
                        }
                    }
                }
            }

            is UiState.Success -> {
                val profile = st.data
                if (!profile.onboardingCompleted) {
                    OnboardingScreen(
                        existingProfile = profile,
                        currentPersona = localPrefs.devoteePersona,
                        currentElderMode = localPrefs.elderModeEnabled,
                        onComplete = { persona, name, wake, sleep, rounds, read, hear, elder, gayatri, gm, ga, ge, resp, apps, strictness, trad, city ->
                            viewModel.completeOnboarding(
                                persona, name, wake, sleep, rounds, read, hear, elder,
                                gayatri, gm, ga, ge, resp, apps, strictness, trad, city
                            )
                        },
                        onSkipDefaults = { viewModel.skipOnboardingWithDefaults() }
                    )
                    return@SadhyaTheme
                }

                BackHandler(enabled = selectedTab != 0) {
                    selectedTab = 0
                }

                val tabs = listOf(
                    NavTabItem("Home", Icons.Default.Home, "nav_tab_home"),
                    NavTabItem("Sadhana", Icons.Default.SelfImprovement, "nav_tab_sadhana"),
                    NavTabItem("Calendar", Icons.Default.CalendarMonth, "nav_tab_calendar"),
                    NavTabItem("Focus", Icons.Default.Shield, "nav_tab_focus"),
                    NavTabItem("Profile", Icons.Default.Person, "nav_tab_profile")
                )

                BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                    val useRail = maxWidth >= 600.dp

                    val screenContent: @Composable (Modifier) -> Unit = { contentModifier ->
                        Box(modifier = contentModifier) {
                            when (selectedTab) {
                                0 -> HomeScreen(
                                    viewModel = viewModel,
                                    profile = profile,
                                    onOpenGuide = { showGuideDialog = true },
                                    onJumpToTab = { selectedTab = it }
                                )
                                1 -> SadhanaMediaScreen(
                                    viewModel = viewModel,
                                    profile = profile
                                )
                                2 -> CalendarScreen(
                                    viewModel = viewModel,
                                    profile = profile
                                )
                                3 -> FocusScreen(
                                    viewModel = viewModel,
                                    profile = profile
                                )
                                else -> ProfileAiScreen(
                                    viewModel = viewModel,
                                    profile = profile,
                                    onJumpToTab = { selectedTab = it },
                                    onUpgradeToGoogleSuccess = onUpgradeToGoogleSuccess,
                                    onSignOut = onSignOut
                                )
                            }

                            if (audioState.currentTrack != null) {
                                MiniAudioPlayerBar(
                                    audioState = audioState,
                                    onTogglePlayPause = { viewModel.audioPlayer.togglePlayPause() },
                                    onStop = { viewModel.audioPlayer.stop() },
                                    modifier = Modifier.align(Alignment.BottomCenter)
                                )
                            }
                        }
                    }

                    Scaffold(
                        contentWindowInsets = WindowInsets.safeDrawing,
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        topBar = {
                            TopAppBar(
                                title = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Sadhya", style = MaterialTheme.typography.headlineSmall)
                                        if (viewModel.isGuestMode) {
                                            Spacer(Modifier.width(8.dp))
                                            Text(
                                                text = "GUEST",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                },
                                colors = TopAppBarDefaults.topAppBarColors(
                                    containerColor = MaterialTheme.colorScheme.background
                                ),
                                actions = {
                                    IconButton(
                                        onClick = { showGuideDialog = true },
                                        modifier = Modifier.testTag("top_bar_guide_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.HelpOutline,
                                            contentDescription = "Open Sadhya App Guide"
                                        )
                                    }
                                }
                            )
                        },
                        bottomBar = {
                            if (!useRail) {
                                NavigationBar {
                                    tabs.forEachIndexed { idx, tab ->
                                        NavigationBarItem(
                                            selected = selectedTab == idx,
                                            onClick = { selectedTab = idx },
                                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                                            label = { Text(tab.label) },
                                            modifier = Modifier.testTag(tab.testTag)
                                        )
                                    }
                                }
                            }
                        }
                    ) { innerPadding ->
                        if (useRail) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                            ) {
                                NavigationRail(modifier = Modifier.fillMaxHeight()) {
                                    tabs.forEachIndexed { idx, tab ->
                                        NavigationRailItem(
                                            selected = selectedTab == idx,
                                            onClick = { selectedTab = idx },
                                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                                            label = { Text(tab.label) },
                                            modifier = Modifier.testTag(tab.testTag)
                                        )
                                    }
                                }
                                screenContent(Modifier.weight(1f).fillMaxHeight())
                            }
                        } else {
                            screenContent(Modifier.fillMaxSize().padding(innerPadding))
                        }
                    }
                }

                if (showGuideDialog) {
                    AppGuideDialog(
                        onDismiss = {
                            showGuideDialog = false
                            viewModel.markAppGuideSeen()
                        },
                        onJumpToTab = { tabIdx ->
                            selectedTab = tabIdx
                            viewModel.markAppGuideSeen()
                        }
                    )
                }
            }
        }
    }
}
