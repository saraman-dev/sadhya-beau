package com.example.ai

import android.util.Log
import com.example.model.DevoteePersona
import com.example.model.ParsedTaskDraft
import com.example.model.ScheduleCategory
import com.example.model.ScheduleItem
import com.example.model.TaskPriority
import com.example.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

class SadhyaAiService {

    companion object {
        private const val TAG = "SadhyaAiService"
        private const val MODEL_NAME = "gemini-3.8-flash"
        private const val TIMEOUT_MS = 60_000L

        private val VAISHNAVA_SYSTEM_PROMPT = """
            You are Sadhya's humble daily routine and habit assistant serving Vaishnava devotees across all stages of practice (newcomers, Harinama/Brahmana initiates, students, grihasthas, temple residents, and elders).
            STRICT NON-NEGOTIABLE GUARDRAILS:
            1. NEVER pose as a Guru, Acharya, or spiritual authority. Always speak humbly as a practical time-management and habit companion.
            2. NEVER issue theological verdicts or resolve sectarian debates. Gently encourage devotees to consult their Guru, senior devotees, or local temple for spiritual or fasting questions.
            3. NEVER invent, fabricate, or quote unverified Sanskrit slokas or scriptural citations.
            4. NEVER mention, ask for, or display any confidential Gayatri mantra text. Refer only discreetly to "Morning, Midday, or Evening Sandhya".
            5. NEVER shame, scold, or guilt-trip a devotee for waking late, missing rounds, or struggling with distractions. Always respond with warmth, compassion, and one small realistic next step.
            6. Keep responses concise, calm, practical, and uplifting.
        """.trimIndent()
    }

    private val chatModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            systemInstruction = content { text(VAISHNAVA_SYSTEM_PROMPT) }
        )
    }

    private val taskParserModel by lazy {
        val taskSchema = Schema.obj(
            properties = mapOf(
                "title" to Schema.string(description = "Clean concise task title"),
                "category" to Schema.string(description = "Short category like Devotion, Reading, Seva, Study, Family, Health, Festival"),
                "reminderTime" to Schema.string(description = "24-hour HH:mm time if mentioned, otherwise empty string"),
                "priority" to Schema.enumeration(listOf("LOW", "MEDIUM", "HIGH"), description = "Task priority"),
                "notes" to Schema.string(description = "Brief helpful note or empty string")
            )
        )
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            systemInstruction = content { text(VAISHNAVA_SYSTEM_PROMPT) },
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = taskSchema
            }
        )
    }

    private val timetableModel by lazy {
        val itemSchema = Schema.obj(
            properties = mapOf(
                "title" to Schema.string(description = "Activity title"),
                "category" to Schema.enumeration(
                    listOf("JAPA", "AARTI", "READING", "HEARING", "GAYATRI", "PUJA", "SEVA", "STUDY", "WORK", "FAMILY", "HEALTH", "REST", "FESTIVAL", "OTHER")
                ),
                "startTime" to Schema.string(description = "HH:mm 24-hour start time"),
                "endTime" to Schema.string(description = "HH:mm 24-hour end time"),
                "essential" to Schema.boolean(description = "True if core sadhana or rest block"),
                "notes" to Schema.string(description = "Short respectful note")
            )
        )
        val wrapperSchema = Schema.obj(
            properties = mapOf(
                "summary" to Schema.string(description = "Warm 1-2 sentence overview of the suggested timetable"),
                "items" to Schema.array(items = itemSchema, description = "Ordered daily schedule blocks")
            )
        )
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            systemInstruction = content { text(VAISHNAVA_SYSTEM_PROMPT) },
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = wrapperSchema
            }
        )
    }

    fun streamCompanionResponse(
        userMessage: String,
        profile: UserProfile?,
        persona: DevoteePersona
    ): Flow<String> = flow {
        val contextHeader = buildString {
            append("Devotee context: Stage=${persona.displayTitle}, ")
            append("Wake=${profile?.wakeTime ?: "04:45"}, Sleep=${profile?.sleepTime ?: "21:45"}, ")
            append("JapaGoal=${profile?.japaTargetRounds ?: 16} rounds, ")
            append("ReadingGoal=${profile?.readingTargetMinutes ?: 30}m.\n")
            append("User asks: $userMessage")
        }
        val sb = StringBuilder()
        withTimeout(TIMEOUT_MS) {
            chatModel.generateContentStream(contextHeader).collect { chunk ->
                val text = chunk.text.orEmpty()
                if (text.isNotEmpty()) {
                    sb.append(text)
                    emit(sb.toString())
                }
            }
        }
        if (sb.isBlank()) {
            throw IllegalStateException("The companion returned an empty response.")
        }
    }

    suspend fun generateWokeLateReflection(
        actualWakeTime: String,
        targetWakeTime: String,
        persona: DevoteePersona
    ): Result<String> {
        return try {
            val prompt = """
                A ${persona.displayTitle} woke up at $actualWakeTime instead of their target $targetWakeTime.
                Offer a brief (3-4 sentences), warm, non-judgmental encouragement and 2 small practical suggestions to still protect their morning Japa and prepare peacefully for tonight's rest.
            """.trimIndent()
            val response = withTimeout(TIMEOUT_MS) {
                chatModel.generateContent(prompt)
            }
            val text = response.text?.trim()
            if (!text.isNullOrBlank()) {
                Result.success(text)
            } else {
                Result.failure(IllegalStateException("Empty reflection response"))
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Wake reflection timed out", e)
            Result.failure(e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Wake reflection failed", e)
            Result.failure(e)
        }
    }

    suspend fun parseNaturalLanguageTask(rawInput: String): Result<ParsedTaskDraft> {
        return try {
            val prompt = "Parse this devotee's personal task into structured JSON fields. If no time is mentioned, set reminderTime to empty string. Input: \"$rawInput\""
            val response = withTimeout(TIMEOUT_MS) {
                taskParserModel.generateContent(prompt)
            }
            val jsonStr = stripJsonFences(response.text ?: throw IllegalStateException("Empty task JSON"))
            val json = JSONObject(jsonStr)
            val title = json.optString("title", rawInput).trim().ifBlank { rawInput.trim() }.take(160)
            val category = json.optString("category", "Devotion").trim().ifBlank { "Devotion" }.take(40)
            val rawTime = json.optString("reminderTime", "").trim()
            val validTime = if (rawTime.matches(Regex("^([01][0-9]|2[0-3]):[0-5][0-9]$"))) rawTime else ""
            val priority = TaskPriority.fromRaw(json.optString("priority", "MEDIUM"))
            val notes = json.optString("notes", "").trim().take(400)
            Result.success(ParsedTaskDraft(title, category, validTime, priority, notes))
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Task parsing timed out", e)
            Result.failure(e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Task parsing failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateTimetable(
        profile: UserProfile,
        persona: DevoteePersona,
        existingEssentialBlocks: List<ScheduleItem>,
        extraRequest: String
    ): Result<Pair<String, List<ScheduleItem>>> {
        return try {
            val essentialsSummary = existingEssentialBlocks.joinToString("\n") {
                "- ${it.startTime}-${it.endTime}: ${it.title} [${it.category}] (ESSENTIAL - MUST PRESERVE)"
            }.ifBlank { "None specified" }

            val prompt = """
                Build a compassionate, realistic daily timetable (6 to 9 blocks) for a ${persona.displayTitle}.
                Wake: ${profile.wakeTime}, Sleep: ${profile.sleepTime} (include an overnight REST block from ${profile.sleepTime} to ${profile.wakeTime}).
                Targets: ${profile.japaTargetRounds} rounds Japa, ${profile.readingTargetMinutes}m reading, ${profile.hearingTargetMinutes}m hearing.
                Gayatri Sandhya reminders needed: ${profile.gayatriInitiated} (if true, include discreet Sandhya blocks at ${profile.gayatriMorningTime}, ${profile.gayatriAfternoonTime}, ${profile.gayatriEveningTime} without ever mentioning confidential mantra texts).
                Responsibilities: ${profile.responsibilities.joinToString(", ")}.
                Existing ESSENTIAL blocks to preserve faithfully:
                $essentialsSummary
                Extra request from devotee: ${extraRequest.ifBlank { "Balanced steady routine" }}
            """.trimIndent()

            val response = withTimeout(TIMEOUT_MS) {
                timetableModel.generateContent(prompt)
            }
            val jsonStr = stripJsonFences(response.text ?: throw IllegalStateException("Empty timetable JSON"))
            val json = JSONObject(jsonStr)
            val summary = json.optString("summary", "Here is a gentle, balanced daily schedule tailored to your routine.")
            val arr = json.optJSONArray("items") ?: throw IllegalStateException("No schedule items returned")
            val parsed = (0 until arr.length()).mapNotNull { idx ->
                val obj = arr.optJSONObject(idx) ?: return@mapNotNull null
                val start = obj.optString("startTime", "05:00")
                val end = obj.optString("endTime", "06:00")
                if (!start.matches(Regex("^([01][0-9]|2[0-3]):[0-5][0-9]$")) ||
                    !end.matches(Regex("^([01][0-9]|2[0-3]):[0-5][0-9]$"))
                ) return@mapNotNull null
                ScheduleItem(
                    id = "",
                    title = obj.optString("title", "Sadhana Block").trim().take(120),
                    category = ScheduleCategory.fromRaw(obj.optString("category", "OTHER")).name,
                    startTime = start,
                    endTime = end,
                    essential = obj.optBoolean("essential", false),
                    notes = obj.optString("notes", "").trim().take(300),
                    sortOrder = (idx + 1).toLong()
                )
            }
            if (parsed.isEmpty()) {
                return Result.failure(IllegalStateException("Could not parse schedule blocks"))
            }
            Result.success(summary to parsed)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Timetable generation timed out", e)
            Result.failure(e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Timetable generation failed", e)
            Result.failure(e)
        }
    }

    private fun stripJsonFences(raw: String): String {
        val trimmed = raw.trim()
        if (!trimmed.startsWith("```")) return trimmed
        return trimmed
            .removePrefix("```json")
            .removePrefix("```JSON")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
    }
}
