package com.example.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.local.PreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootRescheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_TIME_CHANGED &&
            action != Intent.ACTION_TIMEZONE_CHANGED
        ) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val prefs = PreferencesManager(context.applicationContext).prefsFlow.first()
                AlarmScheduler.scheduleDailyWakeAlarm(context, prefs.wakeAlarmTime, prefs.wakeAlarmEnabled)
                AlarmScheduler.scheduleBedtimeWindDown(context, prefs.bedtimeTime, prefs.bedtimeWindDownEnabled)
                AlarmScheduler.scheduleGayatriSandhyaAlarms(
                    context = context,
                    enabled = prefs.gayatriAlarmsEnabled,
                    morningHHmm = prefs.gayatriMorningTime,
                    afternoonHHmm = prefs.gayatriAfternoonTime,
                    eveningHHmm = prefs.gayatriEveningTime
                )
            } finally {
                pendingResult.finish()
            }
        }
    }
}
